'use strict';
let ok = {
mpda:false,
emer:false,
first:false,
delay:false,
dig:function(){},
curok:'',
sc:[],
txtbut:function(n) {
  if(n == 'yes') return 'Да';
  else if(n == 'ok') return 'Ок';
  else if(n == 'next') return 'Далее';
  else if(n == 'back') return 'Назад';
  else if(n == 'run') return 'Выполнить';
  else if(n == 'cancel') return 'Отмена';
  else if(n == 'filter') return '...';
  else if(n == 'close') return 'Закрыть';
  else if(n == 'open') return 'Открыть';
  else if(n == 'save') return 'Сохранить';
  else if(n == 'continue') return 'Продолжить';
  else if(n == 'repeat') return 'Повторить';
  else if(n == 'apply') return 'Применить';
  else if(n == 'delete') return 'Удалить';
  else return 'undefined';
},

coun:function() {
 return;
 let cou = ok.sc.length;
 if(cou == 0) {
  diaokboxcoun_id.style.display = 'none';
  diaokboxcoun_id.innerHTML = '';
  return true;
 } else if(cou >= 1 && cou <= 2 ) {
  diaokboxcoun_id.innerHTML = '...' + cou;
 } else {
  diaokboxcoun_id.innerHTML = `<span onclick="ok.emer=true; ok.cancel('Закрыть все ?', function(r){if(r) ok.resall();});">...${cou} ${ok.txtbut('close')}</span>`;
 }
 diaokboxcoun_id.style.display = 'table-cell';
 return true;
},

show:function(...args) {
 if(diaok_id.style.display == '' && ok.emer == false) {
  let dlim = 99;
  if(ok.sc.length < dlim) {
    if(ok.first) ok.sc.unshift(JSON.stringify(args));
    else ok.sc.push(JSON.stringify(args));
  } else alert('Error: call ok.' + args[0] + '\nDialogs limit ' + dlim);
  ok.first = false;
  return {'return':false, 'curok':JSON.stringify(args)};
 } else {
  if(ok.emer) {
    ok.emer = false;
    if(ok.curok != '') ok.sc.unshift(ok.curok);
  }
  ok.curok = JSON.stringify(args);

  if(g('scrollbox_id')) scrollbox_id.classList.add('dsxblurclass');
  if(g('headpanel_id')) headpanel_id.classList.add('dsxblurclass');

  diaok_id.style.display = '';
  return {'return':true, 'curok':JSON.stringify(args)};
 }
},

okhas:function(c) {
 for(let i = 0; i < ok.sc.length; i++) if(ok.sc[i] == c) return true;
 return false;
},

hide:function(c) {
   window.getSelection().removeAllRanges();
   if(c !== undefined) {
     if(c != ok.curok) {
       for(let i = 0; i < ok.sc.length; i++) {
         if(ok.sc[i] == c) {
           ok.sc.splice(i, 1);
           ok.coun();
           return;
       } }
       return;
   } }
   diaok_id.style.display = 'none';
   diaokbox_id.innerHTML = '';
   ok.curok = '';

   if(g('scrollbox_id')) scrollbox_id.classList.remove('dsxblurclass');
   if(g('headpanel_id')) headpanel_id.classList.remove('dsxblurclass');

   if(ok.sc.length != 0) {
     let tar = JSON.parse(ok.sc.shift());
     eval(`ok.${tar.shift()}(...tar);`);
   }
},

autohide:function(t = 999, crk, f = function(c){ok.hide(c);}) {
  dsx.run(t, 'okautohide_' + urnd('okautohide'), f, function(...args) {
    if(ok.curok == args[7][0]) return 'run';
    if(!ok.okhas(args[7][0])) return 'del';
    else return 'pause';
  }, undefined, crk);
},

resall:function() {
  ok.sc.length = 0;
  ok.hide();
},

ok:function(txt, cb = function(){}, but_ok = ok.txtbut('yes'), ...argu) {
 if(ok.delay) {
  ok.delay = false;
  return (function(...a) {
   eval(`ok.${a.shift()}(...a);`);
  }).bind(undefined, 'ok', txt, cb.toString(), but_ok, ...argu);
 }
 let showres = ok.show('ok', txt, cb.toString(), but_ok, ...argu);
 if(showres['return']) {
  ok.dig = (function(f, a, r) {
    eval(`(${f})(r, ...a);`);
    ok.hide();
  }).bind(undefined, cb.toString(), argu.slice());
  if(but_ok != '') but_ok = `<div class="diaokboxfooter"><button onclick="ok.dig(true);">${but_ok}</button></div>`;
  diaokbox_id.innerHTML = `
   <div class="diaokboxheader">
     <div class="diaokboxheaderlcell"></div>
     <div class="diaokboxheaderrcell" id="diaokboxcoun_id"></div>
   </div>
   <div class="diaokboxbody">
     <div class="diaokboxtxtcont">${txt}</div>
   </div>
   ${but_ok}
  `;
 }
 ok.coun();
 return showres['curok'];
},

cancel:function(txt, cb = function(){}, but_c = ok.txtbut('cancel'), but_ok = ok.txtbut('yes'), ...argu) {
 if(ok.delay) {
  ok.delay = false;
  return (function(...a) {
   eval(`ok.${a.shift()}(...a);`);
  }).bind(undefined, 'cancel', txt, cb.toString(), but_c, but_ok, ...argu);
 }
 let showres = ok.show('cancel', txt, cb.toString(), but_c, but_ok, ...argu);
 if(showres['return']) {
  ok.dig = (function(f, a, r) {
    eval(`(${f})(r, ...a);`);
    ok.hide();
  }).bind(undefined, cb.toString(), argu.slice());
  diaokbox_id.innerHTML = `
   <div class="diaokboxheader">
     <div class="diaokboxheaderlcell"></div>
     <div class="diaokboxheaderrcell" id="diaokboxcoun_id"></div>
   </div>
   <div class="diaokboxbody">
     <div class="diaokboxtxtcont">${txt}</div>
   </div>
   <div class="diaokboxfooter">
     <button onclick="ok.dig(false);">${but_c}</button>
     <button onclick="ok.dig(true);">${but_ok}</button>
   </div>
  `;
 }
 ok.coun();
 return showres['curok'];
},

constr:function(txt, txt2 = '', cb = function(){}, ...argu) {
 let showres = ok.show('constr', txt, txt2, cb.toString(), ...argu);
 if(showres['return']) {
  ok.dig = (function(f, a, ...ua) {
    if(eval(`(${f})(...a, ...ua);`) !== false) ok.hide();
  }).bind(undefined, cb.toString(), argu.slice());
  if(txt2 != '') txt2 = `<div class="diaokboxfooter">${txt2}</div>`;
  diaokbox_id.innerHTML = `
   <div class="diaokboxheader">
     <div class="diaokboxheaderlcell"></div>
     <div class="diaokboxheaderrcell" id="diaokboxcoun_id"></div>
   </div>
   <div class="diaokboxbody">
     <div class="diaokboxtxtcont">${txt}</div>
   </div>
   ${txt2}
  `;
  ok.dig('htset');
 }
 ok.coun();
 return showres['curok'];
},

rlfilt:function(t, lar) {
 let cs = 0;
 for(let i = 0; i < lar.length; i++) {
  if(t.value == '') {
   cs = false;
   g('okrlist_id' + i).style.display = '';
  } else {
   if(lar[i][3] == lar[i][3].replace(eval('/' + dsx.toucode(t.value) + '/ui'), function(match) {return '';}) || (lar[i][1] + lar[i][0]).includes('disabled')) {
    g('okrlist_id' + i).style.display = 'none';
   } else {
    ++cs;
    g('okrlist_id' + i).style.display = '';
 }}}
 let rb = '';
 if(cs === false) {}
 else if(cs > 0) rb = cs.toString();
 else rb = 'пусто';
 diaokboxcounf_id.innerHTML = rb;
},

rlar:[],
rlist:function(ide, rl, cb = function(){}, but_c = ok.txtbut('cancel'), ...argu) {
 ok.rlar = rl.slice();
 if(ok.delay) {
  ok.delay = false;
  if(ide != '') g(ide).innerText = ok.valtoar(g(ide).dataset.xval)[3];
  return (function(...a) {
   eval(`ok.${a.shift()}(...a);`);
  }).bind(undefined, 'rlist', ide, rl, cb.toString(), but_c, ...argu);
 }
 let showres = ok.show('rlist', ide, rl, cb.toString(), but_c, ...argu);
 if(showres['return']) {
  let rb = '', selid;
  for(let i=0; i<rl.length; i++) {
   let discl = '', selcl = '', sel = '';
   if((rl[i][1] + rl[i][0]).includes('disabled')) discl = 'disabledtext';
   if(ide != '') {
    if(rl[i][2] == g(ide).dataset.xval) sel = 'checked';
   } else sel = rl[i][1];
   if(sel.includes('checked')) {
    selcl = 'selectedbox';
    selid = i;
   }
   rb += `
    <form onsubmit="return false;"><label class="okrlist ${selcl} ${discl}" id="okrlist_id${i}">
      <input type="radio" data-idx="${i}" value="${rl[i][2]}" onclick="ok.dig(+this.dataset.idx,this.value);" name="okrlist_name" ${sel} ${rl[i][0]}/>
      ${rl[i][3]}
    </label></form>`;
  }
  let ft = `
   <div class="diaokboxfooter">
     <button onclick="ok.dig(false);">${but_c}</button>
   </div>
  `;
  if(but_c == '') ft = '';
  ok.dig = (function(i, f, a, r, k) {
    if(r !== false && i != '') {
     g(i).dataset.xval = k;
     g(i).innerText = ok.valtoar(k)[3];
    }
    eval(`(${f})(r, k, ...a);`);
    ok.hide();
  }).bind(undefined, ide, cb.toString(), argu.slice());
  let filshow = 'none';
  if(rl.length > 5) filshow = 'table-cell';
  diaokbox_id.innerHTML = `
   <div class="diaokboxheader">
     <div class="diaokboxheaderlcell"><div style="display:${filshow};">
       <form onsubmit="return false;"><input type="text" autocomplete="off" oninput="ok.rlfilt(this,ok.rlar);" onkeydown="if(event.key=='Enter'){this.blur();}" placeholder="${ok.txtbut('filter')}" id="oklistfilt_id" ondblclick="dsx.run(111,'ondblclick',()=>{oklistfilt_id.value='';ok.rlfilt(g('oklistfilt_id'),ok.rlar);});"/>
       <br><span id="diaokboxcounf_id"></span></form>
     </div></div>
     <div class="diaokboxheaderrcell" id="diaokboxcoun_id"></div>
   </div>
   <div class="diaokboxbody" id="diaokboxbody_id">${rb}</div>
   ${ft}
  `;
  diaokboxbody_id.scrollTop = (diaokboxbody_id.scrollHeight/rl.length)*selid;
 }
 ok.coun();
 return showres['curok'];
},

valtoar:function(xv) {
 for(let i = 0; i < ok.rlar.length; i++) {
  if(ok.rlar[i][2] == xv) return ok.rlar[i];
 }
 return false;
},

clar:[],
clist:function(ide, rl, cb = function(){}, but_c = ok.txtbut('cancel'), but_ok = ok.txtbut('yes'), ...argu) {
 ok.clar = rl.slice();
 if(ok.delay) {
  ok.delay = false;
  if(ide != '') ok.lcor(ide, ok.lcou(rl));
  return (function(...a) {
   eval(`ok.${a.shift()}(...a);`);
  }).bind(undefined, 'clist', ide, rl, cb.toString(), but_c, but_ok, ...argu);
 }
 let showres = ok.show('clist', ide, rl, cb.toString(), but_c, but_ok, ...argu);
 if(showres['return']) {
  let rb = '';
  for(let i=0; i<rl.length; i++) {
   let discl = '', selcl = '';
   if((rl[i][0]).includes('disabled')) discl = 'disabledtext';
   if((rl[i][1]).includes('checked')) selcl = 'selectedbox';
   rb += `
    <form onsubmit="return false;"><label class="okrlist ${selcl} ${discl}" id="okrlist_id${i}">
      <input type="checkbox" data-idx="${i}" value="${rl[i][2]}" onclick="ok.clclk(this,${i});" ${rl[i][1]} ${rl[i][0]}/>
      ${rl[i][3]}
    </label></form>`;
  }
  ok.dig = (function(i, f, a, r, k) {
    if(r !== false && i != '') ok.lcor(i, ok.lcou(k));
    eval(`(${f})(r, k, ...a);`);
    ok.clar.length = 0;
    ok.hide();
  }).bind(undefined, ide, cb.toString(), argu.slice());
  let filshow = 'none';
  if(rl.length > 5) filshow = 'table-cell';
  diaokbox_id.innerHTML = `
   <div class="diaokboxheader">
     <div class="diaokboxheaderlcell"><div style="display:${filshow};">
       <form onsubmit="return false;"><input type="text" autocomplete="off" oninput="ok.rlfilt(this,ok.clar);" onkeydown="if(event.key=='Enter'){this.blur();}" placeholder="${ok.txtbut('filter')}" id="oklistfilt_id" ondblclick="dsx.run(111,'ondblclick',()=>{oklistfilt_id.value='';ok.rlfilt(g('oklistfilt_id'),ok.clar);});"/>
       <br><span id="diaokboxcounf_id"></span></form>
     </div></div>
     <div class="diaokboxheaderrcell" id="diaokboxcoun_id"></div>
   </div>
   <div class="diaokboxbody">${rb}</div>
   <div class="diaokboxfooter">
     <button class="tbord" onclick="ok.dig(false);">${but_c}</button>
     <button class="tbord" onclick="ok.dig(ok.lcou(ok.clar), ok.clar.slice());">${but_ok}</button>
   </div>
  `;
 }
 ok.coun();
 return showres['curok'];
},

clclk:function(t, i) {
 if(t.checked) ok.clar[+t.dataset.idx][1] = 'checked';
 else ok.clar[+t.dataset.idx][1] = '';
 g('okrlist_id' + i).classList.toggle('selectedbox');
},

lcou:function(lar) {
 let c = 0;
 for(let i=0; i<lar.length; i++) if((lar[i][0] + lar[i][1]).includes('checked')) ++c;
 return c;
},

lcor:function(ide, c) {
 g(ide).innerText = 'Выбрано: ' + c;
},

};

