<?php
function txta_md($dafnam, $txa, $wcnt, $grn) {
  $txa = str_replace(["\r","\t"], ['',' '], $txa);

  $txar = preg_split('/\n\s/', $txa, 2, PREG_SPLIT_NO_EMPTY);
  if($dafnam == 'dabkrs' || $dafnam == 'dabkrss' || $grn == 'cdict') {
    if(count($txar) == 2) {
      $txar2 = preg_split('/\n/', $txar[1], 2, PREG_SPLIT_NO_EMPTY);
      $txa = str_replace("\n", '\\n', $txar[0])."\n".str_replace("\n", '\\n', $txar2[0])."\n".str_replace("\n", '\\n', $txar2[1]);
    } else {
      $txa = '@err'.$wcnt."\n".'_'."\n".str_replace("\n", '\\n', $txa);
    }
  } else if($dafnam == 'dabruks' || $dafnam == 'examples' || $grn == 'dsldict') {
    if(count($txar) == 2) {
      $txa = str_replace("\n", '\\n', $txar[0])."\n".str_replace("\n", '\\n', $txar[1]);
    } else {
      $txa = '@err'.$wcnt."\n".str_replace("\n", '\\n', $txa);
    }
  }

  if($dafnam == 'dabkrss') {
    if(preg_match("/\n[\s]*_[\s]*\n/", $txa) == 1) {
      return '';
    }
  }

  $txa = str_replace(['<','>'], ['&lt;','&gt;'], $txa);
  $txa = preg_replace('/(\[[\*]\]|\[\/[\*]\])/', ' ', $txa);
  if($GLOBALS['md_indent'] == 0) $txa = preg_replace('/(\[m[0-9]?\]|\[\/m\])/', ' \\n ', $txa);
  else $txa = preg_replace('/\[m[01]?\](.*?)\[\/m\]/', ' \\n $1 \\n ', $txa);
  $txa = preg_replace('/(\[b\][ ]*[IV]+[ ,])/', '\\n$1', $txa);
  $txa = preg_replace('/(\[b\][ ]*[IV]+[ ]*\[\/b\])/', '\\n$1', $txa);
  while(preg_match('/\\\\n[ ]*\\\\n/', $txa) == 1) {
    $txa = preg_replace('/\\\\n[ ]*\\\\n/', '\\n', $txa);
  }
  $txa = preg_replace('/[ ]{2,}/', ' ', $txa);
  $txa = preg_replace('/[ ]*\\\\n[ ]*/', '\\n', $txa);
  $txa = preg_replace('/(\\\\n| )*\n(\\\\n| )*/', "\n", $txa);
  $txa = preg_replace('/(\\\\n| )*$/', '', $txa);
  $txa = preg_replace('/^(\\\\n| )*/', '', $txa);
  $txa = preg_replace('/([\(\[])[ ]+/', '$1', $txa);
  $txa = preg_replace('/[ ]+([\)\]])/', '$1', $txa);
  if($dafnam == 'examples') {
    if(preg_match('/(\\\\n\\\\n.*)(\\\\n)+/', $txa) == 1) {
      $txa = str_replace('\\n\\n', '\\n', $txa);
    }
  }
  if($GLOBALS['md_indent'] > 0) {
    $txa = preg_replace_callback('/\[m(\d)\](.*?)\[\/m\]/', function($matches) {
      if(intval($matches[1]) < 2) return ' \\n '.$matches[2].' \\n ';
      return '<div style="padding-left:'.((intval($matches[1])-1)*$GLOBALS['md_indent']).'px;">'.$matches[2].'</div>';
    }, $txa);
  }
  $txa = preg_replace('/\[([\/]?)(i|b|u|sub|sup)\]/', '<$1$2>', $txa);
  $txa = preg_replace('/\[c[^\[\]\\\\]*\]/', '<font color="#008000">', $txa);
  $txa = str_replace('[/c]', '</font>', $txa);
  $txa = str_replace('[p]', '<font color="#008000">', $txa);
  $txa = str_replace('[/p]', '</font>', $txa);
  $txa = str_replace('[ex]', '<font color="#808080">• ', $txa);
  $txa = str_replace('[/ex]', '</font>', $txa);
  if($grn == '') $txa = preg_replace('/(?<=\[\/ref\])([\s\p{P}]*)(?=\[ref\])/u', '<br>$1', $txa);
  $txa = preg_replace('/\[ref\]([^\[\]]+)\[\/ref\]/', '<a href="entry://$1">$1</a>', $txa);
  $txa = preg_replace('/\\\\([\[\]])/', '$1', $txa);
  return str_replace('\\n', '<br>', $txa);
}

function convert_md($dadir, $dafnam, $profdicarr, $dictitle, $dicdescr, $dadate, $testfl, $grn = '') {
$md_dir = 'MDict';
if(!is_dir($md_dir)) mkdir($md_dir);
$ddir = $md_dir.'/'.$dafnam;
if(is_dir($ddir)) rrmdir($ddir);
mkdir($ddir);

$fntmp = $ddir.'/~mdx.tmp';
$htmpwrite = fopen($fntmp, 'a');

$blcklim = 1000;
$curoffset = 0;
$wordcount = 0;
$wordcountall = 0;
$tarr = array();
$keybytecount = 0;
$meabytecount = 0;
$blockcount = 0;
$kinbcount = 0;
$iterbuff = '';
$pckszarr = array();
foreach ($profdicarr as $dakey => $val) {
  $fnamerd = $dadir;
  if($grn == '') {
    if($dakey == 'dabkrss') $fnamerd .= 'dabkrs_'.$dadate;
    else $fnamerd .= $dakey.'_'.$dadate;
  } else {
    $fnamerd .= $dakey;
  }
  $fp = @fopen($fnamerd, 'r');
  if(!$fp) return 'err:'.$fnamerd;
  $lbuf = '';
  $wordc = 1;
  fgsit($fp, $dakey);
  while (true) {
    $buffer = fgets($fp);
    if($buffer == "\r\n" || $buffer == "\n" || $buffer === false) {
      if($buffer === false && $lbuf == '') break;
      $lbuf = trim($lbuf);
      if($lbuf == '') continue;
      ++$wordcountall;
      $xtx = txta_md($dakey, $lbuf, $wordcountall, $grn);
      if($xtx == '') {
        $lbuf = '';
        continue;
      }
      $ard = explode("\n", $xtx);
      $ardk0 = str_replace(['&lt;','&gt;'], ['<','>'], $ard[0]);

      if($dakey == 'dabkrs' || $dakey == 'dabkrss' || $grn == 'cdict') {
        $ard[1] .= '<hr>'.$ard[2];
      }

      $keybytecount += strlen($ardk0."\x00") + 8;
      $ard[1] = $ard[0].'<hr>'.$ard[1].$GLOBALS['md_addcontent']."\x00";
      $ktl = strlen($ard[1]);
      $iterbuff .= $ard[1];
      $tarr[$curoffset] = $ardk0;
      $curoffset += $ktl;
      ++$wordcount;
      ++$kinbcount;
      $lbuf = '';
      if($kinbcount == $blcklim) {
        fwrite($htmpwrite, pack('V', 2), 4);
        fwrite($htmpwrite, hash('adler32', $iterbuff, true), 4);
        $ktl = fwrite($htmpwrite, gzcompress($iterbuff, $GLOBALS['md_compress']));
        $pckszarr[] = array($ktl + 8, strlen($iterbuff));
        $meabytecount += $ktl + 8;
        $iterbuff = '';
        $kinbcount = 0;
        ++$blockcount;
      }
      if($testfl) {
        if($wordc >= $GLOBALS['tstnums']) break;
        else ++$wordc;
      }
    } else $lbuf .= $buffer;
  }
  fclose($fp);
}

if($iterbuff != '') {
  fwrite($htmpwrite, pack('V', 2), 4);
  fwrite($htmpwrite, hash('adler32', $iterbuff, true), 4);
  $ktl = fwrite($htmpwrite, gzcompress($iterbuff, $GLOBALS['md_compress']));
  $pckszarr[] = array($ktl + 8, strlen($iterbuff));
  $meabytecount += $ktl + 8;
  $iterbuff = '';
  ++$blockcount;
}
fclose($htmpwrite);
$keybytecount += $blockcount * 8;

uasort($tarr, 'ucmp');
$tblockarr = array();
$iterblockarr = array();
$kinbcount = 0;
foreach ($tarr as $key => $val) {
  $iterblockarr[$key] = $val;
  ++$kinbcount;
  if($kinbcount == $blcklim) {
    $lastkey = end($iterblockarr);
    $firstkey = reset($iterblockarr);
    $szkb = 0;
    foreach ($iterblockarr as $key1 => $val1) $szkb += strlen($val1."\x00") + 8;
    $tblockarr[] = [$blcklim, $firstkey, $lastkey, $szkb];
    $kinbcount = 0;
    $iterblockarr = array();
  }
}
if($kinbcount != 0) {
  $lastkey = end($iterblockarr);
  $firstkey = reset($iterblockarr);
  $szkb = 0;
  foreach ($iterblockarr as $key1 => $val1) $szkb += strlen($val1."\x00") + 8;
  $tblockarr[] = [$kinbcount, $firstkey, $lastkey, $szkb];
  $kinbcount = 0;
  $iterblockarr = array();
}

$szttlbkeys = 0;
$hadl = hash_init('adler32');
foreach ($tblockarr as $key1 => $val1) {
  $strlenfir = strlen($val1[1]);
  $strlenlst = strlen($val1[2]);
  $szttlbkeys += $strlenfir + $strlenlst + 30;
  $xadl = array($val1[0], $strlenfir, $val1[1]."\x00", $strlenlst, $val1[2]."\x00", $val1[3] + 8, $val1[3]);
  foreach ($xadl as $key => $val) {
    if($key == 0 || $key == 5 || $key == 6) {
      hash_update($hadl, pack('N', 0));
      hash_update($hadl, pack('N', $val));
    } else if($key == 1 || $key == 3) {
      hash_update($hadl, pack('n', $val));
    } else if($key == 2 || $key == 4) {
      hash_update($hadl, $val);
    }
  }
}
$adltbk = hash_final($hadl, true);

$fnmdx = $ddir.'/'.$dafnam.'.mdx';
$hmdxwrite = fopen($fnmdx, 'a');
$header_str = '<Dictionary GeneratedByEngineVersion="2.0" RequiredEngineVersion="2.0" Encrypted="0" Encoding="UTF-8" Format="Html" CreationDate="'.date('Y-m-d',time()).'" Compact="No" Compat="No" KeyCaseSensitive="No" Description="'.$dicdescr.'" Title="'.$dictitle.'" DataSourceFormat="106" StripKey="No" StyleSheet=""/>'."\r\n\x00";

$header_str = iconv('UTF-8', 'UTF-16LE//IGNORE', $header_str);
fwrite($hmdxwrite, pack('N', strlen($header_str)), 4);
fwrite($hmdxwrite, $header_str);
fwrite($hmdxwrite, pack('N',implode('',unpack('V', hash('adler32', $header_str, true)))), 4);

$xadl = array($blockcount, $wordcount, $szttlbkeys, $szttlbkeys + 8, $keybytecount);
$hadl = hash_init('adler32');
foreach ($xadl as $key => $val) {
  hash_update($hadl, pack('N', 0));
  hash_update($hadl, pack('N', $val));
  fwrite($hmdxwrite, pack('N', 0), 4);
  fwrite($hmdxwrite, pack('N', $val), 4);
}
fwrite($hmdxwrite, hash_final($hadl, true), 4);

fwrite($hmdxwrite, pack('N', 0), 4);
fwrite($hmdxwrite, $adltbk, 4);
foreach ($tblockarr as $key1 => $val1) {
  $xadl = array($val1[0], strlen($val1[1]), $val1[1]."\x00", strlen($val1[2]), $val1[2]."\x00", $val1[3] + 8, $val1[3]);
  foreach ($xadl as $key => $val) {
    if($key == 0 || $key == 5 || $key == 6) {
      fwrite($hmdxwrite, pack('N', 0), 4);
      fwrite($hmdxwrite, pack('N', $val), 4);
    } else if($key == 1 || $key == 3) {
      fwrite($hmdxwrite, pack('n', $val), 2);
    } else if($key == 2 || $key == 4) {
      fwrite($hmdxwrite, $val);
    }
  }
}

$iterblockarr = array();
$kinbcount = 0;
foreach ($tarr as $key1 => $val1) {
  $iterblockarr[$key1] = $val1;
  ++$kinbcount;
  if($kinbcount == $blcklim) {
    $hadl = hash_init('adler32');
    foreach ($iterblockarr as $key => $val) {
      hash_update($hadl, pack('N', 0));
      hash_update($hadl, pack('N', $key));
      hash_update($hadl, $val."\x00");
    }
    fwrite($hmdxwrite, pack('N', 0), 4);
    fwrite($hmdxwrite, hash_final($hadl, true), 4);
    foreach ($iterblockarr as $key => $val) {
      fwrite($hmdxwrite, pack('N', 0), 4);
      fwrite($hmdxwrite, pack('N', $key), 4);
      fwrite($hmdxwrite, $val."\x00");
    }
    $kinbcount = 0;
    $iterblockarr = array();
  }
}
if($kinbcount != 0) {
    $hadl = hash_init('adler32');
    foreach ($iterblockarr as $key => $val) {
      hash_update($hadl, pack('N', 0));
      hash_update($hadl, pack('N', $key));
      hash_update($hadl, $val."\x00");
    }
    fwrite($hmdxwrite, pack('N', 0), 4);
    fwrite($hmdxwrite, hash_final($hadl, true), 4);
    foreach ($iterblockarr as $key => $val) {
      fwrite($hmdxwrite, pack('N', 0), 4);
      fwrite($hmdxwrite, pack('N', $key), 4);
      fwrite($hmdxwrite, $val."\x00");
    }
  $kinbcount = 0;
  $iterblockarr = array();
}
unset($iterblockarr);
unset($tblockarr);
unset($tarr);
    
$xadl = array($blockcount, $wordcount, $blockcount * 16, $meabytecount);
foreach ($xadl as $key => $val) {
  fwrite($hmdxwrite, pack('N', 0), 4);
  fwrite($hmdxwrite, pack('N', $val), 4);
}
foreach ($pckszarr as $key => $val) {
  fwrite($hmdxwrite, pack('N', 0), 4);
  fwrite($hmdxwrite, pack('N', $val[0]), 4);
  fwrite($hmdxwrite, pack('N', 0), 4);
  fwrite($hmdxwrite, pack('N', $val[1]), 4);
}
unset($pckszarr);
unset($xadl);

$ftmpsz = filesize($fntmp);
$htmprd = fopen($fntmp, 'r');
$frwlen = 102400;
for( ; ; ) {
  if($ftmpsz > $frwlen) {
    fwrite($hmdxwrite, fread($htmprd, $frwlen), $frwlen);
    $ftmpsz -= $frwlen;
  } else {
    @fwrite($hmdxwrite, @fread($htmprd, $ftmpsz), $ftmpsz);
    break;
  }
}
fclose($htmprd);
fclose($hmdxwrite);
unlink($fntmp);

@copy('dsx/mdx_icon.jpg', $ddir.'/'.$dafnam.'.jpg');

zipc($ddir);
return restfunc($dafnam, $wordcount, $wordcountall);
}
?>