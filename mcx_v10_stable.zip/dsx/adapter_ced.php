<?php
function is_rf($fnam) {
  if(is_readable($fnam)) if(!is_dir($fnam)) if(filesize($fnam) != 0) return true;
  return false;
}

function aced_py($sstr) {
  if(preg_match('#(.+) (.+) \[(.+)] /(.*)/#', $sstr, $match) !== 1) return false;
  $match[4] = preg_replace_callback('/(?<=\[)([^\[\]]+)(?=\])/u', function($matches) {
    return convertToPinyinDiacritic($matches[1]);
  }, $match[4]);
  $match[4] = preg_replace('/([\[\]])/', '\\\\$1', $match[4]);
  return array('simplified' => $match[2], 'pinyinDiacritic' => convertToPinyinDiacritic($match[3]), 'englishExpanded' => explode('/', $match[4]));
}

function adapter_ced($fninp, $fnoutp) {
  if(!is_rf($fninp) && !is_rf($fnoutp)) return false;
  if(is_rf($fnoutp)) return true;

  $hinprd = fopen($fninp, 'r');
  while(true) {
    $sstr = fgets($hinprd);
    if(mb_substr(trim($sstr),0,1) != '#') break;
  }

  $hfop = fopen($fnoutp, 'a');
  fwrite($hfop, " ");

  for( ; ; ) {
    $itarr = aced_py($sstr);
    if($itarr !== false) {
      fwrite($hfop, "\n\n".$itarr['simplified']."\n ");
      fwrite($hfop, $itarr['pinyinDiacritic']."\n ");
      $nenex = count($itarr['englishExpanded']);
      if($nenex > 1) {
        foreach ($itarr['englishExpanded'] as $ike => $itval) fwrite($hfop, '[m1]'.++$ike.') '.$itval.'[/m]');
      } else if($nenex == 1) {
        fwrite($hfop, '[m1]'.$itarr['englishExpanded'][0].'[/m]');
      }
    }
    $sstr = fgets($hinprd);
    if($sstr === false) break;
  }
  fclose($hinprd);
  fclose($hfop);
  
  return true;
}

//https://github.com/mdsills/cccedict
function convertToPinyinDiacritic($pinyin0) {
  $vowels = ['a', 'e', 'i', 'o', 'u', 'u:', 'A', 'E', 'I', 'O', 'U', 'U:'];
  $conversion = [
    1 => array_combine($vowels, ['ā', 'ē', 'ī', 'ō', 'ū', 'ǖ', 'Ā', 'Ē', 'Ī', 'Ō', 'Ū', 'Ǖ']),
    2 => array_combine($vowels, ['á', 'é', 'í', 'ó', 'ú', 'ǘ', 'Á', 'É', 'Í', 'Ó', 'Ú', 'Ǘ']),
    3 => array_combine($vowels, ['ǎ', 'ě', 'ǐ', 'ǒ', 'ǔ', 'ǚ', 'Ǎ', 'Ě', 'Ǐ', 'Ǒ', 'Ǔ', 'Ǚ']),
    4 => array_combine($vowels, ['à', 'è', 'ì', 'ò', 'ù', 'ǜ', 'À', 'È', 'Ì', 'Ò', 'Ù', 'Ǜ']),
  ];

  $pinyins0 = explode(' ', $pinyin0);
  $returnPinyins0 = [];
  foreach ($pinyins0 as $pinyin0) {
    $pinyin0 = trim($pinyin0);
    if($pinyin0 == '') continue;

    $pinyins = preg_split('/(.+?\d)/', $pinyin0, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
    $returnPinyins = [];
    foreach ($pinyins as $pinyin) {
      $pinyin = trim($pinyin);
      if($pinyin == '') continue;

      $tone = (int)substr($pinyin, -1, 1);
      if ($tone > 0 && $tone < 6) {
        $pinyin = substr($pinyin, 0, -1);

        if ($tone < 5) {
          $toConvertPosition = stripos($pinyin, 'a') ? : stripos($pinyin, 'e') ? : stripos($pinyin, 'ou');

          if ($toConvertPosition === false) {
            for ($i = strlen($pinyin); $i >= 0; $i--) {
              if (in_array(substr($pinyin, $i, 1), $vowels)) {
                $toConvertPosition = $i;
                break;
              }
            }
          }

          if ($toConvertPosition !== false) {
            if (substr($pinyin, $toConvertPosition+1, 1) == ":") {
              $toConvert = substr($pinyin, $toConvertPosition, 2);
            } else {
              $toConvert = substr($pinyin, $toConvertPosition, 1);
            }
            $returnPinyins[] = str_replace($toConvert, $conversion[$tone][$toConvert], $pinyin);
          } else {
            $returnPinyins[] = $pinyin;
          }

        } else {
          $returnPinyins[] = str_replace(['u:', 'U:'], ['ü', 'Ü'], $pinyin);
        }

      } else {
        $returnPinyins[] = $pinyin;
      }

    }
    $returnPinyins0[] = implode('', $returnPinyins);

  }
  return implode(' ', $returnPinyins0);
}
?>