'use strict';
let mark = {
 init:function() {
   for(let key in db_list) if(db_list[key].use) mark.dell[key] = [];
 },

 showflag:false,
 show:function() {
   mark.showflag = true;
   mark.pview();
 },

 hide:function() {
   mark.showflag = false;
   let c = 0;
   for(let db in mark.dell) if(+mark.dell[db].length > 0) c = +c + +mark.dell[db].length;
   if(+c == 0) return;
   ok.cancel('Подтвердите удаление выбранных заметок', function(r) {
     if(r) {
       mark.pactdell(function() {
         if(crstack != 0) search.pcacheout(...rbackstack[crstack - 1]);
       });
     } else for(let db in mark.dell) mark.dell[db].length = 0;
   }, undefined, ok.txtbut('delete'));
 },

 pview:function(db, page = 1) {
   istorage.getItem('mar', function(val, db, page) {
     mark.view(db, page, val);
   }, undefined, db, page);
 },

 view:function(db, page = 1, jms) {
   let mar = JSON.parse(jms);
   let rl = [], su = 0, ssff = false;
   for(let key in mar) {
     if(mar[key].length != 0) {
       let dis = '';
       if(!db_list[key].use) dis = 'disabled';
       if(ssff === false && dis === '') ssff = key;
       rl.push([dis, '', key, db_list[key].name]);
       su = +su + +mar[key].length;
   } }
   displaybox_mar_id.innerHTML = '';
   if(+su == 0) {
     statmbox_id.innerHTML = 'Заметок нет';
     return;
   } else {
     statmbox_id.innerHTML = `${su} (${+perc(+blen(jms),+mark.lslimit).toFixed(2)}%)`;
   }
   let res = '';

   displaybox_mar_id.innerHTML += `<table id="marksinf_id" data-db="" data-page="${page}"><tbody>
     <tr><td id="mi1_id"></td></tr>
     <tr><td id="mi2_id"></td></tr>
   </tbody></table><hr>`;

   let mlc = ''; if(rl.length > 1) mlc = 'mlist';
   mi1_id.innerHTML = `<button class="${mlc}" id="seldbmarklist_id" data-xval="" onclick="mark.seldb();"></button>`;
   if(db === undefined) {
     if(ssff === false) db = rl[0][2];
     else db = ssff;
   }
   seldbmarklist_id.dataset.xval = marksinf_id.dataset.db = db;
   ok.delay = true;
   mark.seldb = ok.rlist('seldbmarklist_id', rl, function(id, val) {
     if(id !== false) mark.pview(val);
   });

   if(ssff === false) return;

   let pag = +Math.trunc(mar[db].length/setting.cline);
   if(mar[db].length%setting.cline != 0) ++pag;
   let s_pag = (page-1)*setting.cline;
   let f_pag = 0;
   if(+(+s_pag + +setting.cline) >= +mar[db].length) f_pag = mar[db].length;
   else f_pag = +s_pag + +setting.cline;
   
   if(+pag > 1) {
     let pl = [];
     for(let p = 1; p <= +pag; p++) pl.push(['','',+p,'Страница '+p]);
     let sp = +page;
     if(page == 1) sp = +pag;
     else --sp;
     mi2_id.innerHTML = `<button class="arrow_l" data-xval="" onclick="mark.pview('${db}',${sp});"></button>`;
     mi2_id.innerHTML += `<button class="mlist" id="selpagmark_id" data-xval="" onclick="mark.selpage();"></button>`;
     selpagmark_id.dataset.xval = page;
     ok.delay = true;
     mark.selpage = ok.rlist('selpagmark_id', pl, function(id, val, d) {
       if(id !== false) mark.pview(d, val);
     }, undefined, db);
     sp = +page;
     if(page == pag) sp = 1;
     else ++sp;
     mi2_id.innerHTML += `<button class="arrow_r" data-xval="" onclick="mark.pview('${db}',${sp});"></button>`;
   }

   let dbm; eval(`dbm=${db};`);
   res += `<table id="markviewtable_id"><tbody><tr><th class="emo">❌</th>`;
   let eol = {};
   for(let h = 0; h < db_list[db].columns.length; h++) {
     res += db_list[db].edithead(db_list[db].columns[h], h, eol, eog);
   }
   res += `</tr>`;
   for(let g = +s_pag; g < +f_pag; g++) {
     let ck = '';
     if(mark.dlhas(db,mar[db][g])) ck = ' checked';
     res += `<tr><td><label class="labelblock">&nbsp;<input type="checkbox" onchange="mark.dellist(this,'${db}',${+mar[db][g]});"${ck}/>&nbsp;</label></td>`;
     let eol = {};
     for(let s = 0; s < db_list[db].columns.length; s++) {
       let ddd = db_list[db].editfunc(dbm[mar[db][g]][s], s, false, mar[db][g], undefined, false, eol, eog);
       res += db_list[db].editfunc(ddd, s, false, mar[db][g], undefined, true, eol, eog);
     }
     res += `</tr>`;
   }
   res += `</tbody></table>`;
   
   if(+pag > 1) {
     let sp = +page;
     if(page == 1) sp = +pag;
     else --sp;
     res += `<hr><div class="markfootnavdiv"><button class="arrow_l" data-xval="" onclick="mark.pview('${db}',${sp});dsx.dispscroll();"></button>`;
     sp = +page;
     if(page == pag) sp = 1;
     else ++sp;
     res += `<button class="arrow_r" data-xval="" onclick="mark.pview('${db}',${sp});dsx.dispscroll();"></button></div>`;
   }
   
   displaybox_mar_id.innerHTML += res;
 },

 dell:{},
 dellist:function(t, db, id) {
   if(t.checked) {
     mark.dell[db].push(+id);
   } else {
     for(let i = 0; i < mark.dell[db].length; ) {
       if(+mark.dell[db][i] == +id) mark.dell[db].splice(i, 1);
       else ++i;
     }
   }
 },

 pactdell:function(cb = function() {}) {
   istorage.getItem('mar', function(val, cb) {
     mark.actdell(val);
     cb();
   }, undefined, cb);
 },

 actdell:function(jms) {
   let c = 0;
   for(let db in mark.dell) if(+mark.dell[db].length > 0) c = +c + +mark.dell[db].length;
   if(+c == 0) return;
   let mar = JSON.parse(jms);
   for(let db in mark.dell) {
     for(let i = 0; i < mark.dell[db].length; i++) {
       for(let w = 0; w < mar[db].length; ) {
         if(+mar[db][w] == +mark.dell[db][i]) mar[db].splice(w, 1);
         else ++w;
       }
     }
     mark.dell[db].length = 0;
   }
   istorage.setItem('mar', JSON.stringify(mar), function(c) {
     ok.autohide(1555, ok.ok(`Заметки удалены (${c})`, undefined, ''));
   }, undefined, c);
 },

 dlhas:function(db, id) {
   for(let i=0; i<mark.dell[db].length; i++) if(+mark.dell[db][i] == +id) return true;
   return false;
 },

 pact:function(t, db, id) {
   istorage.getItem('mar', function(val, t, db, id) {
     mark.act(t, db, id, val);
   }, undefined, t, db, id);
 },

 act:function(t, db, id, jms) {
   if(t.checked) mark.add(db, id, jms);
   else mark.del(db, id, jms);
 },

 lslimit:500000,
 add:function(db, id, jms0) {
   let mar = JSON.parse(jms0);
   for(let i = 0; i < mar[db].length; ) {
     if(+mar[db][i] == +id) mar[db].splice(i, 1);
     else ++i;
   }
   mar[db].unshift(+id);
   let jms = JSON.stringify(mar);
   if(+blen(jms) > +mark.lslimit) {
     for(let key in mar) {
       let mle = mar[key].length;
       let m2 = +cper(mle, 2).toFixed(0); //2%del
       if(+m2 > 0) mar[key].splice(mle - m2, m2);
     }
     jms = JSON.stringify(mar);
   }
   istorage.setItem('mar', jms);
 },

 del:function(db, id, jms0) {
   let mar = JSON.parse(jms0);
   for(let i = 0; i < mar[db].length; ) {
     if(+mar[db][i] == +id) mar[db].splice(i, 1);
     else ++i;
   }
   istorage.setItem('mar', JSON.stringify(mar));
 },


};
