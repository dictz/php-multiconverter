'use strict';
let dsxidbx = {};
let dpfx = 'dpfx_';
let dsxidb;

let istorage = {
 setItem:function(item, x_data, cbt = function(){}, cbf = cbt, ...args) {
   let th;
   try {
     dsxidbx[item] = x_data;
     th = dsxidb.transaction(dsx_dict_id, 'readwrite');
     th.oncomplete = function() {};
     th.onabort = function() {cbf(...args);};

     let obje = {};
     obje[dpfx + item] = dpfx + item;
     obje[item] = x_data;

     let treq = th.objectStore(dsx_dict_id).put(obje, dpfx + item);
     treq.onsuccess = function() {cbt(...args);};
     treq.onerror = function() {cbf(...args);};
   } catch(er) {cbf(...args);}
 },

 getItem:function(item, cbt, cbf = cbt, ...args) {
   let th;
   let datax;
   try {
     try {datax = dsxidbx[item];} catch(er) {}
     th = dsxidb.transaction(dsx_dict_id, 'readonly');
     th.oncomplete = function() {};
     th.onabort = function() {cbf(datax, ...args);};

     let treq = th.objectStore(dsx_dict_id).get(dpfx + item);
     treq.onsuccess = function(event) {
       try {
         let etr = dsxidbx[item] = event.target.result[item];
         cbt(etr, ...args);
       } catch(er) {
         cbf(datax, ...args);
       }
     };
     treq.onerror = function() {
       try {
         cbf(datax, ...args);
       } catch(er) {
         cbf(datax, ...args);
       }
     };
   } catch(er) {cbf(datax, ...args);}
 },

 removeItem:function(item, cbt = function(){}, cbf = cbt, ...args) {
   let th;
   try {
     delete dsxidbx[item];

     th = dsxidb.transaction(dsx_dict_id, 'readwrite');
     th.oncomplete = function() {};
     th.onabort = function() {cbf(...args);};

     let treq = th.objectStore(dsx_dict_id).delete(dpfx + item);
     treq.onsuccess = function() {cbt(...args);};
     treq.onerror = function() {cbf(...args);};
   } catch(er) {cbf(...args);}
 },

 clear:function(cbt = function(){}, cbf = cbt, ...args) {
   let th;
   try {
     dsxidbx = {};

     th = dsxidb.transaction(dsx_dict_id, 'readwrite');
     th.oncomplete = function() {};
     th.onabort = function() {cbf(...args);};

     let treq = th.objectStore(dsx_dict_id).clear();
     treq.onsuccess = function() {cbt(...args);};
     treq.onerror = function() {cbf(...args);};
   } catch(er) {cbf(...args);}
 },
};

try {

  let idbRequest = window.indexedDB.open(`HTML_${dsx_dict_id}`, 1);
  idbRequest.onupgradeneeded = function() {
    dsxidb = idbRequest.result;
    if(!dsxidb.objectStoreNames.contains(dsx_dict_id)) dsxidb.createObjectStore(dsx_dict_id);
  };
  idbRequest.onerror = function(event) {
    //idbRequest.error
  };
  idbRequest.onsuccess = function() {
    dsxidb = idbRequest.result;
    dsxidb.onversionchange = function() {
      //dsxidb.close();
    };
    dsxidb.onerror = function(event) {
      //event.target.error
    };
    istorage.getItem('dsx_vx', function(val) {
      if(val == dsx_vx) {
      } else {
        istorage.clear();
        istorage.setItem('dsx_vx', dsx_vx);
      }
    }, function() {
      istorage.clear();
      istorage.setItem('dsx_vx', dsx_vx);
    });
  };
  idbRequest.onblocked = function() {};

} catch(er) {}
