'use strict';
let keyboard = {
 curthis:0,
 curposc:0,
 init:function() {},

 updtxa:function(t) {
   keyboard.curthis = t;
   keyboard.curposc = dsx.convpos(t);
   dsx.inptxtwupd(t);
 },

 onoffkb:function(f = 'false') {
   if(f === 'true') {
     if(cur_kblist != 0) keyboard.showkeys();
     else keyboard.showlist();
     keyboardbox_id.style.display = '';
     lefttop_id.style.display = 'none';
     keyboardbox_id.style.top = headpanel_id.offsetHeight + 'px';
   } else keyboardbox_id.style.display = 'none';
 },

 sset:function(t, e) {
   let s = t.selectionStart = t.selectionEnd;
   let d = t.value;
   t.value = kbchars = d.replace(/[ \t]{1,}/gu,' ').replace(/(\n \n)/gu,'\n\n').replace(/(\n )/gu,'\n').replace(/\n{5,}/gu,'\n\n\n\n').replace(/\n{3,}(?=$)/u,'\n\n').replace(/(?<=^)\n{2,}/u,'\n').replace(/(u\{)([^\{\}\n]+)(\})/gu, function(match, p1, p2, p3) {
     p2 = p2.replace(/[^,0123456789abcdef]/gui, '').replace(/[,]{2,}/gu, ',').replace(/(?<=^)[,]/gu, '').replace(/(?<=(^|,))([^,]+)(?=($|,))/gu, function(match) {
       if(match.length > 6) match = match.slice(0, 6);
       return match;
     }).toLowerCase();
     return `${p1}${p2}${p3}`;
   }).replace(/(?<=^).*n\{(.+)\}.*(?=$)/gum, function(match, p1) {
     p1 = p1.replace(/[\{\}]/gu, '');
     if(p1.length > 55) p1 = p1.slice(0, 55);
     return `n{${p1}}`;
   }).replace(/(?<=^).*c\{([^ \n]+)\+([^ \n]+)_([^ \n]+)\}.*(?=$)/gum, function(match, p1, p2, p3) {
     p1 = p1.replace(/[^0123456789abcdef]/gui, '');
     p2 = p2.replace(/[^123456789]/gu, '');
     p3 = p3.replace(/[^,0123456789]/gu, '').replace(/[,]{2,}/gu, ',').replace(/(?<=^)[,]/gu, '').replace(/(?<=(^|,))([^,]+)(?=($|,))/gu, function(match) {
       if(match.length > 2) match = match.slice(0, 2);
       return match;
     });
     if(p1.length > 6) p1 = p1.slice(0, 6);
     if(p2.length > 1) p2 = p2.slice(0, 1);
     return `c{${p1}+${p2}_${p3}}`;
   }).replace(/(?<=^).{100,}(?=$)/gum, function(match) {
     if(symc(match, ' ') >= 100) match = match.split(' ').slice(0, 100).join(' ');
     return match;
   });
   if(d.length - kbchars.length > 0) s = s - 1;
   t.selectionStart = t.selectionEnd = s;
   keyboard.cset(1);
   keyboard.showlist();
   istorage.setItem('kbchars', kbchars);
 },

 cset:function(id) {
   cur_kblist = +id;
   istorage.setItem('cur_kblist', cur_kblist);
 },

 showlist:function() {
   let ht = keyboard.pars();
   if(ht == '') keyboard.cset(0);
   keyboardboxl_id.innerHTML = ht;
 },

 showkeys:function() {
   let ht = keyboard.pars(cur_kblist);
   ht += `<button onclick="keyboard.onoffkb();" class="emo">❌</button><button onclick="keyboard.showlist();">Наборы</button><button class="wingding" onclick="keyboard.chardel();">&nbsp;&nbsp;&#x2019;&nbsp;&nbsp;</button>`;
   ht += keyboard.pars(0);
   keyboardboxl_id.innerHTML = ht;
 },

 upars:function(s) {
   return s.replace(/u\{([^\{\}\n]+)\}/gu, function(match, p1) {
     let ar = p1.replace(/[,](?=$)/gu, '').split(',');
     return ar.map(function(item) {
       if(item.split(/[^0123456789abcdef]/i).length > 1) return '';
       return String.fromCodePoint(Number('0x' + item));
     }).join('');
   });
 },

 cpars:function(s) {
   return s.replace(/(?<=^).*c\{([^ \n]+)\+([^ \n]+)_([^ \n]+)\}.*(?=$)/gum, function(match, p1, p2, p3) {
     let n = Number('0x' + p1), ar = [], ar2 = p3.replace(/[,](?=$)/gu, '').split(',');
     p2 = +p2;
     for(let i = 0; i < ar2.length; i++) {
       let ii = n;
       for(; ii <= (+n + +ar2[i]*p2); ii = +ii + +p2) {
         let aw = `u{${ii.toString(16).toLowerCase()}}`;
         if(ii == (+n + +ar2[i]*p2) && i != ar2.length - 1) ar.push(`${aw}\n`);
         else ar.push(aw);
       }
       n = ii;
     }
     return ar.join(' ');
   });
 },

 pars:function(id) {
   let ht = '', na = [];
   let kar = kbchars.split(/[\n]{2,}/gu);
   for(let i = 1; i < kar.length; i++) {
     let kar2 = kar[i].trim().split(/\n/gu);
     kar2[0] = kar2[0].trim().replace(/(?<=^).*n\{(.+)\}.*(?=$)/gu, function(match, p1) {
       p1 = p1.replace(/[\{\}]/gu, '');
       na[i - 1] = p1;
       return '';
     }).trim();
     kar[i] = kar2.join('\n').trim();
   }
   if(id === undefined) {
     for(let i = 1; i < kar.length; i++) {
       if(kar[i].length == 0) continue;
       let ch = '', ks = '';
       if(i == cur_kblist) ch = ' checked';
       if(na[i - 1] !== undefined) ks = na[i - 1];
       else ks = keyboard.upars(keyboard.cpars(kar[i]).replace(/\n/gu, ' ')).trim();
       ht += `<label><input type="radio" name="selkblist" onclick="keyboard.cset(${i});keyboard.showkeys();"${ch}/>&nbsp;${dsx.tomnemonics(ks)}&nbsp;</label><br>`;
     }
   } else if(typeof(+id) == 'number') {
     let kar2 = keyboard.cpars(kar[+id]).trim().split(/\n/gu);
     for(let i = 0; i < kar2.length; i++) {
       let lar = kar2[i].trim().split(/[\s]{1,}/gu);
       for(let s = 0; s < lar.length; s++) {
         let ss = keyboard.upars(lar[s]);
         ht += `<button onclick="keyboard.charinp('${b64e(ss)}');">&nbsp;${dsx.tomnemonics(ss)}&nbsp;</button>`;
       }
       ht += '<br>';
     }
   }
   return ht;
 },

 charinp:function(sb64) {
   let s = b64d(sb64);
   dsx.setRangeTextU(keyboard.curthis, s, keyboard.curposc, keyboard.curposc);
   keyboard.curposc = +keyboard.curposc + +ulen(s);
   dsx.selectionU(keyboard.curthis, keyboard.curposc);
   dsx.inptxtwupd(keyboard.curthis);
 },

 chardel:function() {
   if(+keyboard.curposc > 0) {
     dsx.setRangeTextU(keyboard.curthis, '', +keyboard.curposc - 1, keyboard.curposc);
     --keyboard.curposc;
     dsx.selectionU(keyboard.curthis, keyboard.curposc);
     dsx.inptxtwupd(keyboard.curthis);
   }
 },

};
