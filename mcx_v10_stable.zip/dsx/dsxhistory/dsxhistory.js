'use strict';

let dsxhistory = {
 showflag:false,
 show:function() {
   dsxhistory.showflag = true;
   dsxhistory.pview();
 },

 hide:function() {
   dsxhistory.showflag = false;
   if(dsxhistory.dell.length == 0) return;
   ok.cancel('Подтвердите удаление в истории', function(r) {
     if(r) dsxhistory.pactdell();
     else dsxhistory.dell.length = 0;
   }, undefined, ok.txtbut('delete'));
 },

 search:function(sids64) {
   let schdobj = JSON.parse(b64d(sids64));
   let si = JSON.parse(schdobj.sid);
   let rs = '';
   if(si[0][3].includes('txt') || si[0][3].includes('reg')) if(si[0][1].length != 0) rs += si[0][1] + '\n' + si[0][2];
   if(rs.length != 0) rs += '\n\n';
   rs += si[0][3];
   if(si[0][4].length != 0) rs += '\n\n' + si[0][4];
   if(si[0][5].length != 0) rs += '\n\n' + si[0][5];
   ok.constr(`<textarea cols="30" rows="11" style="white-space:pre;" readonly>${dsx.tomnemonics(rs)}</textarea>`, `
     <button onclick="ok.hide();">${ok.txtbut('close')}</button>
     <button onclick="ok.dig('find');" style="display:none;" id="histfindlgbut_id">Повторить поиск</button>
   `, function(s64, m) {
     if(m == 'htset') {
       let sch = JSON.parse(b64d(s64));
       let si = JSON.parse(sch.sid);
       for(let i = 1; i < si.length; i++) {
         if(db_list[si[i][0]].use && sch[si[i][0]]) {
           histfindlgbut_id.style.display = '';
           break;
         }
       }
     } else if(m == 'find') {
       search.okstart(b64d(s64), 'old');
       return;
     }
     return false;
   }, sids64);
 },

 pview:function(page = 1) {
   istorage.getItem('hist', function(val, page) {
     dsxhistory.view(page, val);
   }, undefined, page);
 },

 view:function(page, jhs) {
   let hist = JSON.parse(jhs);
   displaybox_his_id.innerHTML = '';
   if(hist.length == 0) {
     stathbox_id.innerHTML = 'История пуста';
     return;
   } else {
     stathbox_id.innerHTML = `${hist.length} (${+perc(+blen(jhs),+dsxhistory.lslimit).toFixed(2)}%)`;
   }
   let res = '';

   let pag = +Math.trunc(hist.length/setting.cline);
   if(hist.length%setting.cline != 0) ++pag;
   let s_pag = (page-1)*setting.cline;
   let f_pag = 0;
   if(+(+s_pag + +setting.cline) >= +hist.length) f_pag = hist.length;
   else f_pag = +s_pag + +setting.cline;
   
   if(+pag > 1) {
     let pl = [];
     for(let p = 1; p <= +pag; p++) pl.push(['','',+p,'Страница '+p]);
     let sp = page;
     if(+page == 1) sp = pag;
     else --sp;
     displaybox_his_id.innerHTML += `<div id="historypages_id"></div><hr>`;
     historypages_id.innerHTML += `<button class="arrow_l" data-xval="" onclick="dsxhistory.pview(${sp});"></button>`;
     historypages_id.innerHTML += `<button class="mlist" id="historyselpagres_id" data-xval="" onclick="dsxhistory.selpage();"></button>`;
     historyselpagres_id.dataset.xval = page;
     ok.delay = true;
     dsxhistory.selpage = ok.rlist('historyselpagres_id', pl, function(id, val) {
       if(id !== false) dsxhistory.pview(val);
     });
     sp = page;
     if(+page == +pag) sp = 1;
     else ++sp;
     historypages_id.innerHTML += `<button class="arrow_r" data-xval="" onclick="dsxhistory.pview(${sp});"></button>`;
   }

   res += `<table id="historyrestable_id"><tbody>`;
   res += `<tr><th class="emo">❌</th><th>Схема поиска</th><th>Карта поиска</th></tr>`;
   for(let g = +s_pag; g < +f_pag; g++) {
     let ck = '';
     if(dsxhistory.dlhas(b64e(hist[g]))) ck = ' checked';
     let schdobj = JSON.parse(hist[g]);
     let si = JSON.parse(schdobj.sid);
     let ca = '';
     if(schdobj.sid in searchcache) ca = ' class="incache"';
     res += `<tr><td${ca}><label class="labelblock">&nbsp;<input type="checkbox" onchange="dsxhistory.dellist(this,'${b64e(hist[g])}');"${ck}/>&nbsp;</label></td><td onclick="dsxhistory.search('${b64e(hist[g])}');">${dsx.tomnemonics(si[0][0])}<br>«${dsx.tomnemonics(schdobj.sscsheme_name)}»<br>${schdobj.search_time}<br>Подробнее...</td>`;
     let ts = '';
     for(let i = 1; i < si.length; i++) {
       if(!si[i][1]) continue;
       let dbnl = '', rtm = '(–) ';
       if(!db_list[si[i][0]].use) dbnl = ' class="disabledtext"';
       if(schdobj[si[i][0]]) rtm = '(+) ';
       ts += `<span${dbnl}>${rtm}<b>${db_list[si[i][0]].short_name}</b>;<br>`;
       for(let h = 2; h < si[i].length; h++) {
         if(!si[i][h]) continue;
         ts += `• ${db_list[si[i][0]].columns[h-2]}<br>`;
       }
       ts += `</span>`;
     }
     res += `<td>${ts}</td></tr>`;
   }
   res += `</tbody></table>`;
   
   if(+pag > 1) {
     let sp = page;
     if(+page == 1) sp = pag;
     else --sp;
     res += `<hr><div class="histfootnavdiv"><button class="arrow_l" data-xval="" onclick="dsxhistory.pview(${sp});dsx.dispscroll();"></button>`;
     sp = page;
     if(+page == +pag) sp = 1;
     else ++sp;
     res += `<button class="arrow_r" data-xval="" onclick="dsxhistory.pview(${sp});dsx.dispscroll();"></button></div>`;
   }
   
   displaybox_his_id.innerHTML += res;
 },

 dell:[],
 dellist:function(t, sids64) {
   let sids = b64d(sids64);
   if(t.checked) {
     dsxhistory.dell.push(sids);
   } else {
     for(let i = 0; i < dsxhistory.dell.length; ) {
       if(dsxhistory.dell[i] === sids) dsxhistory.dell.splice(i, 1);
       else ++i;
     }
   }
 },

 pactdell:function() {
   istorage.getItem('hist', function(val) {
     dsxhistory.actdell(val);
   });
 },

 actdell:function(jhs) {
   let c = +dsxhistory.dell.length;
   if(+c == 0) return;
   let hist = JSON.parse(jhs);
   for(let i = 0; i < dsxhistory.dell.length; i++) {
     for(let w = 0; w < hist.length; ) {
       if(hist[w] === dsxhistory.dell[i]) hist.splice(w, 1);
       else ++w;
     }
   }
   dsxhistory.dell.length = 0;
   istorage.setItem('hist', JSON.stringify(hist), function(c) {
     ok.autohide(1555, ok.ok(`Удалено (${c})`, undefined, ''));
   }, undefined, c);
 },

 dlhas:function(sids64) {
   let sids = b64d(sids64);
   for(let i = 0; i < dsxhistory.dell.length; i++) if(dsxhistory.dell[i] === sids) return true;
   return false;
 },

 pinp:function(sids, onz = 'new') {
   istorage.getItem('hist', function(val, sids, onz) {
     dsxhistory.inp(sids, onz, val);
   }, undefined, sids, onz);
 },

 lslimit:1000000,
 inp:function(sids, onz, jhs0) {
   let hist = JSON.parse(jhs0);
   let stp;
   for(let i = 0; i < hist.length; ) {
     if(JSON.parse(hist[i]).sid === JSON.parse(sids).sid) {
       stp = hist[i];
       hist.splice(i, 1);
     } else ++i;
   }
   if(onz == 'new') hist.unshift(sids);
   else if(onz == 'old') hist.unshift(stp);

   let jhs = JSON.stringify(hist);
   if(+blen(jhs) > +dsxhistory.lslimit) {
     let hle = hist.length;
     let h5 = +cper(hle, 5).toFixed(0); //5%del
     if(+h5 > 0) {
       hist.splice(hle - h5, h5);
       jhs = JSON.stringify(hist);
   } }
   istorage.setItem('hist', jhs);
 },

};
