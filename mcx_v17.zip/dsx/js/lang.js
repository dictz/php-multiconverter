'use strict';
let langstr = {
  dsx_langcode    :['english-USA' ,'russian-RF' ,],
  dsx_langname    :['English'     ,'Русский'    ,],
  dsx_direction   :['ltr'         ,'ltr'        ,],
  dsx_trnsltauthor:['–'           ,'dictz'      ,],

  ht_title    :['Loading...'             ,'Загрузка...'                 ,],
  ht_loading  :['Loading'                ,'Загрузка'                    ,],
  ht_minute   :[', wait a minute'        ,', минутку'                   ,],
  ht_wait     :[', wait'                 ,', подождите'                 ,],
  ht_error    :['Error'                  ,'Ошибка'                      ,],
  ht_sear_his :['Search history'         ,'История поиска'              ,],
  ht_marks    :['Marks'                  ,'Заметки'                     ,],
  ht_settings :['Settings'               ,'Настройки'                   ,],
  ht_presets  :['Presettings'            ,'Преднастройки'               ,],
  ht_toexit   :['To exit, close the tab' ,'Для выхода закройте вкладку' ,],
  ht_s        :['s'                      ,'с'                           ,],
  ht_emp      :['Emptily'                ,'Пусто'                       ,],
  ht_print    :['Print | Save PDF'       ,'Печать | Сохранить PDF'      ,],
  ht_savtext  :['Save text (UTF-8)'      ,'Сохранить текст (UTF-8)'     ,],
  ht_savhtml  :['Save HTML'              ,'Сохранить HTML'              ,],
  ht_version  :['Version:'               ,'Версия:'                     ,],
  ht_translat :['Translated:'            ,'Переведено:'                 ,],
  ht_mcxgithub:['Converter:'             ,'Конвертер:'                  ,],

  cmd_exe     :['Executes. Expect results.' ,'Выполняется. Ожидайте результата.' ,],
  cmd_symcach :['Symbols must be cached'    ,'Необходимо кешировать символы'     ,],
  cmd_cachear :['Cached earlier'            ,'Кешировано ранее'                  ,],
  cmd_miss    :['Missing'                   ,'Отсутствует'                       ,],
  cmd_done    :['Done'                      ,'Выполнено'                         ,],
  cmd_stsave  :['Save ?'                    ,'Сохранить ?'                       ,],
  cmd_funclist:['Function list'             ,'Список функций'                    ,],

  his_confdel :['Confirm the deletion in the search history' ,'Подтвердите удаление в истории поиска'  ,],
  his_repsea  :['Repeat search'             ,'Повторить поиск'                   ,],
  his_storyemp:['The story is empty'        ,'История пуста'                     ,],
  his_page    :['Page'                      ,'Страница'                          ,],
  his_seasch  :['Search scheme'             ,'Схема поиска'                      ,],
  his_seamap  :['Search map'                ,'Карта поиска'                      ,],
  his_more    :['More...'                   ,'Подробнее...'                      ,],
  his_removed :['Removed'                   ,'Удалено'                           ,],

  mar_confdel :['Confirm the deletion of the selected marks' ,'Подтвердите удаление выбранных заметок' ,],
  mar_nomarks :['No marks'                  ,'Заметок нет'                       ,],
  mar_page    :['Page'                      ,'Страница'                          ,],
  mar_removed :['Marks removed'             ,'Заметки удалены'                   ,],

  ok_closeall :['Close all ?' ,'Закрыть всё ?' ,],
  ok_yes      :['Yes'         ,'Да'            ,],
  ok_ok       :['Ok'          ,'Ок'            ,],
  ok_next     :['Next'        ,'Далее'         ,],
  ok_back     :['Back'        ,'Назад'         ,],
  ok_run      :['Run'         ,'Выполнить'     ,],
  ok_cancel   :['Cancel'      ,'Отмена'        ,],
  ok_filter   :['...'         ,'...'           ,],
  ok_close    :['Close'       ,'Закрыть'       ,],
  ok_open     :['Open'        ,'Открыть'       ,],
  ok_save     :['Save'        ,'Сохранить'     ,],
  ok_continue :['Continue'    ,'Продолжить'    ,],
  ok_repeat   :['Repeat'      ,'Повторить'     ,],
  ok_apply    :['Apply'       ,'Применить'     ,],
  ok_delete   :['Delete'      ,'Удалить'       ,],
  ok_selected :['Selected:'   ,'Выбрано:'      ,],
  ok_emp      :['Emptily'     ,'Пусто'         ,],

  sea_search  :['Search'                     ,'Поиск'                            ,],
  sea_complin :['Completed in'               ,'Выполнено за'                     ,],
  sea_s       :['s'                          ,'с'                                ,],
  sea_noresult:['No result'                  ,'Безрезультатно'                   ,],
  sea_error   :['Error'                      ,'Ошибка'                           ,],
  sea_errexe  :['Execution error'            ,'Ошибка выполнения'                ,],
  sea_erfunsea:['Search function error'      ,'Ошибка функции поиска'            ,],
  sea_navi    :['Navigation'                 ,'Навигация'                        ,],
  sea_seasch  :['Search scheme'              ,'Схема поиска'                     ,],
  sea_seamap  :['Search map'                 ,'Карта поиска'                     ,],
  sea_more    :['More...'                    ,'Подробнее...'                     ,],
  sea_page    :['Page'                       ,'Страница'                         ,],
  sea_alotofpg:['A lot of pages'             ,'Очень много страниц'              ,],
  sea_ofunerr :['Output function error'      ,'Ошибка функции вывода'            ,],
  sea_inprocer:['Input processing error'     ,'Ошибка обработки ввода'           ,],
  sea_inspomi :['Insertion point missing'    ,'Отсутствует точка ввода'          ,],
  sea_misregex:['Missing regular expression' ,'Отсутствует регулярное выражение' ,],
  sea_regexerr:['Regular expression error'   ,'Ошибка регулярного выражения'     ,],

  tts_nofovoi :['No voices found to speak the text' ,'Не найдены голоса для озвучивания текста' ,],
  tts_voice   :['Voice'                             ,'Озвучить'                                 ,],
  tts_stop    :['Stop'                              ,'Стоп'                                     ,],
  tts_unkerr  :['Unknown error. Try again'          ,'Неизвестная ошибка. Попробуйте снова'     ,],
  tts_prnotres:['The problem is not resolved'       ,'Проблема не устранена'                    ,],
  tts_lang    :['Languages'                         ,'Языки'                                    ,],
  tts_voitone :['Voice tone'                        ,'Тон'                                      ,],
  tts_voispeed:['Voicing speed'                     ,'Скорость'                                 ,],
  tts_setchdef:['Default marks are set'             ,'Установлены отметки по умолчанию'         ,],

  set_seaset  :['Search settings'          ,'Настройки поиска'              ,],
  set_chandinp:['Characters and input'     ,'Символы и ввод'                ,],
  set_othsets :['Other settings'           ,'Другие настройки'              ,],
  set_info    :['Information'              ,'Информация'                    ,],
  set_inpchar :['Input characters'         ,'Ввод'                          ,],
  set_charkeys:['Character keys:'          ,'Наборы для ввода:'             ,],
  set_useinp  :['Use character input'      ,'Использовать ввод'             ,],
  set_cachprog:['Caching in progress (up to 3 minutes)' ,'Выполняется кеширование (до 3 минут)' ,],
  set_inexssc :['Advanced search schemes available, install? Previous schemes will not be available; install manually:' ,'Доступны расширенные схемы поиска, установить? Прежние схемы будут недоступны; установка вручную:' ,],
  set_sscinst :['Search schemes installed' ,'Схемы установлены'             ,],
  set_showsym :['Show symbols'             ,'Показать символы'              ,],
  set_viewsym :['View symbols'             ,'Просмотр символов'             ,],
  set_page    :['Page'                     ,'Стр.'                          ,],
  set_homogl  :['Homoglyphs'               ,'Омоглифы'                      ,],
  set_homedit :['Edit'                     ,'Редактировать'                 ,],
  set_notsaved:['Not saved.'               ,'Не сохранено.'                 ,],
  set_fieldemp:['(the field is empty)'     ,'(в поле пусто)'                ,],
  set_seamap  :['Search map'               ,'Карта поиска'                  ,],
  set_error   :['Error'                    ,'Ошибка'                        ,],
  set_accancel:['Action canceled. One array or part of it is required' ,'Действие отменено. Необходим хотя бы один массив или его часть' ,],
  set_seasch  :['Search scheme'            ,'Схема поиска'                  ,],
  set_copied  :['Copied'                   ,'Скопировано'                   ,],
  set_ncopied :['Not copied'               ,'Не скопировано'                ,],
  set_copy    :['Copy'                     ,'Копировать'                    ,],
  set_impplhol:['...'                      ,'...'                           ,],
  set_notimp  :['Not imported.'            ,'Не импортировано.'             ,],
  set_import  :['Import'                   ,'Импортировать'                 ,],
  set_delschem:['Delete the scheme?'       ,'Удалить схему?'                ,],
  set_name    :['Name'                     ,'Имя'                           ,],
  set_scheme  :['Scheme'                   ,'Схема'                         ,],
  set_regexp  :['Regular expression'       ,'Регулярное выражение'          ,],
  set_function:['Function'                 ,'Функция'                       ,],
  set_inphand :['Input handler'            ,'Обработчик ввода'              ,],
  set_toexe   :['To execute'               ,'Выполнить'                     ,],
  set_colorman:['Color management'         ,'Управление цветом'             ,],
  set_clrauto :['Automatically (may not be supported)' ,'Автоматически (может не поддерживаться)' ,],
  set_clrremem:['Remember the choise'      ,'Запоминать выбор'              ,],
  set_linespag:['Lines per page'           ,'Строк на странице'             ,],
  set_fontsize:['Font size'                ,'Размер шрифта'                 ,],
  set_resetset:['Reset settings'           ,'Сброс настроек'                ,],
  set_reset   :['Reset'                    ,'Сбросить'                      ,],
  set_doneres :['Done. Restart html'       ,'Выполнено. Перезапустите html' ,],
  set_resconti:['This will reset your settings to default and clear your history and marks. Continue?' ,'Будут установлены настройки по умолчанию, очищены история и заметки. Продолжить?' ,],

  ssc_txt1    :['Text (A=a, é=e)'                                ,'Текст (А=а, е́=е)'                          ,],
  ssc_txt2    :['Text (A=a, é=e, 0=O)'                           ,'Текст (А=а, е́=е, 0=O)'                     ,],
  ssc_txt3    :['Text (case insensitive (A=a)'                   ,'Текст (не учитывая регистр (А=а)'          ,],
  ssc_txt4    :['Text (insensitive to combined characters (é=e)' ,'Текст (не уч. комбинируемые символы (е́=е)' ,],
  ssc_txt5    :['Text (insensitive to homoglyphs (0=O)'          ,'Текст (уч. омоглифы (0=O, r=г, б=6)'       ,],
  ssc_regex   :['Regular expression'                             ,'Регулярное выражение'                      ,],
  ssc_word1   :['^词Word'                                        ,'^词Слово (в начале строки)'                 ,],
  ssc_word2   :['~词Word'                                        ,'~词Слово (в начале строки)'                 ,],
  ssc_word3   :['Text at the beginning of a line'                ,'Текст в начале строки'                     ,],
  ssc_word4   :['Word'                                           ,'Слово'                                     ,],
  ssc_word5   :['At the beginning of a word'                     ,'В начале слова'                            ,],
  ssc_word6   :['At the end of the word'                         ,'В конце слова'                             ,],
  ssc_word7   :['At the end of the word (highlight the word)'    ,'В конце слова (выделить слово)'            ,],
  ssc_mixa1   :['Mixed alphabets (Cyr,Lat)'                      ,'Смешанные алфавиты (Cyr,Lat)'              ,],
  ssc_mixa2   :['Mixed alphabets (All)'                          ,'Смешанные алфавиты (All)'                  ,],
  ssc_stat1   :['STAT | At the end of words (in file)'           ,'STAT | В конце слов (в файл)'              ,],
  ssc_stat2   :['STAT | Save words to a file'                    ,'STAT | Сохранить слова в файл'             ,],
  ssc_stat3   :['STAT | All sc=Han to a file'                    ,'STAT | Все sc=Han в файл'                  ,],
};

let dsx_langc;
let rtl_f = false;

function xl_init(tx = dsx_langc) {
  for(let i = 0; i < langstr.dsx_langcode.length; i++) {
    if(langstr.dsx_langcode[i] == tx) {
      dsx_langc = i;
      return true;
    }
  }
  alert(`Error !\nLanguage «${tx}» not initialize.`);
  if(tx == 'english-USA') {
    dsx_langc = 'ERR';
    return false;
  }
  return xl_init('english-USA');
}

function xd_init() {
  if(dsx_langc === 'ERR') return;
  if(langstr.dsx_direction[dsx_langc] == 'rtl') {
    body_id.classList.add('rightleft');
    html_id.setAttribute('dir', 'rtl');
    rtl_f = true;
  }
}

function xl(tx) {
  if(dsx_langc === 'ERR') return dsx_langc;
  try {
    return langstr[tx][dsx_langc];
  } catch(er) {
    return 'ERR:' + tx;
  }
}
