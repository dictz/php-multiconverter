'use strict';
let symbols = {
 init:function() {},

 cachesymb:{},
 cs:function() {
   for(let db in db_list) {
     if(db_list[db].use) if(!(db in symbols.cachesymb)) symbols.cachesymb[db] = symbols.dictsymbstat(db, eval(db));
   }
   return symbols.cachesymb;
 },

 cacheconf:{},
 cc:function() {
   for(let db in db_list) {
     if(db_list[db].use) if(!(db in symbols.cacheconf)) symbols.cacheconf[db] = symbols.dictconfstat(db);
   }
   return symbols.cacheconf;
 },

 pvclear:function() {
   symbols.sob = {};
 },

 sob:{},
 dictsymbstat:function(db, tar) {
  symbols.sob[db] = {};
  for(let i = 0; i < tar.length; i++) {
    for(let ii = 0; ii < tar[i].length; ii++) {
      for(let match of tar[i][ii]) {
        let n = String(+match.codePointAt(0));
        if(n in symbols.sob[db]) ++symbols.sob[db][n];
        else symbols.sob[db][n] = 1;
      }
  } }

  let sar = [];
  for(let key in symbols.sob[db]) {//of for Set/Map
   sar.push(+key);
  }
  sar.sort(function(d, b) {
   if(d > b) return 1;
   if(d == b) return 0;
   if(d < b) return -1;
  });

  let sar2 = [];
  for(let i = 0; i < sar.length; i++) {
   if(sar2.length > 0) {
    if((sar[i] - (sar2[sar2.length-1][0] + sar2[sar2.length-1][1])) == 1) {
     ++sar2[sar2.length-1][1];
    } else {
     sar2.push([+sar[i],0]);
    }
   } else {
    sar2.push([+sar[i],0]);
   }
  }

  let sob2 = {};
  for(let i = 0; i < unicode_blocks.length; i++) {
   let mmin = +('0x' + unicode_blocks[i][0]);
   let mmax = +('0x' + unicode_blocks[i][1]);
   for(let ii = 0; ii < sar2.length; ii++) {
    let m1 = +sar2[ii][0];
    let m2 = +sar2[ii][0] + +sar2[ii][1];
    if(m1 >= mmin && m1 <= mmax && m2 >= mmin && m2 <= mmax) {
     if(!Reflect.has(sob2, unicode_blocks[i][2])) {
      eval(`sob2['${unicode_blocks[i][2]}'] = {block:'${unicode_blocks[i][0]}-${unicode_blocks[i][1]}',symbols:[]};`);
     }
     let sm = m1.toString(16).toUpperCase();
     if(m1 != m2) {
      sm += '-' + m2.toString(16).toUpperCase();
     }
     eval(`sob2['${unicode_blocks[i][2]}'].symbols.push(sm);`);
    }
  }}
  return JSON.parse(JSON.stringify(sob2));
 },

 dictconfstat:function(db) {
   let conf = [];
   for(let k = 0; k < confusables.length; k++) {
     let tmar = [];
     for(let e = 0; e < confusables[k].length; e++) {
       if(confusables[k][e].length == 1) {
         if((+('0x' + confusables[k][e][0])).toString() in symbols.sob[db]) tmar.push(confusables[k][e]);
       }
     }
     if(tmar.length > 1) conf.push(tmar);
   }
   return conf.slice();
 },

};