<?php
function txta_md($dafnam, $txa, $wcnt, $grn) {
  $txa = str_replace(["\r","\t"], ['',' '], $txa);

  $txar = preg_split('/\n\s/', $txa, 2, PREG_SPLIT_NO_EMPTY);
  if($dafnam == 'dabkrs' || $dafnam == 'dabkrss' || $grn == 'cdict') {
    if(count($txar) == 2) {
      $txar2 = preg_split('/\n/', $txar[1], 2, PREG_SPLIT_NO_EMPTY);
      $txa = str_replace("\n", '\\n', $txar[0])."\n".str_replace("\n", '\\n', $txar2[0])."\n".str_replace("\n", '\\n', $txar2[1]);
    } else {
      $txa = '@err'.$wcnt."\n".'_'."\n".str_replace("\n", '\\n', $txa);
    }
  } else if($dafnam == 'dabruks' || $dafnam == 'examples' || $grn == 'dsldict') {
    if(count($txar) == 2) {
      $txa = str_replace("\n", '\\n', $txar[0])."\n".str_replace("\n", '\\n', $txar[1]);
    } else {
      $txa = '@err'.$wcnt."\n".str_replace("\n", '\\n', $txa);
    }
  }

  if($dafnam == 'dabkrss') {
    if(preg_match("/\n[\s]*_[\s]*\n/", $txa) == 1) {
      return '';
    }
  }

  $txa = str_replace(['<','>'], ['&lt;','&gt;'], $txa);
  $txa = preg_replace('/(\[[\*]\]|\[\/[\*]\])/', ' ', $txa);
  if($GLOBALS['md_indent'] == 0) $txa = preg_replace('/(\[m[0-9]?\]|\[\/m\])/', ' \\n ', $txa);
  else $txa = preg_replace('/\[m[01]?\](.*?)\[\/m\]/', ' \\n $1 \\n ', $txa);
  $txa = preg_replace('/(\[b\][ ]*[IV]+[ ,])/', '\\n$1', $txa);
  $txa = preg_replace('/(\[b\][ ]*[IV]+[ ]*\[\/b\])/', '\\n$1', $txa);
  while(preg_match('/\\\\n[ ]*\\\\n/', $txa) == 1) {
    $txa = preg_replace('/\\\\n[ ]*\\\\n/', '\\n', $txa);
  }
  $txa = preg_replace('/[ ]{2,}/', ' ', $txa);
  $txa = preg_replace('/[ ]*\\\\n[ ]*/', '\\n', $txa);
  $txa = preg_replace('/(\\\\n| )*\n(\\\\n| )*/', "\n", $txa);
  $txa = preg_replace('/(\\\\n| )*$/', '', $txa);
  $txa = preg_replace('/^(\\\\n| )*/', '', $txa);
  $txa = preg_replace('/([\(\[])[ ]+/', '$1', $txa);
  $txa = preg_replace('/[ ]+([\)\]])/', '$1', $txa);
  if($dafnam == 'examples') {
    if(preg_match('/(\\\\n\\\\n.*)(\\\\n)+/', $txa) == 1) {
      $txa = str_replace('\\n\\n', '\\n', $txa);
    }
  }
  if($GLOBALS['md_indent'] > 0) {
    $txa = preg_replace_callback('/\[m(\d)\](.*?)\[\/m\]/', function($matches) {
      if(intval($matches[1]) < 2) return ' \\n '.$matches[2].' \\n ';
      return '<div style="padding-inline-start:'.((intval($matches[1])-1)*$GLOBALS['md_indent']).'px;">'.$matches[2].'</div>';
    }, $txa);
  }
  $txa = preg_replace('/\[([\/]?)(i|b|u|sub|sup)\]/', '<$1$2>', $txa);
  $txa = preg_replace('/\[c[^\[\]\\\\]*\]/', '<font class="p">', $txa);
  $txa = str_replace('[/c]', '</font>', $txa);
  $txa = str_replace('[p]', '<font class="p">', $txa);
  $txa = str_replace('[/p]', '</font>', $txa);
  $txa = str_replace('[ex]', '<font class="ex">• ', $txa);
  $txa = str_replace('[/ex]', '</font>', $txa);
  if($grn == '') $txa = preg_replace('/(?<=\[\/ref\])([\s\p{P}]*)(?=\[ref\])/u', '<br>$1', $txa);
  $txa = preg_replace('/\[ref\]([^\[\]]+)\[\/ref\]/', '<a href="entry://$1">$1</a>', $txa);
  $txa = preg_replace('/\\\\([\[\]])/', '$1', $txa);
  return str_replace('\\n', '<br>', $txa);
}

function convert_md($dadir, $dafnam, $profdicarr, $dictitle, $dicdescr, $dadate, $testfl, $grn = '') {
$md_dir = 'MDict';
if(!is_dir($md_dir)) mkdir($md_dir);
$ddir = $md_dir.'/'.str_replace('@', $dafnam, $GLOBALS['md_catname']);
if(is_dir($ddir)) rrmdir($ddir);
mkdir($ddir);

$fntmp = $ddir.'/~mdx.tmp';
$htmpwrite = fopen($fntmp, 'a');

$xaht = aht($GLOBALS['md_theme']);
$blcklim = 100;
$curoffset = 0;
$wordcount = 0;
$wordcountall = 0;
$tarr = array();
$meabytecount = 0;
$blockcount = 0;
$kinbcount = 0;
$iterbuff = '';
$pckszarr = array();
foreach ($profdicarr as $dakey => $val) {
  $fnamerd = $dadir;
  if($grn == '') {
    if($dakey == 'dabkrss') $fnamerd .= 'dabkrs_'.$dadate;
    else $fnamerd .= $dakey.'_'.$dadate;
  } else {
    $fnamerd .= $dakey;
  }
  $fp = @fopen($fnamerd, 'r');
  if(!$fp) return 'err:'.$fnamerd;
  $lbuf = '';
  $wordc = 1;
  fgsit($fp, $dakey);
  while (true) {
    $buffer = fgets($fp);
    if($buffer == "\r\n" || $buffer == "\n" || $buffer === false) {
      if($buffer === false && $lbuf == '') break;
      $lbuf = trim($lbuf);
      if($lbuf == '') continue;
      ++$wordcountall;
      $xtx = txta_md($dakey, $lbuf, $wordcountall, $grn);
      if($xtx == '') {
        $lbuf = '';
        continue;
      }
      $ard = explode("\n", $xtx);
      $ardk0 = str_replace(['&lt;','&gt;'], ['<','>'], $ard[0]);

      if($dakey == 'dabkrs' || $dakey == 'dabkrss' || $grn == 'cdict') {
        $ard[1] .= '<hr>'.$ard[2];
      }

      $ard[1] = $xaht.$ard[0].'<hr>'.$ard[1].$GLOBALS['md_addcontent']."\x00";
      $iterbuff .= $ard[1];
      $tarr[$curoffset] = $ardk0;
      $curoffset += strlen($ard[1]);
      ++$wordcount;
      ++$kinbcount;
      $lbuf = '';
      if($kinbcount == $blcklim) {
        fwrite($htmpwrite, "\x02\x00\x00\x00".hash('adler32', $iterbuff, true));
        $ktl = fwrite($htmpwrite, gzcompress($iterbuff, $GLOBALS['md_compress']));
        $pckszarr[] = array($ktl + 8, strlen($iterbuff));
        $meabytecount += $ktl + 8;
        $iterbuff = '';
        $kinbcount = 0;
        ++$blockcount;
      }
      if($testfl) {
        if($wordc >= $GLOBALS['tstnums']) break;
        else ++$wordc;
      }
    } else $lbuf .= $buffer;
  }
  fclose($fp);
}

if($iterbuff != '') {
  fwrite($htmpwrite, pack('V',2).hash('adler32', $iterbuff, true));
  $ktl = fwrite($htmpwrite, gzcompress($iterbuff, $GLOBALS['md_compress']));
  $pckszarr[] = array($ktl + 8, strlen($iterbuff));
  $meabytecount += $ktl + 8;
  $iterbuff = '';
  ++$blockcount;
}
fclose($htmpwrite);
uasort($tarr, 'ucmp');
$tarr = array_chunk($tarr, $blcklim, true);

$stbu = '';
$skbu = '';
foreach ($tarr as $key0 => $starr) {
  $kbu = '';
  $hadl = hash_init('adler32');
  foreach ($starr as $key => $val) {
    $ikey = "\x00\x00\x00\x00".pack('N',$key).$val."\x00";
    hash_update($hadl, $ikey);
    $kbu .= $ikey;
  }
  $szkb = strlen($kbu);
  $kbu = gzcompress($kbu, $GLOBALS['md_compress']);
  $szkbc = strlen($kbu) + 8;
  $skbu .= "\x02\x00\x00\x00".hash_final($hadl,true).$kbu;

  $lastkey = end($starr);
  $firstkey = reset($starr);
  $stbu .= "\x00\x00\x00\x00".pack('N',count($starr)).pack('n',strlen($firstkey)).$firstkey."\x00".pack('n',strlen($lastkey)).$lastkey."\x00\x00\x00\x00\x00".pack('N',$szkbc)."\x00\x00\x00\x00".pack('N',$szkb);
}
unset($tarr);
$adltbk = hash('adler32', $stbu, true);
$sztb = strlen($stbu);
$stbu = gzcompress($stbu, $GLOBALS['md_compress']);
$sztbc = strlen($stbu) + 8;

$fnmdx = $ddir.'/'.$dafnam.'.mdx';
$hmdxwrite = fopen($fnmdx, 'a');
$header_str = '<Dictionary GeneratedByEngineVersion="2.0" RequiredEngineVersion="2.0" Encrypted="0" Encoding="UTF-8" Format="Html" CreationDate="'.date('Y-m-d',time()).'" Compact="No" Compat="No" KeyCaseSensitive="No" Description="'.str_replace(['<','>'], ['&lt;','&gt;'], $xaht.$dicdescr).'" Title="'.$dictitle.'" DataSourceFormat="106" StripKey="No" StyleSheet=""/>'."\r\n\x00";
$header_str = iconv('UTF-8', 'UTF-16LE//IGNORE', $header_str);
fwrite($hmdxwrite, pack('N',strlen($header_str)).$header_str);
fwrite($hmdxwrite, pack('N',implode('',unpack('V',hash('adler32',$header_str,true)))));

$xadl = array($blockcount, $wordcount, $sztb, $sztbc, strlen($skbu));
$hadl = hash_init('adler32');
foreach ($xadl as $key => $val) {
  hash_update($hadl, "\x00\x00\x00\x00".pack('N',$val));
  fwrite($hmdxwrite, "\x00\x00\x00\x00".pack('N',$val));
}
fwrite($hmdxwrite, hash_final($hadl,true).pack('V',2).$adltbk.$stbu.$skbu);
unset($stbu);
unset($skbu);
    
$xadl = array($blockcount, $wordcount, $blockcount * 16, $meabytecount);
foreach ($xadl as $key => $val) {
  fwrite($hmdxwrite, "\x00\x00\x00\x00".pack('N',$val));
}
foreach ($pckszarr as $key => $val) {
  fwrite($hmdxwrite, "\x00\x00\x00\x00".pack('N',$val[0])."\x00\x00\x00\x00".pack('N',$val[1]));
}
unset($pckszarr);
unset($xadl);

$ftmpsz = filesize($fntmp);
$htmprd = fopen($fntmp, 'r');
$frwlen = 102400;
for( ; ; ) {
  if($ftmpsz > $frwlen) {
    fwrite($hmdxwrite, fread($htmprd, $frwlen));
    $ftmpsz -= $frwlen;
  } else if($ftmpsz == 0) {
    break;
  } else {
    fwrite($hmdxwrite, fread($htmprd, $ftmpsz));
    break;
  }
}
fclose($htmprd);
fclose($hmdxwrite);
unlink($fntmp);

$imfoln = '';
if($dafnam == 'dabkrs' || $dafnam == 'dabkrss' || $dafnam == 'dabruks' || $dafnam == 'examples' || $grn == '') $imfoln = 'images_bkrs';
else if($grn == 'cdict') $imfoln = 'images_mdbg';
else if($grn == 'dsldict') $imfoln = 'images_dsl';

@copy('dsx/'.$imfoln.'/mdx_icon.jpg', $ddir.'/'.$dafnam.'.jpg');
if($GLOBALS['md_readme'] != '') file_put_contents($ddir.'/README.txt', "\xEF\xBB\xBF".$GLOBALS['md_readme']);

zipc($ddir);
return restfunc($dafnam, $wordcount, $wordcountall);
}
?>
