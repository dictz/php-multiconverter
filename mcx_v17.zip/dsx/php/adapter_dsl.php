<?php
function adsl_awp($houtp, $rdata, $ls = '') {
  return preg_replace_callback('/.+(?=\x0a\x00'.$ls.')/s', function($matches) use ($houtp, $ls) {
    $txa = @iconv('UTF-16LE','UTF-8//IGNORE',$matches[0]);
    $txa = str_replace(["\r","\t"], ['',' '], $txa);
    $txa = preg_replace_callback('/.*?\n[^ ].*?(?=\n[^ ]'.$ls.')/s', function($matches) use ($houtp) {
      $txa = preg_replace('/\[[\/]?(!trs|com|trn|\*|lang[^\[\]\\\\]*)\]/', ' ', $matches[0]);
      $txa = preg_replace('/\[url\][^\[\]]*\[\/url\]/', ' ', $txa);
      $txa = preg_replace('/\[s\][^\[\]]*\[\/s\]/', ' ', $txa);
      $txa = preg_replace('/\[\'\]([^\[\]]*)\[\/\'\]/', "$1\xcc\x81", $txa);
      $txa = preg_replace('/\[m[0-9]?\]\[\/m\]/', '', $txa);
      $txa = preg_replace('/\[\/m\][ ]*\n/', '[/m]', $txa);
      $txa = preg_replace('/\n[ ]+\n/', "\n\n", $txa);
      $txa = preg_replace('/[\n]{2,}/', "\n", $txa);
      $txa = preg_replace('/[ ]{2,}/', ' ', $txa);
      $txa = trim($txa);
      if($txa == '') return '';
      fwrite($houtp, "\n\n".$txa);
      return '';
    }, $txa);
    return @iconv('UTF-8', 'UTF-16LE//IGNORE', $txa);
  }, $rdata);
}

function adapter_dsl($fninpar, $fnoutp) {
  $flinp = true;
  foreach ($fninpar as $fninp) $flinp = $flinp && is_rf($fninp);
  if(!$flinp && !is_rf($fnoutp)) return false;
  if(is_rf($fnoutp)) return true;

  $houtp = fopen($fnoutp, 'a');
  fwrite($houtp, " ");
  foreach ($fninpar as $fninp) {
    $finpsz = filesize($fninp) - 2;
    $hinprd = fopen($fninp, 'r');
    $xsg = fread($hinprd, 2);
    $frwlen = 102400;
    if($finpsz < $frwlen) $frwlen = $finpsz;

    $xpd = preg_replace_callback('/(^|\x0a\x00)\x23\x00.*?(?=\x0a\x00)/', function($matches) {
      return '';
    }, fread($hinprd, $frwlen));
    $finpsz -= $frwlen;

    for( ; ; ) {
      if($finpsz > $frwlen) {
        $xpd = adsl_awp($houtp, $xpd.fread($hinprd, $frwlen));
        $finpsz -= $frwlen;
      } else if($finpsz == 0) {
        adsl_awp($houtp, $xpd, '|$');
        break;
      } else {
        adsl_awp($houtp, $xpd.fread($hinprd, $finpsz), '|$');
        break;
      }
    }
    fclose($hinprd);
  }
  fclose($houtp);
  return true;
}

?>