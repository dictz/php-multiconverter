<?php
function is_rf($fnam) {
  if(is_readable($fnam)) if(!is_dir($fnam)) if(filesize($fnam) != 0) return true;
  return false;
}

function aced_py($sstr) {
  if(preg_match('#(.+) (.+) \[(.+)] /(.*)/#', $sstr, $match) !== 1) return false;
  $match[4] = preg_replace_callback('/(?<=\[)([^\[\]]+)(?=\])/u', function($matches) {
    return convertToPinyinDiacritic($matches[1]);
  }, $match[4]);
  $match[4] = preg_replace('/([\[\]])/', '\\\\$1', $match[4]);
  $match[1] = preg_replace('/([\[\]])/', '\\\\$1', $match[1]);
  $match[2] = preg_replace('/([\[\]])/', '\\\\$1', $match[2]);
  return array('simplified' => $match[2], 'pinyinDiacritic' => convertToPinyinDiacritic($match[3]), 'englishExpanded' => explode('/', $match[4]), 'traditional' => $match[1]);
}

function rpl($str) {
  $str = str_replace(['<','>'], ['&lt;','&gt;'], $str);
  return preg_replace_callback('/(?<=\[)[^\[\]]+(?=\\\\\])/u', function($matches) {
    return '[p] '.$matches[0].' [/p]';
  }, $str);
}

function adapter_ced($fninp, $fnoutp) {
  if(!is_rf($fninp) && !is_rf($fnoutp)) return false;
  if(is_rf($fnoutp)) return true;

  $hinprd = fopen($fninp, 'r');
  while(true) {
    $sstr = fgets($hinprd);
    if(mb_substr(trim($sstr),0,1) != '#') break;
  }

  $hfop = fopen($fnoutp, 'a');
  fwrite($hfop, " ");

  $eccount = 0;
  $cecount = 0;
  for( ; ; ) {
    $itarr = aced_py($sstr);
    if($itarr !== false) {
      fwrite($hfop, "\n\n".$itarr['simplified']."\n ");
      fwrite($hfop, '[p]'.$itarr['pinyinDiacritic'].'[/p]'."\n ");
      $nenex = count($itarr['englishExpanded']);
      if($nenex > 1) {
        foreach ($itarr['englishExpanded'] as $ike => $itval) fwrite($hfop, '[m1]• '.rpl($itval).'[/m]');
      } else if($nenex == 1) {
        fwrite($hfop, '[m1]'.rpl($itarr['englishExpanded'][0]).'[/m]');
      }

      if($itarr['simplified'] != $itarr['traditional']) {
        fwrite($hfop, "\n\n".$itarr['traditional']."\n ");
        fwrite($hfop, '[p]'.$itarr['pinyinDiacritic'].'[/p]'."\n ");
        $nenex = count($itarr['englishExpanded']);
        if($nenex > 1) {
          foreach ($itarr['englishExpanded'] as $ike => $itval) fwrite($hfop, '[m1]• '.rpl($itval).'[/m]');
        } else if($nenex == 1) {
          fwrite($hfop, '[m1]'.rpl($itarr['englishExpanded'][0]).'[/m]');
        }
      }

      foreach ($itarr['englishExpanded'] as $ike2 => $itval2) {
        $txar = preg_split('/[\s]*;[\s]{0,}/', $itval2, 0, PREG_SPLIT_NO_EMPTY);
        foreach ($txar as $ike => $itval) {
          fwrite($hfop, "\n\n".$itval."\n ");
          fwrite($hfop, '[p]'.$itarr['pinyinDiacritic'].'[/p]'."\n ");
          fwrite($hfop, '[m1][ref]'.$itarr['simplified'].'[/ref][/m]');

          if(preg_match("/^\(.*?\)[\s]*[^\s\(\)].*$/", $itval) == 1 && preg_match("/^\([^\(\)]*\(/", $itval) != 1) {
            $itval = preg_replace("/^(\(.*?\))[\s]*([^\s\(\)].*)$/", '$2 $1', $itval);
            fwrite($hfop, "\n\n".$itval."\n ");
            fwrite($hfop, '[p]'.$itarr['pinyinDiacritic'].'[/p]'."\n ");
            fwrite($hfop, '[m1][ref]'.$itarr['simplified'].'[/ref][/m]');

          }

          ++$eccount;
        }
      }

      ++$cecount;
    }
    $sstr = fgets($hinprd);
    if($sstr === false) break;
  }
  fclose($hinprd);
  fclose($hfop);

  $editmetext = file_get_contents('adapter/EDITME.json');
  $editmetext = preg_replace("/(?<=Chinese-English \()[\d]+(?=\))/", $cecount, $editmetext);
  $editmetext = preg_replace("/(?<=English-Chinese \()[\d]+(?=\))/", $eccount, $editmetext);
  $editmetext = preg_replace("/(?<=date )[\d]+\.[\d]+\.[\d]+/", date('d.m.Y',time()), $editmetext);
  file_put_contents('adapter/EDITME.json', $editmetext);
  
  return true;
}

//https://github.com/mdsills/cccedict
function convertToPinyinDiacritic($pinyin0) {
  $vowels = ['a', 'e', 'i', 'o', 'u', 'u:', 'A', 'E', 'I', 'O', 'U', 'U:'];
  $conversion = [
    1 => array_combine($vowels, ['ā', 'ē', 'ī', 'ō', 'ū', 'ǖ', 'Ā', 'Ē', 'Ī', 'Ō', 'Ū', 'Ǖ']),
    2 => array_combine($vowels, ['á', 'é', 'í', 'ó', 'ú', 'ǘ', 'Á', 'É', 'Í', 'Ó', 'Ú', 'Ǘ']),
    3 => array_combine($vowels, ['ǎ', 'ě', 'ǐ', 'ǒ', 'ǔ', 'ǚ', 'Ǎ', 'Ě', 'Ǐ', 'Ǒ', 'Ǔ', 'Ǚ']),
    4 => array_combine($vowels, ['à', 'è', 'ì', 'ò', 'ù', 'ǜ', 'À', 'È', 'Ì', 'Ò', 'Ù', 'Ǜ']),
  ];

  $pinyins0 = explode(' ', $pinyin0);
  $returnPinyins0 = [];
  foreach ($pinyins0 as $pinyin0) {
    $pinyin0 = trim($pinyin0);
    if($pinyin0 == '') continue;

    $pinyins = preg_split('/(.+?\d)/', $pinyin0, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
    $returnPinyins = [];
    foreach ($pinyins as $pinyin) {
      $pinyin = trim($pinyin);
      if($pinyin == '') continue;

      $tone = (int)substr($pinyin, -1, 1);
      if ($tone > 0 && $tone < 6) {
        $pinyin = substr($pinyin, 0, -1);

        if ($tone < 5) {
          $toConvertPosition = stripos($pinyin, 'a') ? : stripos($pinyin, 'e') ? : stripos($pinyin, 'ou');

          if ($toConvertPosition === false) {
            for ($i = strlen($pinyin); $i >= 0; $i--) {
              if (in_array(substr($pinyin, $i, 1), $vowels)) {
                $toConvertPosition = $i;
                break;
              }
            }
          }

          if ($toConvertPosition !== false) {
            if (substr($pinyin, $toConvertPosition+1, 1) == ":") {
              $toConvert = substr($pinyin, $toConvertPosition, 2);
            } else {
              $toConvert = substr($pinyin, $toConvertPosition, 1);
            }
            $returnPinyins[] = str_replace($toConvert, $conversion[$tone][$toConvert], $pinyin);
          } else {
            $returnPinyins[] = $pinyin;
          }

        } else {
          $returnPinyins[] = str_replace(['u:', 'U:'], ['ü', 'Ü'], $pinyin);
        }

      } else {
        $returnPinyins[] = $pinyin;
      }

    }
    $returnPinyins0[] = implode('', $returnPinyins);

  }
  return implode(' ', $returnPinyins0);
}
?>
