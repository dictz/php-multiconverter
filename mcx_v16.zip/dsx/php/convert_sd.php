<?php
function txta_sd($dafnam, $txa, $wcnt, $grn) {
  $txa = str_replace(["\r","\t"], ['',' '], $txa);

  $txar = preg_split('/\n\s/', $txa, 2, PREG_SPLIT_NO_EMPTY);
  if($dafnam == 'dabkrs' || $dafnam == 'dabkrss' || $grn == 'cdict') {
    if(count($txar) == 2) {
      $txar2 = preg_split('/\n/', $txar[1], 2, PREG_SPLIT_NO_EMPTY);
      $txa = str_replace("\n", '\\n', $txar[0])."\n".str_replace("\n", '\\n', $txar2[0])."\n".str_replace("\n", '\\n', $txar2[1]);
    } else {
      $txa = '@err'.$wcnt."\n".'_'."\n".str_replace("\n", '\\n', $txa);
    }
  } else if($dafnam == 'dabruks' || $dafnam == 'examples' || $grn == 'dsldict') {
    if(count($txar) == 2) {
      $txa = str_replace("\n", '\\n', $txar[0])."\n".str_replace("\n", '\\n', $txar[1]);
    } else {
      $txa = '@err'.$wcnt."\n".str_replace("\n", '\\n', $txa);
    }
  }

  if($dafnam == 'dabkrss') {
    if(preg_match("/\n[\s]*_[\s]*\n/", $txa) == 1) {
      return '';
    }
  }

  $txa = str_replace(['<','>'], ['&lt;','&gt;'], $txa);
  $txa = preg_replace('/(\[[\*]\]|\[\/[\*]\])/', ' ', $txa);
  if($GLOBALS['sd_indent'] == 0) $txa = preg_replace('/(\[m[0-9]?\]|\[\/m\])/', ' \\n ', $txa);
  else $txa = preg_replace('/\[m[01]?\](.*?)\[\/m\]/', ' \\n $1 \\n ', $txa);
  $txa = preg_replace('/(\[b\][ ]*[IV]+[ ,])/', '\\n$1', $txa);
  $txa = preg_replace('/(\[b\][ ]*[IV]+[ ]*\[\/b\])/', '\\n$1', $txa);
  while(preg_match('/\\\\n[ ]*\\\\n/', $txa) == 1) {
    $txa = preg_replace('/\\\\n[ ]*\\\\n/', '\\n', $txa);
  }
  $txa = preg_replace('/[ ]{2,}/', ' ', $txa);
  $txa = preg_replace('/[ ]*\\\\n[ ]*/', '\\n', $txa);
  $txa = preg_replace('/(\\\\n| )*\n(\\\\n| )*/', "\n", $txa);
  $txa = preg_replace('/(\\\\n| )*$/', '', $txa);
  $txa = preg_replace('/^(\\\\n| )*/', '', $txa);
  $txa = preg_replace('/([\(\[])[ ]+/', '$1', $txa);
  $txa = preg_replace('/[ ]+([\)\]])/', '$1', $txa);
  if($dafnam == 'examples') {
    if(preg_match('/(\\\\n\\\\n.*)(\\\\n)+/', $txa) == 1) {
      $txa = str_replace('\\n\\n', '\\n', $txa);
    }
  }
  if($GLOBALS['sd_indent'] > 0) {
    $txa = preg_replace_callback('/\[m(\d)\](.*?)\[\/m\]/', function($matches) {
      if(intval($matches[1]) < 2) return ' \\n '.$matches[2].' \\n ';
      return '<div style="padding-inline-start:'.((intval($matches[1])-1)*$GLOBALS['sd_indent']).'px;">'.$matches[2].'</div>';
    }, $txa);
  }
  $txa = preg_replace('/\[([\/]?)(i|b|u|sub|sup)\]/', '<$1$2>', $txa);
  $txa = preg_replace('/\[c[^\[\]\\\\]*\]/', '<font class="p">', $txa);
  $txa = str_replace('[/c]', '</font>', $txa);
  $txa = str_replace('[p]', '<font class="p">', $txa);
  $txa = str_replace('[/p]', '</font>', $txa);
  $txa = str_replace('[ex]', '<font class="ex">• ', $txa);
  $txa = str_replace('[/ex]', '</font>', $txa);
  if($grn == '') $txa = preg_replace('/(?<=\[\/ref\])([\s\p{P}]*)(?=\[ref\])/u', '<br>$1', $txa);
  $txa = preg_replace('/\[ref\]([^\[\]]+)\[\/ref\]/', '<a href="$1">$1</a>', $txa);
  $txa = preg_replace('/\\\\([\[\]])/', '$1', $txa);
  return str_replace('\\n', '<br>', $txa);
}

function convert_sd($dadir, $dafnam, $profdicarr, $dictitle, $dicdescr, $dadate, $testfl, $grn = '') {
$sd_dir = 'StarDict';
if(!is_dir($sd_dir)) mkdir($sd_dir);
$ddir = $sd_dir.'/'.str_replace('@', $dafnam, $GLOBALS['sd_catname']);
if(is_dir($ddir)) rrmdir($ddir);
mkdir($ddir);

$xaht = aht($GLOBALS['sd_theme']);
$wordcountall = 0;
$wordcount = 0;
$fndict = $ddir.'/'.$dafnam.'.dict';
$hdictwrite = fopen($fndict, 'a');

$curoffset = 0;
$tarr = array();
$tarr['0_0'] = ' ';
foreach ($profdicarr as $dakey => $val) {
  $fnamerd = $dadir;
  if($grn == '') {
    if($dakey == 'dabkrss') $fnamerd .= 'dabkrs_'.$dadate;
    else $fnamerd .= $dakey.'_'.$dadate;
  } else {
    $fnamerd .= $dakey;
  }
  $fp = @fopen($fnamerd, 'r');
  if(!$fp) return 'err:'.$fnamerd;
  $lbuf = '';
  $wordc = 1;
  fgsit($fp, $dakey);
  while (true) {
    $buffer = fgets($fp);
    if($buffer == "\r\n" || $buffer == "\n" || $buffer === false) {
      if($buffer === false && $lbuf == '') break;
      $lbuf = trim($lbuf);
      if($lbuf == '') continue;
      ++$wordcountall;
      $xtx = txta_sd($dakey, $lbuf, $wordcountall, $grn);
      if($xtx == '') {
        $lbuf = '';
        continue;
      }
      $ard = explode("\n", $xtx);

      if(strlen($ard[0]) > 253) {
        $ardk0 = mb_substr($ard[0], 0, 50).'...';
      } else $ardk0 = $ard[0];

      if($dakey == 'dabkrs' || $dakey == 'dabkrss' || $grn == 'cdict') {
        $ard[1] .= '<hr>'.$ard[2];
      }

      $ktl = fwrite($hdictwrite, $xaht.$ard[0].'<hr>'.$ard[1].$GLOBALS['sd_addcontent']);
      $tarr[$curoffset.'_'.$ktl] = str_replace(['&lt;','&gt;'], ['<','>'], $ardk0);
      $curoffset += $ktl;
      ++$wordcount;
      $lbuf = '';
      if($testfl) {
        if($wordc >= $GLOBALS['tstnums']) break;
        else ++$wordc;
      }
    } else $lbuf .= $buffer;
  }
  fclose($fp);
}
fclose($hdictwrite);
uasort($tarr, 'ucmp');

$fnidx = $ddir.'/'.$dafnam.'.idx';
$hidxwrite = fopen($fnidx, 'a');
foreach ($tarr as $key => $val) {
  $keyar = explode('_', $key);
  fwrite($hidxwrite, $val."\x00".pack('N',$keyar[0]).pack('N',$keyar[1]));
}
fclose($hidxwrite);
unset($tarr);

$ifotext = 'StarDict\'s dict ifo file
version=2.4.2
wordcount='.$wordcount.'
idxfilesize='.filesize($fnidx).'
bookname='.$dictitle.'
date='.date('Y.m.d',time()).'
sametypesequence=h
description='.$dicdescr;

file_put_contents($ddir.'/'.$dafnam.'.ifo', $ifotext);
if($GLOBALS['sd_readme'] != '') file_put_contents($ddir.'/README.txt', "\xEF\xBB\xBF".$GLOBALS['sd_readme']);

dzipc($ddir, 'idx', 'gz', $GLOBALS['sd_compress']);
dzipc($ddir, 'dict', 'dz', $GLOBALS['sd_compress']);
zipc($ddir);
return restfunc($dafnam, $wordcount, $wordcountall);
}
?>
