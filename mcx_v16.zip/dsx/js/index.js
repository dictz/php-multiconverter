'use strict';
function g(idelem){return document.getElementById(idelem);}
function b64e(str){return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,function toSolidBytes(math,p1){return String.fromCharCode('0x'+p1);}));} 
function b64d(str){return decodeURIComponent(atob(str).split('').map(function(c){return '%'+('00'+c.charCodeAt(0).toString(16)).slice(-2);}).join(''));} 
function toent(tx){return tx.replace(/./gus,function(match){return '&#'+match.codePointAt(0)+';';});}
function ulen(par){let len=0;for(let i of par){++len;}return len;}
function rnd(minr,maxr){return Math.floor(Math.random()*(maxr-minr+1))+minr;}

let ok = {
mpda:false,
emer:false,
first:false,
delay:false,
dig:function(){},
curok:'',
sc:[],
txtbut:function(n) {
  if(n == 'yes') return 'Да';
  else if(n == 'ok') return 'Ок';
  else if(n == 'next') return 'Далее';
  else if(n == 'back') return 'Назад';
  else if(n == 'run') return 'Выполнить';
  else if(n == 'cancel') return 'Отмена';
  else if(n == 'filter') return '...';
  else if(n == 'close') return 'Закрыть';
  else if(n == 'open') return 'Открыть';
  else if(n == 'save') return 'Сохранить';
  else if(n == 'continue') return 'Продолжить';
  else if(n == 'repeat') return 'Повторить';
  else if(n == 'apply') return 'Применить';
  else if(n == 'delete') return 'Удалить';
  else return 'undefined';
},

coun:function() {
 return;
 let cou = ok.sc.length;
 if(cou == 0) {
  diaokboxcoun_id.style.display = 'none';
  diaokboxcoun_id.innerHTML = '';
  return true;
 } else if(cou >= 1 && cou <= 2 ) {
  diaokboxcoun_id.innerHTML = '...' + cou;
 } else {
  diaokboxcoun_id.innerHTML = `<span onclick="ok.emer=true; ok.cancel('Закрыть все ?', function(r){if(r) ok.resall();});">...${cou} ${ok.txtbut('close')}</span>`;
 }
 diaokboxcoun_id.style.display = 'table-cell';
 return true;
},

show:function(...args) {
 if(diaok_id.style.display == '' && ok.emer == false) {
  let dlim = 99;
  if(ok.sc.length < dlim) {
    if(ok.first) ok.sc.unshift(JSON.stringify(args));
    else ok.sc.push(JSON.stringify(args));
  } else alert('Error: call ok.' + args[0] + '\nDialogs limit ' + dlim);
  ok.first = false;
  return {'return':false, 'curok':JSON.stringify(args)};
 } else {
  if(ok.emer) {
    ok.emer = false;
    if(ok.curok != '') ok.sc.unshift(ok.curok);
  }
  ok.curok = JSON.stringify(args);
  if(g('box_id')) box_id.style.filter = 'blur(1px)'; 
  diaok_id.style.display = '';
  return {'return':true, 'curok':JSON.stringify(args)};
 }
},

okhas:function(c) {
 for(let i = 0; i < ok.sc.length; i++) if(ok.sc[i] == c) return true;
 return false;
},

hide:function(c) {
   window.getSelection().removeAllRanges();
   if(c !== undefined) {
     if(c != ok.curok) {
       for(let i = 0; i < ok.sc.length; i++) {
         if(ok.sc[i] == c) {
           ok.sc.splice(i, 1);
           ok.coun();
           return;
       } }
       return;
   } }
   diaok_id.style.display = 'none';
   diaokbox_id.innerHTML = '';
   ok.curok = '';
   if(g('box_id')) box_id.style.filter = ''; 
   if(ok.sc.length != 0) {
     let tar = JSON.parse(ok.sc.shift());
     eval(`ok.${tar.shift()}(...tar);`);
   }
},

autohide:function(t = 999, crk, f = function(c){ok.hide(c);}) {
  dsx.run(t, 'okautohide_' + urnd('okautohide'), f, function(...args) {
    if(ok.curok == args[7][0]) return 'run';
    if(!ok.okhas(args[7][0])) return 'del';
    else return 'pause';
  }, undefined, crk);
},

resall:function() {
  ok.sc.length = 0;
  ok.hide();
},

ok:function(txt, cb = function(){}, but_ok = ok.txtbut('yes'), ...argu) {
 if(ok.delay) {
  ok.delay = false;
  return (function(...a) {
   eval(`ok.${a.shift()}(...a);`);
  }).bind(undefined, 'ok', txt, cb.toString(), but_ok, ...argu);
 }
 let showres = ok.show('ok', txt, cb.toString(), but_ok, ...argu);
 if(showres['return']) {
  ok.dig = (function(f, a, r) {
    eval(`(${f})(r, ...a);`);
    ok.hide();
  }).bind(undefined, cb.toString(), argu.slice());
  if(but_ok != '') but_ok = `<div class="diaokboxfooter"><button onclick="ok.dig(true);">${but_ok}</button></div>`;
  diaokbox_id.innerHTML = `
   <div class="diaokboxheader">
     <div class="diaokboxheaderlcell"></div>
     <div class="diaokboxheaderrcell" id="diaokboxcoun_id"></div>
   </div>
   <div class="diaokboxbody">
     <div class="diaokboxtxtcont">${txt}</div>
   </div>
   ${but_ok}
  `;
 }
 ok.coun();
 return showres['curok'];
},

cancel:function(txt, cb = function(){}, but_c = ok.txtbut('cancel'), but_ok = ok.txtbut('yes'), ...argu) {
 if(ok.delay) {
  ok.delay = false;
  return (function(...a) {
   eval(`ok.${a.shift()}(...a);`);
  }).bind(undefined, 'cancel', txt, cb.toString(), but_c, but_ok, ...argu);
 }
 let showres = ok.show('cancel', txt, cb.toString(), but_c, but_ok, ...argu);
 if(showres['return']) {
  ok.dig = (function(f, a, r) {
    eval(`(${f})(r, ...a);`);
    ok.hide();
  }).bind(undefined, cb.toString(), argu.slice());
  diaokbox_id.innerHTML = `
   <div class="diaokboxheader">
     <div class="diaokboxheaderlcell"></div>
     <div class="diaokboxheaderrcell" id="diaokboxcoun_id"></div>
   </div>
   <div class="diaokboxbody">
     <div class="diaokboxtxtcont">${txt}</div>
   </div>
   <div class="diaokboxfooter">
     <button onclick="ok.dig(false);">${but_c}</button>
     <button onclick="ok.dig(true);">${but_ok}</button>
   </div>
  `;
 }
 ok.coun();
 return showres['curok'];
},

constr:function(txt, txt2 = '', cb = function(){}, ...argu) {
 let showres = ok.show('constr', txt, txt2, cb.toString(), ...argu);
 if(showres['return']) {
  ok.dig = (function(f, a, ...ua) {
    if(eval(`(${f})(...a, ...ua);`) !== false) ok.hide();
  }).bind(undefined, cb.toString(), argu.slice());
  if(txt2 != '') txt2 = `<div class="diaokboxfooter">${txt2}</div>`;
  diaokbox_id.innerHTML = `
   <div class="diaokboxheader">
     <div class="diaokboxheaderlcell"></div>
     <div class="diaokboxheaderrcell" id="diaokboxcoun_id"></div>
   </div>
   <div class="diaokboxbody">
     <div class="diaokboxtxtcont">${txt}</div>
   </div>
   ${txt2}
  `;
  ok.dig('htset');
 }
 ok.coun();
 return showres['curok'];
},

};
