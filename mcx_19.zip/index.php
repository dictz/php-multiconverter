<?php 
set_time_limit(86399);
ini_set('memory_limit', '3072M');
mb_internal_encoding('UTF-8');

//================================================
//           НАСТРОЙКИ | OPTIONS
//------------------------------------------------

//Общие переменные
  // Общий постфикс для имён каталогов, текущие год|месяц|день. Пример: _250412.
  $postfix = '_'.mb_substr(date('Ymd',time()), 2);

  // Общий текст для README.txt. Файл не будет создан если строка пуста.
  $readme_text = '';

//DSL
  $dsl_numparts = 3;              // Деление DSL на части, количество частей, число >= 1.
  $dsl_parbalance = 1;            // 1 - уравновесить части по размеру; 2 - уровнять части по количеству слов.
  $dsl_threshold = 200*1024*1024; // Порог для осуществления деления, - размер исходн. файла(ов) в байтах. Деление будет происходить только если размер исходника больше этого значения.
  $dsl_include = true;            // Использование директивы #INCLUDE при делении на части: true - использовать; false - не использовать. Используется для компиляции в Lingvo, другие программы могут игнорировать директиву.
  $dsl_compress = 6;              // Сжатие DictZIP (.dsl.dz). Число от 1 до 9, определяющее уровень сжатия. 0 - без сжатия. Для компиляции в Lingvo установить 0.
  $dsl_cn_langindex = 'Chinese';  // English
  $dsl_ru_langindex = 'Russian';
  $dsl_cn_langcontent = 'Chinese';
  $dsl_ru_langcontent = 'Russian';
  $dsl_catname = 'dsl_@'.$postfix; // Имя каталога, должно содержать только допустимые для имён символы (недопустимые символы: @<>:;.,«»\/|?*[]=#%&)
  $dsl_readme = $readme_text;      // Текст для README.txt

//MDict
  $md_keyword = true;        // Добавление ключевого слова (словосочетания) в начало словарной статьи. true - добавить; false - не добавлять.
  $md_compress = 6;          // Внутреннее сжатие. Число от 1 до 9, определяющее уровень сжатия. 0 - без сжатия.
  $md_indent = 20;           // Отступы в словарных статьях, пиксели. 0 - без отступов.
  $md_theme = 'app';         // Цветовая тема: 'light' - всегда светлая; 'dark' - всегда тёмная; 'app' - управляется приложением, либо системой; '' - не устанавливать стили.
  $md_addcontent = '';       // Добавочное содержимое, помещается в конце каждой страницы. Допустимо использование HTML, CSS и JavaScript.
  $md_catname = 'mdict_@'.$postfix; // Имя каталога, должно содержать только допустимые для имён символы (недопустимые символы: @<>:;.,«»\/|?*[]=#%&)
  $md_readme = $readme_text;        // Текст для README.txt

//StarDict
  $sd_keyword = true;        // Добавление ключевого слова (словосочетания) в начало словарной статьи. true - добавить; false - не добавлять.
  $sd_compress = 6;          // Сжатие GZip (.idx.gz) и DictZip (.dict.dz). Число от 1 до 9, определяющее уровень сжатия. 0 - без сжатия.
  $sd_indent = 20;           // Отступы в словарных статьях, пиксели. 0 - без отступов.
  $sd_theme = 'app';         // Цветовая тема: 'light' - всегда светлая; 'dark' - всегда тёмная; 'app' - управляется приложением, либо системой; '' - не устанавливать стили.
  $sd_addcontent = '';       // Добавочное содержимое, помещается в конце каждой страницы. Допустимо использование HTML, CSS и JavaScript (некоторые приложения JavaScript не выполняют).
  $sd_catname = 'stardict_@'.$postfix; // Имя каталога, должно содержать только допустимые для имён символы (недопустимые символы: @<>:;.,«»\/|?*[]=#%&)
  $sd_readme = $readme_text;           // Текст для README.txt

//HTML
  $ht_langcode = 'english-USA';    // Язык интерфейса (см. dsx/js/lang.js). Учитывается только при конвертации из DSL.
  $ht_catname = 'html_@'.$postfix; // Имя каталога, должно содержать только допустимые для имён символы (недопустимые символы: @<>:;.,«»\/|?*[]=#%&)
  $ht_readme = $readme_text;       // Текст для README.txt

//ZIP
  $option_zip = true;    // Создание сжатого ZIP-каталога: true - включить; false - обычный каталог.
  $zip_password = '';    // Пароль для ZIP-каталога (PHP >= 7.2). Пустая строка '' - без пароля.
  $zip_srccatdel = true; // Удаление исходного каталога после получения ZIP-каталога: true - удалить; false - не удалять.

//Дополнительно
  $tstnums = 1000;       // Количество слов в базах для тестовой конвертации.
  $threads = 1;          // Для многопоточного сервера. Количество потоков, число >= 1.

  //Стили тем для форматов MDict и StarDict
  $theme_style = '
<style>
  * {border-color:gray !important;}
  hr {border-top-width:0 !important;}
  .ex {color:gray !important;}

  @media (prefers-color-scheme:dark) {
    body {
      color:#d5d5d5 !important;
      background-color:#252525 !important;
    }
    .p {color:#3d3 !important;}
    a:link {color:#bb2 !important;}
    a:visited {color:skyblue !important;}
  }/*light*/ /*@*/

  @media (prefers-color-scheme:light) {
    body {
      color:#000 !important;
      background-color:#f5f5f5 !important;
    }
    .p {color:green !important;}
    a:link {color:blue !important;}
    a:visited {color:purple !important;}
  }/*dark*/ /*@*/
</style>';

//------------------------------------------------
  @include 'options.php'; // Необязательный файл, настройки вынесенные в него переопределяют настройки выше.
//================================================

function tdsrepl($xstr) {return trim(str_replace(["\t","\n","\r"], [' ',' ',''], $xstr));}
if($_SERVER["REQUEST_METHOD"] != 'POST') {
include 'dsx/php/adapter_ced.php';
include 'dsx/php/adapter_dsl.php';

$ast = '<hr>Добавление, редактирование и новые версии словаря - <a target="_blank" href="https://bkrs.info">https://bkrs.info</a><br>Конвертировано с помощью <a target="_blank" href="https://github.com/dictz">https://github.com/dictz</a>';
$bktitle = '大БКРС';
$bkdescr = 'Большой Китайско-Русский Словарь';
$brtitle = 'БРуКС';
$brdescr = 'Большой Русско-Китайский Словарь';
$extitle = 'Примеры';
$exdescr = 'Примеры 大БКРС';

$flv = array('StarDict' => false, 'MDict' => false, 'DSL' => false, 'HTML' => false);
$dadir = 'da/';
$addir = 'adapter/';
$convdata = array('testfl' => false, 'dadir' => $dadir, 'bzdate' => '', 'bzl' => []);

$dadate = '';
$dadate2 = '';
$arfiles = scandir($dadir);
foreach ($arfiles as $key => $value) {
  if(is_file($dadir.$value)) {
    if(preg_match('/^(dabkrs|dabruks|examples)_[\d]{6}$/', $value) != 1) continue;
    $dafnam = explode('_', $value)[0];
    $dadate = $convdata['bzdate'] = explode('_', $value)[1];
    $dadate2 = preg_replace('/(\d\d)(\d\d)(\d\d)/', '20$1-$2-$3', $dadate);
    if ($dafnam == 'dabkrs') {
      $convdata['bzl'][$dafnam] = array();
      $convdata['bzl'][$dafnam]['flv'] = $flv;
      $convdata['bzl'][$dafnam.'s'] = array();
      $convdata['bzl'][$dafnam.'s']['flv'] = $flv;
      $convdata['bzl'][$dafnam]['title'] = $convdata['bzl'][$dafnam.'s']['title'] = $bktitle.' - '.$dadate;
      $convdata['bzl'][$dafnam]['descr'] = $convdata['bzl'][$dafnam.'s']['descr'] = $bkdescr.' ('.$dadate2.'). '.$ast;
    } else if ($dafnam == 'dabruks') {
      $convdata['bzl'][$dafnam] = array();
      $convdata['bzl'][$dafnam]['flv'] = $flv;
      $convdata['bzl'][$dafnam]['title'] = $brtitle.' - '.$dadate;
      $convdata['bzl'][$dafnam]['descr'] = $brdescr.' ('.$dadate2.'). '.$ast;
    } else if ($dafnam == 'examples') {
      $convdata['bzl'][$dafnam] = array();
      $convdata['bzl'][$dafnam]['flv'] = $flv;
      $convdata['bzl'][$dafnam]['title'] = $extitle.' - '.$dadate;
      $convdata['bzl'][$dafnam]['descr'] = $exdescr.' ('.$dadate2.'). '.$ast;
    }
  }
}

$mixbz = array(
'dabkrs_dabruks_examples' => [
  'flv' => $flv,
  'title' => $bktitle.', '.$brtitle.', '.$extitle.' - '.$dadate,
  'descr' => $bkdescr.', '.$brdescr.', '.$exdescr.' ('.$dadate2.'). '.$ast
], 'dabkrs_dabruks' => [
  'flv' => $flv,
  'title' => $bktitle.', '.$brtitle.' - '.$dadate,
  'descr' => $bkdescr.', '.$brdescr.' ('.$dadate2.'). '.$ast
], 'dabkrss_dabruks_examples' => [
  'flv' => $flv,
  'title' => $bktitle.', '.$brtitle.', '.$extitle.' - '.$dadate,
  'descr' => $bkdescr.', '.$brdescr.', '.$exdescr.' ('.$dadate2.'). '.$ast
], 'dabkrss_dabruks' => [
  'flv' => $flv,
  'title' => $bktitle.', '.$brtitle.' - '.$dadate,
  'descr' => $bkdescr.', '.$brdescr.' ('.$dadate2.'). '.$ast
],
);
foreach ($mixbz as $key => $profar) {
  if(count(array_diff_key(array_flip(explode('_',$key)), $convdata['bzl'])) != 0) {
    unset($mixbz[$key]);
  }
}
$convdata['bzl'] += $mixbz;

$adapterinfoar = json_decode(trim(str_replace(["\r","\n"],['',''],preg_replace('/^.*<json>[\r]?\n(.*)\n<\/json>.*$/s','$1',file_get_contents($addir.'EDITME.json')))), true);
foreach ($adapterinfoar as $key => $dbl) {
  if($key == 'CDICT') {
    foreach ($dbl as $dkey => $infl) {
      if(adapter_ced($addir.$infl['file'], $dadir.$dkey)) {
        $convdata['bzl'][$dkey] = array();
        $convdata['bzl'][$dkey]['flv'] = $flv;
        $convdata['bzl'][$dkey]['title'] = tdsrepl($infl['title']);
        $convdata['bzl'][$dkey]['descr'] = tdsrepl($infl['description']);
        $convdata['bzl'][$dkey]['grn'] = 'cdict';
      } else {
        continue;
      }
    }
  } else if($key == 'DSLDICT') {
    foreach ($dbl as $dkey => $infl) {
      foreach ($infl['files'] as &$ifn) $ifn = $addir.$ifn;
      unset($ifn);
      if(adapter_dsl($infl['files'], $dadir.$dkey)) {
        $convdata['bzl'][$dkey] = array();
        $convdata['bzl'][$dkey]['flv'] = $flv;
        $convdata['bzl'][$dkey]['flv']['DSL'] = 'disabled';
        $convdata['bzl'][$dkey]['title'] = tdsrepl($infl['title']);
        $convdata['bzl'][$dkey]['descr'] = tdsrepl($infl['description']);
        $convdata['bzl'][$dkey]['grn'] = 'dsldict';
      } else {
        continue;
      }
    }
  }
}

$convdatajs = base64_encode(json_encode($convdata));
//_________________________________________________________________
?><html dir="ltr">
<head>
  <title>MultiConverterX</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0"/>
  <meta name="HandheldFriendly" content="True"/>
  <link href="dsx/css/index.css" rel="stylesheet" type="text/css"/>
  <script src="dsx/js/index.js" type="text/javascript"></script>
  <script type="text/javascript">
 'use strict';
 const convdata = JSON.parse(b64d(`<?php echo $convdatajs; ?>`));
 const threads = <?php echo strval($threads); ?>;
 window.name = 'mcx';

 function lani(eid) {
   g(eid).dataset.intid = setInterval(function(eid) {
     let st = g(eid).dataset.stc;
     if(st == 'execution') {
       if(g(eid).innerText.length > 9) g(eid).innerText = '•';
       else g(eid).innerText = '•' + g(eid).innerText;
       return;
     } else if(st == 'success') {
       let ast = g(eid).dataset.res.split('_');
       g(eid).innerText = ast[0];
       g(eid.replace(/_c_id$/, '_d_id')).innerText = ast[1];
     } else if(st == 'error') {
       g(eid).innerHTML = `<button onclick="cdsend('${eid}');">Возобновить</button><button class="ibut" onclick="ok.ok(b64d(\`${g(eid).dataset.msg}\`));">i</button>`;
     }
     clearInterval(g(eid).dataset.intid);
   }, 500, eid);
 }

 function cdsend(eid) {
   let xhr = new XMLHttpRequest();
   xhr.open('POST', window.location);
   xhr.onload = (function(eid) {
     if(xhr.status != 200) {
       g(eid).dataset.msg = b64e(`<b>${xhr.status}</b> :<br>${xhr.statusText}`);
       g(eid).dataset.stc = 'error';
     } else {
       delete rs[eid];
       g(eid).dataset.res = xhr.response.trim();
       g(eid).dataset.stc = 'success';
       g(eid.replace(/_c_id$/, '_t_id')).innerText = timecon(+g(eid).dataset.tim);
       cdupd();
     }
   }).bind(undefined, eid);
   xhr.onerror = (function(eid) {
     g(eid).dataset.msg = b64e('Процесс завершился ошибкой.<br>Возможно локальный сервер остановлен или было прервано соединение.');
     g(eid).dataset.stc = 'error';
   }).bind(undefined, eid);

   convdata_name.value = g(eid).dataset.cd64;
   mtinfo_name.value = b64e(JSON.stringify(rs));

   g(eid).dataset.stc = 'execution';
   g(eid).dataset.tim = String(Date.now());
   lani(eid);
   xhr.send(new FormData(document.forms.form_name));
 }

 let rs = {}, summtim, cintid;
 function convstart(tst) {
   summtim = Date.now();
   showhide_id.style.display = 'none';
   convdata['testfl'] = tst;
   let tbody = '', flist = {'StarDict':false, 'MDict':false, 'DSL':false, 'HTML':false};
   for(let i in flist) {
     let ts = '';
     for(let key in convdata.bzl) {
       for(let key2 in convdata.bzl[key]['flv']) {
         if(key2 == i && convdata.bzl[key]['flv'][key2] === true) {
           let cd = {testfl:convdata.testfl, dadir:convdata.dadir, bzdate:convdata.bzdate, bzl:{}};
           cd.bzl[key] = JSON.parse(JSON.stringify(convdata.bzl[key]));
           cd.bzl[key]['flv'] = JSON.parse(JSON.stringify(flist));
           cd.bzl[key]['flv'][i] = true;
           rs[`${i}_${key}_c_id`] = i;
           ts += `<tr><td>${cd.bzl[key]['title']}<br><span class="cbzc">${key}</span><br><span id="${i}_${key}_t_id"></span></td><td id="${i}_${key}_c_id" data-stc="waiting" data-msg="" data-cd64="${b64e(JSON.stringify(cd))}" data-tim="" data-intid="" data-res="" class="emo">&#xe038;</td><td id="${i}_${key}_d_id"></td></tr>`;
           break;
     } } }
     if(ts != '') {
       if(tbody == '') tbody += `<tr><th colspan="2">${i}</th><th class="emo">&#xe07d;</th></tr>${ts}`;
       else tbody += `<tr><th colspan="3">${i}</th></tr>${ts}`;
     }
   }
   ulist_id.innerHTML = `<table class="resinfotable"><tbody>${tbody}</tbody></table><hr><p><span id="summtim_id" class="emo">&#xe038;</span></p>`;
   cdupd(threads);

   cintid = setInterval(function() {
     for(let eid in rs) if(g(eid).dataset.stc == 'execution') return;
     cdupd(threads, ['error','waiting']);
   }, 5000);
 }

 function cdupd(t = 1, arp = ['waiting','error']) {
   let i = 0;
   for(let eid in rs) ++i;
   if(i === 0) {
     clearInterval(cintid);
     let iib = '';
     if(threads > 1) iib = `<button class="ibut" onclick="ok.ok('Если пройденное время существенно меньше, это может означать, что фактическое одновременно выполняемое количество потоков меньше установленного (меньше ${threads}).<br>Если возникали остановки сервера и/или разрывы соединения, пройденное время будет включать время простоя.');">i</button>`;
     summtim_id.innerHTML = `${iib}Прошло ${timecon(summtim)}`;
     return;
   }
   if(t > i) t = i;

   for(let sc of arp) for(let eid in rs) {
     if(g(eid).dataset.stc != sc) continue;
     cdsend(eid);
     --t;
     if(t === 0) return;
   }
 }

 function tdedit(xbz) {
   ok.constr(`
     <input type="text" id="newtitle_id" autocomplete="off" placeholder="Заголовок" onkeydown="if(event.key=='Enter'){newdescr_id.focus();}" style="width:400px;"/>
     <hr><textarea id="newdescr_id" placeholder="Описание" style="width:400px;height:20%;"></textarea>
   `, `
     <button onclick="ok.hide();">${ok.txtbut('cancel')}</button>
     <button onclick="ok.dig('save');">${ok.txtbut('apply')}</button>
   `, function(xbz, m) {
     if(m == 'htset') {
       newtitle_id.value = xbz['title'];
       newdescr_id.value = xbz['descr'];
       newtitle_id.focus();
     } else if(m == 'save') {
       xbz['title'] = newtitle_id.value.replace(/[\n\r\t'"<>\\$]/g, ' ').replace(/[ ]{2,}/g, ' ').trim();
       xbz['descr'] = newdescr_id.value.replace(/[\n\r\t'"<>\\$]/g, ' ').replace(/[ ]{2,}/g, ' ').trim();
       getinplist();
       return;
     }
     return false;
   }, xbz);
 }

 function flvupd() {
   let fcount = 0;
   for(let key in convdata['bzl']) {
     for(let key2 in convdata['bzl'][key]['flv']) {
       if(convdata['bzl'][key]['flv'][key2] === true) ++fcount;
     }
   }
   if(fcount > 0) showhide_id.style.display = '';
   else showhide_id.style.display = 'none';
   cc_id.innerText = 'Выбрано: ' + fcount;
 }

 function getinplist() {
   let listr = '', lth;
   for(let key in convdata['bzl']) {
     if(listr == '') {
       listr = `<tr class="thclass"><td></td>`;
       for(let key2 in convdata['bzl'][key]['flv']) listr += `<td>${key2}</td>`;
       listr += '</tr>';
       lth = listr.replace('<td></td>', '<td><span id="cc_id" class="cclass">Выбрано: 0</span></td>');
     }
     listr += `<tr><td onclick="tdedit(convdata['bzl']['${key}']);">${convdata['bzl'][key]['title']}`;
     if(key.indexOf('dabkrss') != -1) listr += `<br><span class="ssinf">(大БКРС short, <a target="_blank" href="http://bkrs.info/p257">слова с чтением</a>)</span>`;
     listr += `<br><span class="cbzc">${key}</span></td>`;
     for(let key2 in convdata['bzl'][key]['flv']) {
       if(convdata['bzl'][key]['flv'][key2] === 'disabled') {
         listr += '<td></td>';
         continue;
       }
       let che = '';
       if(convdata['bzl'][key]['flv'][key2] === true) che = ' checked';
       listr += `<td><label class="onlbl"><input type="checkbox" onchange="convdata['bzl']['${key}']['flv']['${key2}']=this.checked;flvupd();"${che}/></label></td>`;
     }
     listr += '</tr>';
   }
   if(listr != '') listr += lth;

   if(listr == '') ulist_id.innerHTML = `<p>В каталогах <i><?php echo $dadir; ?></i> и <i><?php echo $addir; ?></i> пусто.</p><hr><p><button onclick="window.open(window.location,window.name);">Обновить</button></p>`;
   else ulist_id.innerHTML = `<table><tbody>${listr}</tbody></table`;
 }
  </script>
</head>
<body onload="getinplist();">
    <div class="diaok atop" id="diaok_id" style="display:none;" onmousedown="if(ok.mpda) ok.resall();" onmousemove="if(event.clientX > diaokbox_id.offsetLeft && event.clientX < +diaokbox_id.offsetLeft + +diaokbox_id.offsetWidth && event.clientY > diaokbox_id.offsetTop && event.clientY < +diaokbox_id.offsetTop + +diaokbox_id.offsetHeight) ok.mpda = false; else ok.mpda = true;">
      <div class="diaokbox" id="diaokbox_id"></div>
    </div>
    <div id="box_id">
      <form name="form_name" style="display:none;" onsubmit="return false;"><input type="hidden" name="convdata_name" id="convdata_name"/><input type="hidden" name="mtinfo_name" id="mtinfo_name"/></form>
      <div id="ulist_id"></div>
      <div style="display:none;" id="showhide_id" class="showhide">
        <button class="ibut" onclick="ok.ok('В зависимости от вычислительной скорости и количества выбранных пунктов, время конвертации может составить от минуты до часа и более.<br>Проследите чтобы вкладка не оказалась скрытой и устройство не ушло в спящий режим, иначе локальный сервер может быть замедлен или остановлен.<br>(<i>«настройки экрана» -> «не выключать экран»</i>)');">i</button><button onclick="ok.cancel('Подтвердите конвертацию',function(r){if(r) convstart(false);});"> Конвертировать </button>
        <hr><button class="ibut" onclick="ok.ok('Будет по <?php echo strval($tstnums); ?> слов в выбранных словарных базах. Используется в тестировании, когда нужна быстрая конвертация.');">i</button><button onclick="ok.cancel('Подтвердите тестовую конвертацию',function(r){if(r) convstart(true);});"> Тест </button>
      </div>
    </div>
    <hr><p class="infot"><a target="_blank" href="https://github.com/dictz">GitHub</a> | <a target="_blank" href="http://bkrs.info/taolun/thread-340497.html">Форум</a></p>
</body>
</html><?php } else { //_________________________________________________________________
include 'dsx/php/functions.php';
include 'dsx/php/convert_sd.php';
include 'dsx/php/convert_md.php';
include 'dsx/php/convert_dsl.php';
include 'dsx/php/convert_ht.php';

header("Access-Control-Allow-Origin: *");
$convdata = json_decode(base64_decode($_POST["convdata_name"]), true);
$mtinfo = json_decode(base64_decode($_POST["mtinfo_name"]), true);
$resstr = '';

$arp = array();
foreach ($convdata['bzl'] as $key => $val) {
  if(!$val['flv']['HTML']) continue;
  $tarp = explode('_', $key);
  foreach ($tarp as $key2 => $val2) $arp[] = $val2;
}
if(count($arp) > 0) {
  $arp = array_unique($arp);
  $tars = array(0,0);
  foreach ($arp as $val) {
    if(!isset($convdata['bzl'][$val]['grn'])) $tarc = explode('_', convert_ht($convdata['dadir'].$val.'_'.$convdata['bzdate'], $val, 'dsx/dict/'.$val.'.txt', $convdata['testfl']));
    else $tarc = explode('_', convert_ht($convdata['dadir'].$val, $val, 'dsx/dict/'.$val.'.txt', $convdata['testfl'], $convdata['bzl'][$val]['grn']));
    $tars[0] += intval(preg_replace('/[^\d]/','',$tarc[0]));
    $tars[1] += intval(preg_replace('/[^\d]/','',$tarc[1]));
  }
  $resstr = number_format($tars[0], 0, '', '.').'_'.number_format($tars[1], 0, '', '.');
  foreach ($convdata['bzl'] as $key => $val) {
    if(!$val['flv']['HTML']) continue;
    if(!isset($convdata['bzl'][$key]['grn'])) compile_ht($key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate']);
    else compile_ht($key, array($convdata['bzl'][$key]['grn'] => ''), $val['title'], $val['descr'], date('YmdHis',time()), $convdata['bzl'][$key]['grn']);
  }

  $arfiles = scandir('dsx/dict/');
  foreach ($arfiles as $key => $value) if(is_file('dsx/dict/'.$value)) @unlink('dsx/dict/'.$value);
}
if($resstr != '') goto theend;


foreach ($convdata['bzl'] as $key => $val) {
  if(!$val['flv']['StarDict']) continue;
  if(!isset($convdata['bzl'][$key]['grn'])) $resstr .= convert_sd($convdata['dadir'], $key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate'], $convdata['testfl']);
  else $resstr .= convert_sd($convdata['dadir'], $key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate'], $convdata['testfl'], $convdata['bzl'][$key]['grn']);
}
if($resstr != '') goto theend;


foreach ($convdata['bzl'] as $key => $val) {
  if(!$val['flv']['MDict']) continue;
  if(!isset($convdata['bzl'][$key]['grn'])) $resstr .= convert_md($convdata['dadir'], $key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate'], $convdata['testfl']);
  else $resstr .= convert_md($convdata['dadir'], $key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate'], $convdata['testfl'], $convdata['bzl'][$key]['grn']);
}
if($resstr != '') goto theend;


foreach ($convdata['bzl'] as $key => $val) {
  if($val['flv']['DSL'] !== true) continue;
  if(!isset($convdata['bzl'][$key]['grn'])) $resstr .= convert_dsl($convdata['dadir'], $key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate'], $convdata['testfl']);
  else $resstr .= convert_dsl($convdata['dadir'], $key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate'], $convdata['testfl'], $convdata['bzl'][$key]['grn']);
}

theend:
echo $resstr;
} ?>