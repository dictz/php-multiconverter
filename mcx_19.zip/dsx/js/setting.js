'use strict';
let setting = {
 start:function() {
   istorage.getItem('sin', function(val) {
     sin = JSON.parse(val);
     setting.sinlsupd();
   }, function() {
     istorage.setItem('sin', JSON.stringify(sin));
     setting.sinlsupd();
   });

   istorage.getItem('searchscheme_list', function(val) {
     searchscheme_list = JSON.parse(val);
   }, function() {
     istorage.setItem('searchscheme_list', JSON.stringify(searchscheme_list));
   });

   istorage.getItem('cur_searchscheme', function(val) {
     cur_searchscheme = val;
     setting.placeholder(cur_searchscheme);
   }, function() {
     istorage.setItem('cur_searchscheme', cur_searchscheme);
     setting.placeholder(cur_searchscheme);
   });

   istorage.getItem('cline', function(val) {
     setting.cline = oldcline = val;
   }, function() {
     istorage.setItem('cline', setting.cline);
   });

   istorage.getItem('hist', function(val) {
   }, function() {
     istorage.setItem('hist', JSON.stringify([]));
   });

   istorage.getItem('mar', function(val) {
   }, function() {
     let mar = {};
     for(let key in db_list) if(db_list[key].use) mar[key] = [];
     istorage.setItem('mar', JSON.stringify(mar));
   });

   istorage.getItem('cur_kblist', function(val) {
     cur_kblist = val;
   }, function() {
     istorage.setItem('cur_kblist', cur_kblist);
   });

   istorage.getItem('kbchars', function(val) {
     kbchars = val;
   }, function() {
     istorage.setItem('kbchars', kbchars);
   });

   istorage.getItem('usekbflag', function(val) {
     usekbflag = val;
   }, function() {
     istorage.setItem('usekbflag', usekbflag);
   });

   istorage.getItem('dsxcacheflag', function(val) {
     dsxcacheflag = val;
   }, function() {
     istorage.setItem('dsxcacheflag', false);
   });

   istorage.getItem('cachesymb', function(val) {
     cachesymb = JSON.parse(val);
     try{search.init();}catch(er){}
   }, function() {
     istorage.setItem('cachesymb', JSON.stringify(cachesymb));
   });

   istorage.getItem('cacheconf', function(val) {
     cacheconf = JSON.parse(val);
   }, function() {
     istorage.setItem('cacheconf', JSON.stringify(cacheconf));
   });

   let rl = [
     ['', '', 0, xl('set_seaset')],
     ['', '', 1, xl('set_chandinp')],
     ['', '', 2, xl('set_othsets')],
     ['', '', 3, xl('set_info')],
   ];
   selsetlist_id.dataset.xval = rl[0][2];
   ok.delay = true;
   setting.selsetlistmenu = ok.rlist('selsetlist_id', rl, function(id, val) {
     if(id !== false) {
       setting.showlist(+val);
       setting.curdsl = +val;
     }
   });

 },

 curdsl:99,

 show:function() {
   if(+setting.curdsl != +selsetlist_id.dataset.xval || +selsetlist_id.dataset.xval == 0) setting.showlist(+selsetlist_id.dataset.xval);
   setting.curdsl = +selsetlist_id.dataset.xval;
 },

 showlist:function(l) {
   if(l == 0) {
     displaybox_set_id.innerHTML = `<div class="setting"><div id="sscupdbox_id">${setting.sscupd()}</div>${setting.sinupd()}</div>`;
   } else if(l == 1) {
     displaybox_set_id.innerHTML = `<div class="setting setviewsymb">${setting.kbshowset()}${setting.symbview()}${setting.confview()}</div>`;
     if(dsxcacheflag) {
       charinfobox_cv_id.innerHTML = setting.symbviewact();
       confinfobox_cv_id.innerHTML = setting.confviewact();
     }
   } else if(l == 2) {
     displaybox_set_id.innerHTML = `<div class="setting">${setting.cschem()}${setting.linepage()}${setting.fontsize()}${setting.lssetreset()}</div>`;
   } else if(l == 3) {
     displaybox_set_id.innerHTML = '<br>' + dsx.infolistgen('fullname');
   }
 },

//================================================

 kbshowset:function() {
   let che = '';
   if(usekbflag === 'true') che = ' checked';
   return `<fieldset class="setkb"><legend>${xl('set_inpchar')}</legend>
   <label><input type="checkbox" onchange="setting.kbusef(this);"${che}/>${xl('set_useinp')}</label><br>
   <label>${xl('set_charkeys')}<br><textarea id="takbchars_id" oninput="keyboard.sset(this,event);">${kbchars}</textarea></label>
   </fieldset>`;
 },
 
 kbusef:function(t) {
   usekbflag = String(t.checked);
   if(usekbflag == 'false') keyboardbox_id.style.display = 'none';
   istorage.setItem('usekbflag', usekbflag);
 },

//================================================
 symgen:function() {
   cachesymb = symbols.cs();
   cacheconf = symbols.cc();
   symbols.pvclear();
   istorage.setItem('dsxcacheflag', true);
   istorage.setItem('cachesymb', JSON.stringify(cachesymb));
   istorage.setItem('cacheconf', JSON.stringify(cacheconf));
   dsxcacheflag = true;
   search.init();
 },

 symqc:function() {
   dsx.jsync([() => {
     cachesbut_id.innerText = xl('set_cachprog');
     cachesbut_id.onclick = '';
     diaok_id.onmousedown = function() {};
     setting.cokh = ok.ok(xl('set_cachprog'), undefined, '');
   }, () => {
     setting.symgen();
     ok.hide(setting.cokh);
     diaok_id.onmousedown = function() {if(ok.mpda) ok.resall();};
     setTimeout(function() {
       ok.cancel(xl('set_inexssc') + ' cmd -&gt; #exsscinstall', function(r) {
         if(r) {
           setting.exsscinstall();
           if(setting.curdsl == 0) setting.showlist(0);
           ok.autohide(1555, ok.ok(xl('set_sscinst'), undefined, ''));
         }
       });
     }, 5000);
     if(setting.curdsl == 1) setting.showlist(1);
   }]);
 },

 symbview:function() {
   if(!dsxcacheflag) return `<hr>&nbsp;<button onclick="setting.symqc();" id="cachesbut_id">${xl('set_showsym')}</button>`;
   else return `<fieldset><legend>${xl('set_viewsym')}</legend>
     <button class="mlist" id="seldbcharinfobox_id" data-xval=""></button>
     <button class="mlist" id="selplcharinfobox_id" data-xval=""></button><br>
     <div id="symbviewpagebox_id"></div>
     <input type="text" class="inputltr" id="infoinputcharinfobox_id" readonly/>
     <hr><div id="charinfobox_cv_id"></div>
   </fieldset>`;
 },

 symbviewactsi1:function(s, db) {
   if(s === undefined) {
     infoinputcharinfobox_id.style.display = 'none';
     return;
   }
   infoinputcharinfobox_id.value = `u{${(+s).toString(16).toLowerCase()}} [  ${String.fromCodePoint(+s)} ]`;
   infoinputcharinfobox_id.style.display = '';
 },

 symbviewact:function(db, plane, page = 1) {
   let rl = [];
   for(let key in db_list) {
     if(!db_list[key].use) continue;
     rl.push(['', '', key, db_list[key].name]);
   }
   rl.push(['', '', 'unicode', '(Unicode)']);
   if(db === undefined) db = rl[0][2];
   seldbcharinfobox_id.dataset.xval = db;
   ok.delay = true;
   seldbcharinfobox_id.onclick = ok.rlist('seldbcharinfobox_id', rl, function(id, val) {
     if(id !== false) charinfobox_cv_id.innerHTML = setting.symbviewact(val);
   });

   let rd = [];
   if(db == 'unicode') for(let p = 0; p < unicode_blocks.length; p++) rd.push(['', '', unicode_blocks[p][2], unicode_blocks[p][2]]);
   else for(let key in cachesymb[db]) rd.push(['', '', key, key]);
   if(plane === undefined) plane = rd[0][2];
   selplcharinfobox_id.dataset.xval = plane;
   ok.delay = true;
   selplcharinfobox_id.onclick = ok.rlist('selplcharinfobox_id', rd, function(id, val, d) {
     if(id !== false) charinfobox_cv_id.innerHTML = setting.symbviewact(d, val);
   }, undefined, db);

   let ca = dsx.symarr(db, plane).slice();
   
   let cavsx = 10, cavsy = 10*cavsx;
   let pag = +Math.trunc(ca.length/cavsy);
   if(ca.length%cavsy != 0) ++pag;
   let s_pag = (page-1)*cavsy;
   let f_pag = 0;
   if(+(+s_pag + +cavsy) >= +ca.length) f_pag = ca.length;
   else f_pag = +s_pag + +cavsy;
   
   if(+pag > 1) {
     let pl = [];
     for(let p = 1; p <= +pag; p++) pl.push(['','',+p,xl('set_page')+' '+p]);
     let sp = +page;
     if(page == 1) sp = +pag;
     else --sp;
     symbviewpagebox_id.innerHTML = `<button class="ico_arrow_l" data-xval="" onclick="charinfobox_cv_id.innerHTML=setting.symbviewact('${db}','${plane}',${sp});"></button>`;
     symbviewpagebox_id.innerHTML += `<button class="mlist" id="selpagsymbview_id" data-xval="" onclick="setting.selpagesymbview();"></button>`;
     selpagsymbview_id.dataset.xval = page;
     ok.delay = true;
     setting.selpagesymbview = ok.rlist('selpagsymbview_id', pl, function(id, val, d, p) {
       if(id !== false) charinfobox_cv_id.innerHTML = setting.symbviewact(d, p, val);
     }, undefined, db, plane);
     sp = +page;
     if(page == pag) sp = 1;
     else ++sp;
     symbviewpagebox_id.innerHTML += `<button class="ico_arrow_r" data-xval="" onclick="charinfobox_cv_id.innerHTML=setting.symbviewact('${db}','${plane}',${sp});"></button>`;
   } else symbviewpagebox_id.innerHTML = '';
   
   setting.symbviewactsi1();
   let res = '<table><tbody>';
   for(let i = +s_pag; i < +f_pag;) {
     res += '<tr>';
     for(let ii = 0; ii < cavsx; ii++) {
       if(i < +f_pag) {
         res += `<td onclick="setting.symbviewactsi1('${ca[i]}','${db}');">${dsx.tomnemonics(String.fromCodePoint(ca[i]))}</td>`;
         ++i;
       }
     }
     res += '</tr>';
   }
   res += '</tbody></table>';
   return res;
 },

//================================================

 confview:function() {
   if(!dsxcacheflag) return '';
   return `<fieldset><legend>${xl('set_homogl')}</legend>
     <button class="mlist" id="seldbconfinfobox_id" data-xval=""></button> <button onclick="setting.confuedit(this.dataset.db);" id="confuedit_id" data-db="">${xl('set_homedit')}</button><br>
     <div id="confviewpagebox_id"></div>
     <input type="text" class="inputltr" id="infoinputcharconfinfobox_id" readonly/>
     <hr><div id="confinfobox_cv_id"></div>
   </fieldset>`;
 },

 confuedit:function(db) {
   ok.constr(`
     <textarea id="confuedittextarea_id" oninput="" placeholder="" style="width:400px;height:50%;white-space:nowrap;">${dsx.objtotext(cacheconf[db],'','',[,1])}</textarea>
   `, `
     <button onclick="ok.hide();">${ok.txtbut('cancel')}</button>
     <button onclick="ok.dig('save');">${ok.txtbut('save')}</button>
   `, function(db, dbcs, m) {
     if(m == 'htset') {
     } else if(m == 'save') {
       function aler(er = '') {ok.autohide(3000, ok.ok(`${xl('set_notsaved')}<br>${er}`, undefined, ''));}
       if(confuedittextarea_id.value.length == 0) return aler(xl('set_fieldemp'));
       try {
         cacheconf[db] = JSON.parse(confuedittextarea_id.value).slice();
         confinfobox_cv_id.innerHTML = setting.confviewact(db);
       } catch(er) {
         cacheconf[db] = JSON.parse(dbcs).slice();
         confinfobox_cv_id.innerHTML = setting.confviewact(db);
         aler(er);
       }
       istorage.setItem('cacheconf', JSON.stringify(cacheconf));
       return;
     }
     return false;
   }, db, JSON.stringify(cacheconf[db]));
 },

 symbviewactsi3:function(s, db) {
   if(s === undefined) {
     infoinputcharconfinfobox_id.style.display = 'none';
     return;
   }
   infoinputcharconfinfobox_id.value = `u{${(+s).toString(16).toLowerCase()}} [  ${String.fromCodePoint(+s)} ]`;
   infoinputcharconfinfobox_id.style.display = '';
 },
 
 confviewact:function(db, page = 1) {
   let rl = [];
   for(let key in db_list) {
     if(!db_list[key].use) continue;
     rl.push(['', '', key, db_list[key].name]);
   }
   if(db === undefined) db = rl[0][2];
   seldbconfinfobox_id.dataset.xval = db;
   confuedit_id.dataset.db = db;
   ok.delay = true;
   seldbconfinfobox_id.onclick = ok.rlist('seldbconfinfobox_id', rl, function(id, val) {
     if(id !== false) confinfobox_cv_id.innerHTML = setting.confviewact(val);
   });
   
   let cavsy = 10, al = cacheconf[db].length;
   let pag = +Math.trunc(al/cavsy);
   if(al%cavsy != 0) ++pag;
   let s_pag = (page-1)*cavsy;
   let f_pag = 0;
   if(+(+s_pag + +cavsy) >= +al) f_pag = al;
   else f_pag = +s_pag + +cavsy;
   
   if(+pag > 1) {
     let pl = [];
     for(let p = 1; p <= +pag; p++) pl.push(['','',+p,xl('set_page')+' '+p]);
     let sp = +page;
     if(page == 1) sp = +pag;
     else --sp;
     confviewpagebox_id.innerHTML = `<button class="ico_arrow_l" data-xval="" onclick="confinfobox_cv_id.innerHTML=setting.confviewact('${db}',${sp});"></button>`;
     confviewpagebox_id.innerHTML += `<button class="mlist" id="confselpagsymbview_id" data-xval="" onclick="setting.confselpagesymbview();"></button>`;
     confselpagsymbview_id.dataset.xval = page;
     ok.delay = true;
     setting.confselpagesymbview = ok.rlist('confselpagsymbview_id', pl, function(id, val, d) {
       if(id !== false) confinfobox_cv_id.innerHTML = setting.confviewact(d, val);
     }, undefined, db);
     sp = +page;
     if(page == pag) sp = 1;
     else ++sp;
     confviewpagebox_id.innerHTML += `<button class="ico_arrow_r" data-xval="" onclick="confinfobox_cv_id.innerHTML=setting.confviewact('${db}',${sp});"></button>`;
   } else confviewpagebox_id.innerHTML = '';

   setting.symbviewactsi3();
   let res = '<table><tbody>';
   for(let i = +s_pag; i < +f_pag; i++) {
     res += '<tr>';
     for(let ii = 0; ii < cacheconf[db][i].length; ii++) {
       let n = cacheconf[db][i][ii].map(function(item){return Number('0x' + item);}).join(',');
       let st = cacheconf[db][i][ii].map(function(item){return String.fromCodePoint(Number('0x' + item));}).join('');
       res += `<td onclick="setting.symbviewactsi3('${n}','${db}');">${dsx.tomnemonics(st)}</td>`;
     }
     res += '</tr>';
   }
   res += '</tbody></table>';
   return res;
 },
 
//================================================

 sinupd:function(ef = true) {
   let ts = '';
   if(ef) ts = `<fieldset class="setsin"><legend>${xl('set_seamap')}</legend>`;
   for(let key in db_list) {
     if(!db_list[key].use) continue;
     ts += `<fieldset><legend>${dsx.tomnemonics(db_list[key].name)}</legend><table><tbody>`;
     for(let i = 0; i < db_list[key].columns.length; i++) {
       let che = '';
       if(setting.gsin(key, i)) che = ' checked';
       ts += `<tr><td><label><input type="checkbox" onchange="setting.sinlsupd2(this,'${key}','${i}');"${che}/>${dsx.tomnemonics(db_list[key].columns[i])}</label></td></tr>`;
     }
     ts += `</tbody></table></fieldset>`;
   }
   if(ef) ts += `</fieldset>`;
   return ts;
 },

 gsin:function(k, i, n) {
   for(let ii = 1; ii < sin.length; ii++) {
    if(sin[ii][0] == k) {
     if(n === undefined) return sin[ii][+i+2];
     else {
       sin[ii][+i+2] = n;
       return n;
   }}}
   ok.emer = true;
   ok.ok(xl('set_error'));
 },

 sinlsupd2:function(t, key, i) {
   setting.gsin(key, i, t.checked);
   let ba = false;
   for(let ii = 1; ii < sin.length; ii++) {
     if(!db_list[sin[ii][0]].use) continue;
     for(let m = 2; m < sin[ii].length; m++) {
       ba = ba || sin[ii][m];
   } }
   if(!ba) {
     ok.emer = true;
     ok.ok(xl('set_accancel'));
     t.checked = setting.gsin(key, i, true);
   }
   ba = false;
   for(let ii = 1; ii < sin.length; ii++) {
     for(let m = 2; m < sin[ii].length; m++) {
       ba = ba || sin[ii][m];
     }
     if(db_list[sin[ii][0]].use) sin[ii][1] = ba;
     else sin[ii][1] = false;
     ba = false;
   }
   istorage.setItem('sin', JSON.stringify(sin));
 },

 sinlsupd:function() {
   let ba = false;
   for(let ii = 1; ii < sin.length; ii++) {
     if(!db_list[sin[ii][0]].use) continue;
     for(let m = 2; m < sin[ii].length; m++) {
       ba = ba || sin[ii][m];
   } }
   if(!ba) {
     for(let ii = 1; ii < sin.length; ii++) {
       if(!db_list[sin[ii][0]].use) continue;
       sin[ii] = s_sin[ii].slice();
   } }
   ba = false;
   for(let ii = 1; ii < sin.length; ii++) {
     for(let m = 2; m < sin[ii].length; m++) {
       ba = ba || sin[ii][m];
     }
     if(db_list[sin[ii][0]].use) sin[ii][1] = ba;
     else sin[ii][1] = false;
     ba = false;
   }
   istorage.setItem('sin', JSON.stringify(sin));
 },

 getsin:function(dbn, s = sin) {
   let bt = false;
   for(let i = 1; i < s.length; i++) {
     if(s[i][0] == dbn) {
       let at = [];
       for(let m = 2; m < s[i].length; m++) at.push(s[i][m]);
       return [s[i][1], at.slice()];
   } }
   ok.emer = true;
   ok.ok(xl('set_error'));
 },

//================================================

 sscupd:function() {
   let ts = `<fieldset class="setssc"><legend>${xl('set_seasch')}</legend><table><tbody>`;
   for(let i=0; i<searchscheme_list.length; i++) {
    let che = ['', '', 'false', 'ico_edit'];
    if(i == cur_searchscheme) che[0] = ' checked';
    if(i != 0) che[1] = `<button onclick="setting.sscdelete(${i});" class="ico_del"></button>`;
    else {che[2] = 'true'; che[3] = 'ico_rdnl';}
    if(searchscheme_list[i][3].includes('txt') || searchscheme_list[i][3].includes('reg')) ts += `<tr><td><label><input type="radio" id="ssc_id${i}" onchange="setting.ssclsupd(${i});" name="sscradio"${che[0]}/>${dsx.tomnemonics(searchscheme_list[i][0])}</label></td><td><button onclick="setting.sscedit(${i},${che[2]});" class="${che[3]}"></button></td><td><button onclick="setting.sscexport(${i});" class="ico_exp"></button></td><td>${che[1]}</td></tr>`;
    else ts += `<tr><td><span class="ico_sea"></span><button id="ssc_id${i}" onclick="search.go(${i});">${dsx.tomnemonics(searchscheme_list[i][0])}</button></td><td><button onclick="setting.sscedit(${i});" class="${che[3]}"></button></td><td><button onclick="setting.sscexport(${i});" class="ico_exp"></button></td><td>${che[1]}</td></tr>`;
   }
   ts += `<tr><td></td><td></td><td><button onclick="setting.sscimport();" class="ico_imp"></button></td><td><button onclick="setting.sscadd();" class="ico_add"></button></td></tr>
   </tbody></table></fieldset>`;
   return ts;
 },
 
 sscexport:function(i) {
   ok.constr(`
     <textarea cols="30" rows="7" id="settaexport_id" style="white-space:normal;" onclick="this.selectionStart=0;this.selectionEnd=this.value.length;" readonly></textarea>
   `, `
     <button onclick="ok.hide();">${ok.txtbut('close')}</button>
     <button onclick="ok.dig('copy');" id="setexportcopybut_id">${xl('set_copy')}</button>
     <button onclick="ok.dig('aimp');" class="ico_aimp_r"></button>
   `, function(i, m) {
     if(m == 'htset') {
       settaexport_id.value = JSON.stringify(searchscheme_list[i]);
       if(String(window.location).replace(/^https:/i,'') == String(window.location)) setexportcopybut_id.style.display = 'none';
     } else if(m == 'copy') {
       navigator.clipboard.writeText(JSON.stringify(searchscheme_list[i])).then(
         function() {ok.autohide(1111, ok.ok(xl('set_copied'), undefined, ''));},
         function() {ok.autohide(1111, ok.ok(xl('set_ncopied'), undefined, ''));}
       );
       return;
     } else if(m == 'aimp') {
       setting.sscadd(JSON.parse(settaexport_id.value).slice());
       return;
     }
     return false;
   }, i);
 },

 sscimport:function() {
   ok.cancel(`<textarea cols="30" rows="7" ondblclick="navigator.clipboard.readText().then(function(txt){sscimporttext_id.value=txt;},function(){});" style="white-space:normal;" id="sscimporttext_id" placeholder="${xl('set_impplhol')}"></textarea>`, function(r) {
     if(r) {
       function aler(er = '') {ok.autohide(1555, ok.ok(`${xl('set_notimp')}<br>${er}`, undefined, ''));}
       if(sscimporttext_id.value.length == 0) return aler(xl('set_fieldemp'));
       try {
         setting.sscadd(JSON.parse(sscimporttext_id.value).slice());
       } catch(er) {
         aler(er);
       }
     }
   }, undefined, xl('set_import'));
 },

 exsscinstall:function() {
   searchscheme_list.length = 0;
   searchscheme_list = searchscheme_list_ex.slice();
   istorage.setItem('searchscheme_list', JSON.stringify(searchscheme_list));
   setting.ssclsupd(5);
 },

 ssclsupd:function(i) {
   cur_searchscheme = i;
   setting.placeholder(i);
   istorage.setItem('cur_searchscheme', cur_searchscheme);
 },

 placeholder:function(i) {
   word_id.placeholder = word_m_id.placeholder = searchscheme_list[i][0];
 },

 sscdelete:function(i) {
   if(i == 0) return;
   ok.cancel(`${xl('set_delschem')}<br>«${dsx.tomnemonics(searchscheme_list[i][0])}»`, function(r, i) {
     if(r) {
       searchscheme_list.splice(i, 1);
       if(cur_searchscheme == i) cur_searchscheme = 0;
       if(cur_searchscheme > i) --cur_searchscheme;
       sscupdbox_id.innerHTML = setting.sscupd();
       setting.placeholder(cur_searchscheme);
       istorage.setItem('searchscheme_list', JSON.stringify(searchscheme_list));
       istorage.setItem('cur_searchscheme', cur_searchscheme);
     }
   }, undefined, undefined, i);
 },

 sscadd:function(xar = ['','','','','','']) {
   setting.sscaedialog(false, xar.slice(), function(ar) {
     searchscheme_list.push(ar.slice());
     sscupdbox_id.innerHTML = setting.sscupd();
     istorage.setItem('searchscheme_list', JSON.stringify(searchscheme_list));
   });
 },

 sscedit:function(i, ro = false) {
   setting.sscaedialog(ro, searchscheme_list[i].slice(), function(ar, i, fr) {
     searchscheme_list[i] = ar.slice();
     if(fr && i == cur_searchscheme) cur_searchscheme = 0;
     setting.placeholder(cur_searchscheme);
     sscupdbox_id.innerHTML = setting.sscupd();
     istorage.setItem('searchscheme_list', JSON.stringify(searchscheme_list));
     istorage.setItem('cur_searchscheme', cur_searchscheme);
   }, i);
 },

 sscaedialog:function(ro, ar, f, i) {
   let rdnl = '';
   if(ro) rdnl = ' readonly';
   ok.constr(`<fieldset class="sscaedialog">
       <legend>${xl('set_name')}</legend>
       <input type="text" size="30" autocomplete="off" id="sscaedialog_inp_id1" value="${dsx.tomnemonics(ar[0])}" placeholder="${xl('set_name')}"${rdnl}/>
     </fieldset>
     <fieldset class="sscaedialog">
       <legend>${xl('set_scheme')}</legend>
       <input type="text" size="30" class="inputltr" autocomplete="off" id="sscaedialog_inp_id4" value="${dsx.tomnemonics(ar[3])}" oninput="ok.dig('oninput',this.value);" placeholder="${xl('set_regexp')}"${rdnl}/><br>
       <textarea cols="30" rows="8" id="sscaedialog_inp_id5" placeholder="${xl('set_function')}"${rdnl}>${dsx.tomnemonics(ar[4])}</textarea>
     </fieldset>
     <fieldset class="sscaedialog" id="sscaedialog_entr_id" style="display:none;">
       <legend>${xl('set_inphand')}</legend>
       <input type="text" size="30" class="inputltr" autocomplete="off" id="sscaedialog_inp_id2" value="${dsx.tomnemonics(ar[1])}" oninput="ok.dig('oninput2',this.value);" placeholder="${xl('set_regexp')}"${rdnl}/><br>
       <textarea cols="30" rows="8" id="sscaedialog_inp_id3" placeholder="${xl('set_function')}" style="display:none;"${rdnl}>${dsx.tomnemonics(ar[2])}</textarea>
     </fieldset>
     <fieldset class="sscaedialog">
       <legend>${xl('set_toexe')}</legend>
       <textarea cols="30" rows="12" id="sscaedialog_inp_id6" placeholder="${xl('set_function')}"${rdnl}>${dsx.tomnemonics(ar[5])}</textarea>
     </fieldset>
   `, `
     <button onclick="ok.hide();" id="sscaedialog_closebut_id" style="display:none;">${ok.txtbut('close')}</button>
     <button onclick="ok.hide();" id="sscaedialog_cancelbut_id">${ok.txtbut('cancel')}</button>
     <button onclick="ok.dig('save');" id="sscaedialog_savebut_id">${ok.txtbut('save')}</button>
   `, function(ro, ar, f, i, m, v) {
     if(m == 'htset') {
       if(ar[3].includes('txt') || ar[3].includes('reg')) sscaedialog_entr_id.style.display = '';
       if(ar[1].length != 0) sscaedialog_inp_id3.style.display = '';
       if(ro) {
         sscaedialog_cancelbut_id.style.display = 'none';
         sscaedialog_savebut_id.style.display = 'none';
         sscaedialog_closebut_id.style.display = '';
       }
     } else if(m == 'save') {
       let inpar = [];
       inpar[0] = sscaedialog_inp_id1.value;
       inpar[1] = sscaedialog_inp_id2.value;
       inpar[2] = sscaedialog_inp_id3.value;
       inpar[3] = sscaedialog_inp_id4.value;
       inpar[4] = sscaedialog_inp_id5.value;
       inpar[5] = sscaedialog_inp_id6.value;
       function testname(name, i) {
         if(name.length == 0) return false;
         for(let ii = 0; ii < searchscheme_list.length; ii++) if(ii != i && name == searchscheme_list[ii][0]) return false;
         return true;
       }
       if(!testname(inpar[0], i)) {sscaedialog_inp_id1.focus(); return false;}
       if(!regtest(inpar[3])) {sscaedialog_inp_id4.focus(); return false;}
       function testfunc(fu, rfl, mod) {
         function ttt(mod) {
           try {
             let uol = {};
             if(mod == 2) eval(`(${fu})('test', 't '.repeat(999).split(' '), 0, 'test', uol, uog);`);
             else if(mod == 4) eval(`(${fu})('test', 't '.repeat(999).split(' '));`);
             else if(mod == 5) eval(`(${fu})('test');`);
             return true;
           } catch(e) {
             return false;
         } }
         if(fu.length != 0) return ttt(mod);
         else {
           if(rfl) return false;
           else return true;
       } }
       if(!testfunc(inpar[4], false, 4)) {sscaedialog_inp_id5.focus(); return false;}
       let fr = 'false';
       if(inpar[3].includes('txt') || inpar[3].includes('reg')) {
         if(inpar[1].length != 0) {
           if(!regtest(inpar[1])) {sscaedialog_inp_id2.focus(); return false;}
           if(!testfunc(inpar[2], true, 2)) {sscaedialog_inp_id3.focus(); return false;}
       } } else fr = 'true';
       if(!testfunc(inpar[5], false, 5)) {sscaedialog_inp_id6.focus(); return false;}
       eval(`(${f})([inpar[0],inpar[1],inpar[2],inpar[3],inpar[4],inpar[5]],i,${fr});`);
       return;
     } else if(m == 'oninput') {
       if(v.includes('txt') || v.includes('reg')) sscaedialog_entr_id.style.display = '';
       else sscaedialog_entr_id.style.display = 'none';
     } else if(m == 'oninput2') {
       if(v.length != 0) sscaedialog_inp_id3.style.display = '';
       else sscaedialog_inp_id3.style.display = 'none';
     }
     return false;
   }, ro, ar, f.toString(), i);
 },

//================================================

 cschemesett:'auto',
 cschem:function() {
   let ch = ['', ''];
   if(setting.cschemesett == 'auto') ch[0] = ' checked';
   else ch[1] = ' checked';
   return `
     <fieldset id="misc_cschem_id">
       <legend>${xl('set_colorman')}</legend>
       <label><input type="radio" name="set_cschem_name" onchange="setting.cschemesettupd(true);" id="set_cschem_id1"${ch[0]}/>${xl('set_clrauto')}</label><br><br>
       <label><input type="radio" name="set_cschem_name" onchange="setting.cschemesettupd(false);" id="set_cschem_id2"${ch[1]}/>${xl('set_clrremem')}</label>
     </fieldset>
   `;
 },

 cschemesettupd:function(opt) {
   if(opt) setting.cschemesett = 'auto';
   else setting.cschemesett = cscheme.curcscheme;
   istorage.setItem('cschemesett', setting.cschemesett);
 },

//================================================

 cline:20,
 linepage:function() {
   return `
     <fieldset id="misc_optout_id">
       <legend>${xl('set_linespag')}</legend>
       <form onsubmit="return false;"><input type="number" value="${setting.cline}" data-clineval="${setting.cline}" placeholder="20(1-?)" oninput="setting.linepageupd(this);" onkeydown="if(event.key=='Enter'){this.blur();}"/></form>
     </fieldset>
   `;
 },

 linepageupd:function(t) {
   if(+t.value < 1 || t.value.length == 0) t.dataset.clineval = 20;
 //else if(+t.value > 100) t.dataset.clineval = 100;
   else t.dataset.clineval = t.value;
   setting.cline = +t.dataset.clineval;
   istorage.setItem('cline', setting.cline);
 },

//================================================

 curfsize:'1.2', //rem
 fontsize:function() {
   return `
     <fieldset id="optstart_fsize_id">
       <legend>${xl('set_fontsize')}</legend>
       <table><tbody><tr>
         <td colspan="2" id="fsize_out_id">${setting.curfsize}</td>
       </tr><tr>
         <td onclick="setting.updfontsize1('+');"><span class="ico_add"></span></td>
         <td onclick="setting.updfontsize1('-');"><span class="ico_sub"></span></td>
       </tr></tbody></table>
     </fieldset>
   `;
 },

 updfontsize1:function(d) {
   if(d == '-' && +fsize_out_id.innerText > 0.6) {
     fsize_out_id.innerText = +(+fsize_out_id.innerText - 0.02).toFixed(2);
   } else if(d == '+') {
     fsize_out_id.innerText = +(+fsize_out_id.innerText + 0.02).toFixed(2);
   }
   setting.curfsize = fsize_out_id.innerText;
   setting.updfontsize2();
   istorage.setItem('curfsize', setting.curfsize);
 },

 updfontsize2:function() {
   dsx.setel('style', 'fontsize_id', `.dsxfs, body, input, textarea, select, button, table, tbody, tr, td, th, legend, option, div, form, span, p {font-size:${setting.curfsize}rem;}`);
   dsx.run(33, 'displaymargin', ()=>{dsx.margin();});
 },

//================================================

 lssetreset:function() {
   return `
     <fieldset>
       <legend>${xl('set_resetset')}</legend>
       <button id="resetbut_id" onclick="setting.resetdialog();">${xl('set_reset')}</button>
     </fieldset>
   `;
 },

 resetdialog:function() {
   ok.cancel(xl('set_resconti'), function(r) {
     if(r) {
       dsx.restart = true;
       diaok_id.onmousedown = function() {};
       istorage.clear();
       ok.ok(xl('set_doneres'), function() {}, '');
     }
   });
 },

//================================================


};
