'use strict';
let cscheme = {
 curcscheme:'',
 dlbutton:function(f) {
   if(f == 'dark') {
     cscheme.curcscheme = 'dark';
     cscheme_id.classList.remove('ico_dark');
     cscheme_id.classList.add('ico_light');
   } else if(f == 'light') {
     cscheme.curcscheme = 'light';
     cscheme_id.classList.remove('ico_light');
     cscheme_id.classList.add('ico_dark');
   }
 },

 selcscheme:function(sel = cscheme.curcscheme, sf = false) {
   let nn = ['light', 'dark'];
   if(sf) {nn.length = 0; nn = ['dark', 'light'];}
   if(sel == nn[0]) {
     dsx.setel('style', 'colorstyle_id', cscheme.color_dark);
     ChromeSBPColor_id.content = '#333';
     cscheme.dlbutton('dark');
   } else if(sel == nn[1]) {
     dsx.setel('style', 'colorstyle_id', cscheme.color_light);
     ChromeSBPColor_id.content = '#eee';
     cscheme.dlbutton('light');
   }
   if(setting.cschemesett != 'auto') setting.cschemesettupd(false);
 },

 pstart:function() {
   istorage.getItem('cschemesett', function(val) {
     setting.cschemesett = val;
     cscheme.start();
   }, function() {
     istorage.setItem('cschemesett', setting.cschemesett);
     cscheme.start();
   });
 },

 start:function() {
   const dlCScheme = window.matchMedia("(prefers-color-scheme: dark)");
   dlCScheme.addEventListener("change", function(e) {
     if(setting.cschemesett != 'auto') {
       cscheme.selcscheme(setting.cschemesett, true);
       return;
     }
     if(e.matches) cscheme.dlbutton('dark');
     else cscheme.dlbutton('light');
     if(g('colorstyle_id')) g('colorstyle_id').remove();
   });

   if(setting.cschemesett == 'auto') {
     getComputedStyle(document.body).backgroundColor.replace(/\d{1,3}/, function(match) {
       if(+match > 127) cscheme.dlbutton('light');
       else if(+match < 127) cscheme.dlbutton('dark');
       return match;
     });
   } else cscheme.selcscheme(setting.cschemesett, true);
 },

 color_dark:`
  body, textarea, div, input, select, option, button, table, fieldset, hr {
    color: #ddd;
    background-color: #333;
  }
  .wo {
    color: #e88;
  }
  .wo_sel {
    color: #000;
    background-color: #eee;
  }
  ::selection {
    color: black;
    background: yellow;
  }
  button:disabled {
   color: gray;
  }
  .nsecurdbinmapsea {
   border-top-color: gray;
  }
  input[type="radio"]:checked::before, 
  input[type="checkbox"]:checked::before {
    color: yellow !important;
  }
  input[type="radio"]:checked:disabled::before,
  input[type="checkbox"]:checked:disabled::before {
   color: gray !important;
  }`,

 color_light:`
  body, textarea, div, input, select, option, button, table, fieldset, hr {
    color: #000;
    background-color: #eee;
  }
  .wo {
    color: #e33;
  }
  .wo_sel {
    color: #fff;
    background-color: #444;
  }
  ::selection {
    color: black;
    background: lightskyblue;
  }
  button:disabled {
   color: lightgray;
  }
  .nsecurdbinmapsea {
   border-top-color: lightgray;
  }
  input[type="radio"]:checked::before, 
  input[type="checkbox"]:checked::before {
    color: #55f !important;
  }
  input[type="radio"]:checked:disabled::before,
  input[type="checkbox"]:checked:disabled::before {
   color: gray !important;
  }`,

};
