<?php 
function restfunc($dafnam, $wordcount, $wordcountall) {
  $wd = $wordcountall - $wordcount;
  $gs = '';
  if($wd != 0) $gs = ' (-'.number_format($wd,0,'',' ').')';
  return '<tr><td>'.$dafnam.'</td><td>'.number_format($wordcount,0,'',' ').$gs.'</td></tr>';
}

function ucmp($a, $b) {
  $c = mb_strtolower($a);
  $d = mb_strtolower($b);
  if($c == $d) {
    if($a == $b) return 0;
    return ($a < $b) ? -1 : 1;
  }
  return ($c < $d) ? -1 : 1;
}

function rrmdir($src) {
  $dir = opendir($src);
  if($dir === false) return false;
  while(false !== ( $file = readdir($dir)) ) {
    if(( $file != '.' ) && ( $file != '..' )) {
      $full = $src . '/' . $file;
      if( is_dir($full) ) {
        rrmdir($full);
      } else {
        @unlink($full);
      }
    }
  }
  closedir($dir);
  @rmdir($src);
}

function zipc($zipdn) {
  @unlink($zipdn.'.zip');
  if(!$GLOBALS['option_zip']) return false;

  $farr = scandir($zipdn);
  if($farr === false) return false;
  foreach ($farr as $key => $val) if(!is_file($zipdn.'/'.$val)) unset($farr[$key]);
  if(count($farr) == 0) return false;

  $zip = new ZipArchive();
  if($zip->open($zipdn.'.zip', ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
    foreach ($farr as $key => $val) {
      if($zip->addFile($zipdn.'/'.$val, $val) === false) {$zip->close(); return false;}
    }
    if($GLOBALS['zip_password'] != '') {
      $zip->setPassword($GLOBALS['zip_password']);
      foreach ($farr as $key => $val) {
        if($zip->setEncryptionName($val, ZipArchive::EM_AES_128) === false) {$zip->close(); return false;}
      }
    }
    $zip->close();
    if($GLOBALS['zip_srccatdel']) rrmdir($zipdn);
    return true;
  } else return false;
}

function fgsit($fp, $dafnam) {
  if($dafnam == 'dabkrs' || $dafnam == 'dabkrss' || $dafnam == 'dabruks') $b = fread($fp, 3);
  while(true) {
    if(mb_substr(trim(fgets($fp)),0,1) != '#') break;
  }
}

function dzipc($ddir, $fext, $form, $compress) {
  if($compress == 0) return false;
  $farr = scandir($ddir);
  if($farr === false) return false;
  foreach ($farr as $key => $val) if(!is_file($ddir.'/'.$val) || preg_match('/\.'.$fext.'$/', $val) != 1 || filesize($ddir.'/'.$val) == 0) unset($farr[$key]);
  if(count($farr) == 0) return false;

  foreach ($farr as $key => $val) {
    $fnread = $ddir.'/'.$val;
    $fsz = filesize($fnread);
    if($form == 'dz') if($fsz > (0xfff4/2)*58900) continue;
    $fhcrc = pack('V', implode('', unpack('N', hash_file('crc32b', $fnread, true))));
    $fzhead = "\x1f\x8b\x08";
    if($form == 'dz') $fzhead .= "\x04";
    else $fzhead .= "\x00";
    $fzhead .= pack('V', time())."\x02\x03";
    $brsz = 102400;
    if($form == 'dz') $brsz = 58900;
    
    $fnwrite = $fnread.'.gz';
    if($form == 'dz') $fnwrite = '~dz.tmp';

    $defcontext = deflate_init(ZLIB_ENCODING_GZIP, ['level' => $compress]); 
    $dsxxx = deflate_add($defcontext, "\x64\x73\x78", ZLIB_FULL_FLUSH);

    $gzextrar = array();
    $fhwrite = fopen($fnwrite, 'a');
    if($form != 'dz') fwrite($fhwrite, $fzhead);
    $fhread = fopen($fnread, 'r');
    $ftmpsz = $fsz;
    for( ; ; ) {
      if($ftmpsz > $brsz) {
        $gzextrar[] = fwrite($fhwrite, deflate_add($defcontext, fread($fhread, $brsz), ZLIB_FULL_FLUSH));
        $ftmpsz -= $brsz;
      } else if($ftmpsz == 0) {
        break;
      } else {
        $gzextrar[] = fwrite($fhwrite, deflate_add($defcontext, fread($fhread, $ftmpsz), ZLIB_FULL_FLUSH));
        break;
      }
    }
    $dsxxx = deflate_add($defcontext, '', ZLIB_FINISH);
    fclose($fhread);
    unlink($fnread);
    if($form != 'dz') {
      fwrite($fhwrite, "\x03\x00");
      fwrite($fhwrite, $fhcrc);
      fwrite($fhwrite, pack('V', $fsz));
    }
    fclose($fhwrite);
    if($form != 'dz') continue;

    $fhread = fopen($fnwrite, 'r');
    $fhwrite = fopen($fnread.'.dz', 'a');
    fwrite($fhwrite, $fzhead);
    $dzxlen = (count($gzextrar)*2)+10;
    fwrite($fhwrite, pack('v', $dzxlen));
    fwrite($fhwrite, "\x52\x41");
    fwrite($fhwrite, pack('v', $dzxlen-4));
    fwrite($fhwrite, "\x01\x00");
    fwrite($fhwrite, pack('v', $brsz));
    fwrite($fhwrite, pack('v', count($gzextrar)));
    foreach ($gzextrar as $key => $val) fwrite($fhwrite, pack('v', $val));
    $ftmpsz = filesize($fnwrite);
    $brsz = 102400;
    for( ; ; ) {
      if($ftmpsz > $brsz) {
        fwrite($fhwrite, fread($fhread, $brsz));
        $ftmpsz -= $brsz;
      } else if($ftmpsz == 0) {
        break;
      } else {
        fwrite($fhwrite, fread($fhread, $ftmpsz));
        break;
      }
    }
    unlink($fnwrite);
    fwrite($fhwrite, "\x03\x00");
    fwrite($fhwrite, $fhcrc);
    fwrite($fhwrite, pack('V', $fsz));
    fclose($fhwrite);
  }
  return true;
}

?>