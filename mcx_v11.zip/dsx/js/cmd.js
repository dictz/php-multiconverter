'use strict';
let cmd = {
 init:function() {},
 show:function() {},

 cm:'',
 cmar:[],
 run:function() {
   cmd.cm = cmd_id.value;
   cmd.cmar = [];
   if(cmd.cm.search(/(?<=[^\\]):/u) != -1) {
     cmd.cmar = cmd.cm.split(/(?<=[^\\]):/u);
     cmd.cm = cmd.cmar[0];
     cmd.cmar = cmd.cmar[1].split(/(?<=[^\\]),/u).map(function(item) {
       try {
         return eval(`'${item}'`);
       } catch(er) {
         ok.ok(er);
         return item.replace(/\\n/gu, '\n').replace(/\\(?=[^\\])/gu, '').replace(/\\\\/gu, '\\');
       }
     });
   }
   cmd.cm = cmd.cm.toLowerCase();
   
   dsx.jsync([() => {
     displaybox_cmd_id.innerHTML = xl('cmd_exe');

   }, () => {
     let result = '';

     if(cmd.cm == '#cmd') {
       result = `<textarea cols="30" rows="14" ondblclick="try{cmd_cmd_res_id.innerHTML=eval('('+this.value+')();');}catch(er){ok.ok(er);}">function() {\n  \n  \n  return ;\n}</textarea><hr><div class="setting setviewsymb" id="cmd_cmd_res_id"></div>`;

     } else if(cmd.cm == '#exsscinstall') {
       if(dsxcacheflag) setting.exsscinstall();
       else result = xl('cmd_symcach') + ' (#cachesymbol)';

     } else if(cmd.cm == '#cachesymbol') {
       if(!dsxcacheflag) setting.symgen();
       else result = xl('cmd_cachear');

     } else if(cmd.cm == '#sscexport') {
       result = `<pre>\n\n${dsx.objtotext(searchscheme_list,'','',[,3])}\n\n</pre>`;

     } else if(cmd.cm == '#dbdel') {
       try {
         for(let key in db_list) if(db_list[key].use) eval(`${key}.length=0;`);
         dsx.restart = true;
       } catch(er) {ok.ok(er);}

     } else {
       result = xl('cmd_miss');
       function ty(f) {try{if(f in cmd){return true;}else{return false;}}catch(er){ok.ok(er);}}
       if(!'init,show,run,cm,cmar,uag'.includes(cmd.cm)) if(ty(cmd.cm)) {
         try {
           result = cmd[cmd.cm](...cmd.cmar);
         } catch(er) {
           ok.ok(er);
         }
       }
     }

     if(result != '') displaybox_cmd_id.innerHTML = result;
     else displaybox_cmd_id.innerHTML = `${xl('cmd_done')}: ${cmd.cm}`;
   }]);
 },

 help:function(...xt) {
   if(xt.length != 0) return `<pre> ${xt.join('\n ')}</pre>`;
   else return `<pre>
 statinit   :();
 statsave   :(dlg = false, fname = 'stat.txt');
 statout    :(p1=0, p2='');
 statsearch :(p1='', p2='');
 statdel    :(p1='', p2=p1);
 statclear  :();
</pre>`;
 },

 ccview:function(st = '', sn = 16, bef = 'u{', aft = '}\n') {
   if(String(+sn) == 'NaN') return 'Not argument (radix 2 - 36)';
   if(+sn < 2 || +sn > 36) return 'Radix 2 - 36';
   let stri = '';
   for(let ch of st) stri += `${bef}${ch.codePointAt(0).toString(+sn).toLowerCase()}${aft}`;
   return '<textarea cols="30" rows="14" ondblclick="cmd_cmd_res_id.innerHTML=this.value">' + stri + '</textarea><hr><div class="setting setviewsymb" id="cmd_cmd_res_id"></div>';
 },

 uag:[],
 statinit:function() {
   if(cmd.uag.length > 0) return `<b>&nbsp;Length: ${cmd.uag.length}</b>`;
   let srr = '_:';
   for(let key in uog) cmd.uag.push(String(key) + srr + String(uog[key]));
   uog = {};
   cmd.uag.sort(function(a, b) {
     let aa = a.split(srr)[1], bb = b.split(srr)[1];
     if(+aa < +bb) return 1;
     if(+aa == +bb) return 0;
     if(+aa > +bb) return -1;
   });
   return `<b>&nbsp;Initialized. Length: ${cmd.uag.length}</b>`;
 },

 statsave:function(dlg = false, fname = 'stat.txt') {
   if(dlg) {
     ok.cancel(xl('cmd_stsave'), function(r, fname) {
       if(r) {
         if(cmd.uag.length > 0) dsx.savefile(fname, [new Uint8Array([0xef,0xbb,0xbf]), cmd.uag.join('\n')]);
       }
     }, undefined, undefined, fname);
     return;
   }
   if(cmd.uag.length > 0) dsx.savefile(fname, [new Uint8Array([0xef,0xbb,0xbf]), cmd.uag.join('\n')]);
   return `<b>&nbsp;Length: ${cmd.uag.length}</b>`;
 },

 statout:function(p1 = 0, p2 = '') {
   if(p2 == '') p2 = cmd.uag.length;
   else if(String(+p2) == 'NaN') return 'Not argument (number)';
   else if(+p2 > cmd.uag.length) p2 = cmd.uag.length;
   if(String(+p1) == 'NaN') return 'Not argument (number)';
   if(!confirm('Confirm')) return 'statout: cancelled';
   return '<textarea cols="30" rows="14">' + cmd.uag.slice(+p1, +p2).join('\n') + '</textarea>';
 },

 statsearch:function(p1 = '', p2 = '') {
   if(p1 == '') return 'Not argument (RegExp or number)';
   let stri = [];
   if(String(+p1) == 'NaN') {
     for(let i = 0; i < cmd.uag.length; i++) if(cmd.uag[i].search(eval(`/${p1}/ui`)) != -1) stri.push(cmd.uag[i]);
   } else {
     for(let i = 0; i < cmd.uag.length; i++) if(+cmd.uag[i].split('_:')[1] == +p1) stri.push(cmd.uag[i]);
   }
   if(String(+p1) == 'NaN') {
     if(p2 == '') return `<b>&nbsp;RegExp "${p1}" : ${stri.length}</b>`;
   } else {
     if(p2 == '') return `<b>&nbsp;Number ${p1} : ${stri.length}</b>`;
   }
   if(!confirm('Confirm')) return 'statsearch: cancelled';
   return '<textarea cols="30" rows="14">' + stri.join('\n') + '</textarea>';
 },

 statdel:function(p1 = '', p2 = p1) {
   if(p1 == '') return 'Not argument (number)';
   if(String(+p1) == 'NaN' || String(+p2) == 'NaN') return 'Not argument (number)';
   let cnt = 0;
   let tear = [];
   for(let i = 0; i < cmd.uag.length; i++) {
     let xi = +cmd.uag[i].split('_:')[1];
     if(xi >= +p1 && xi <= +p2) ++cnt;
     else tear.push(cmd.uag[i]);
   }
   cmd.uag = tear.slice();
   return `<b>&nbsp;Deleted: ${cnt}; Length: ${cmd.uag.length}</b>`;
 },

 statclear:function() {
   cmd.uag.length = 0;
   return `<b>&nbsp;Length: ${cmd.uag.length}</b>`;
 },

};
