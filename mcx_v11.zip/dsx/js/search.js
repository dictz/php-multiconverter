'use strict';
let searchcache = {}, rbackstack = [], crstack = 0, oldcline;
let search = {
 init:function() {
   for(let key in db_list) {
     if(!db_list[key].use) continue;
     curdbforfuncex = key;
     if(!(key in dbpalaneranges)) dbpalaneranges[key] = [];
     for(let plane in cachesymb[key]) {
       let aa = cachesymb[key][plane].block.split('-');
       dbpalaneranges[key].push([Number('0x' + aa[0]), Number('0x' + aa[1])]);
     }
   }
 },

 showflag:false,
 show:function() {
   search.showflag = true;
   if(rbackstack.length != 0) if(oldcline != setting.cline) for(let i = 0; i < rbackstack.length; i++) rbackstack[i][2] = 1;
   oldcline = setting.cline;
   if(crstack != 0) search.pcacheout(...rbackstack[crstack - 1]);
 },

 hide:function() {
   search.showflag = false;
 },
 
 gettimestring:function() {
   let nd = new Date;
   return `${nd.getDate()}-${+nd.getMonth()+1}-${nd.getFullYear()}_${nd.getHours()}:${nd.getMinutes()}:${nd.getSeconds()}`;
 },

 rback:function(mf, sids, sci, db, pg) {
   if(mf == 'reset') {
     rbackstack.length = 0;
     crstack = 0;
     butrback_id.disabled = true;
     butrnext_id.disabled = true;
   } else if(mf == 'add') {
     for(let i = 0; i < rbackstack.length; ) {
       if(JSON.parse(rbackstack[i][0]).sid === JSON.parse(sids).sid) rbackstack.splice(i, 1);
       else ++i;
     }
     //if(crstack < rbackstack.length) rbackstack.splice(crstack, rbackstack.length - crstack, [sids, db, pg, sci]);
     //else rbackstack.push([sids, db, pg, sci]);
     rbackstack.push([sids, db, pg, sci]);
     crstack = rbackstack.length;
     if(rbackstack.length > 1) butrback_id.disabled = false;
     else butrback_id.disabled = true;
     butrnext_id.disabled = true;
     dsx.dispscroll();
   } else if(mf == 'upd' && rbackstack.length > 0 && crstack > 0) {
     rbackstack[crstack - 1].splice(1, 2, db, pg);
   } else if(mf == 'back') {
     --crstack;
     if(crstack <= 1) butrback_id.disabled = true;
     else butrback_id.disabled = false;
     butrnext_id.disabled = false;
     search.pcacheout(...rbackstack[crstack - 1]);
     dsx.dispscroll();
   } else if(mf == 'next') {
     ++crstack;
     if(crstack >= rbackstack.length) butrnext_id.disabled = true;
     else butrnext_id.disabled = false;
     butrback_id.disabled = false;
     search.pcacheout(...rbackstack[crstack - 1]);
     dsx.dispscroll();
   }
 },

 time:0,
 timokh:'',
 tim1:function() {
   search.breakflag = false;
   search.breakflag2 = false;
   search.time = Date.now();
   diaok_id.onmousedown = function() {};
   search.timokh = ok.ok(xl('sea_search') + ' <span id="searchindicator_id"></span>', function() {
     search.timokh = '';
     search.breakflag = true;
     diaok_id.onmousedown = function() {if(ok.mpda) ok.resall();};
   }, ok.txtbut('cancel'));
 },

 tim2:function(txt = '', sids, sci, db, pg) {
   ok.hide(search.timokh);
   diaok_id.onmousedown = function() {if(ok.mpda) ok.resall();};
   if(txt == '' && !search.breakflag) {
     dsx.raf = false;
     sethash(urlhash.dsx);
     //ok.autohide(888, ok.ok(xl('sea_complin') + ' ' + ((Date.now() - search.time) / 1000).toFixed(1) + xl('sea_s'), undefined, ''));
     search.rback('add', sids, sci, db, pg);
   } else {
     if(search.breakflag && txt != '') ok.ok(txt);
     else if(txt != '') ok.autohide(1500, ok.ok(txt, undefined, ''));
   }
 },

 go:function(sscsheme = cur_searchscheme, fitext) {
   sin[0] = searchscheme_list[sscsheme].slice();
   if(searchscheme_list[sscsheme][3].includes('txt') || searchscheme_list[sscsheme][3].includes('reg')) {
     if(fitext == '') return false;
     else sin[0][0] = fitext;
   } else sin[0][0] = '';
   let schdobj = {};
   schdobj['sscsheme_name'] = searchscheme_list[sscsheme][0];
   schdobj['sid'] = JSON.stringify(sin);
   return search.okstart(JSON.stringify(schdobj), 'new');
 },

 okstart:function(sids, onz) {
   let sscob = {};
   for(let key in db_list) {
     if(!db_list[key].use) continue;
     let res = search.wval(JSON.parse(sids).sid, key);
     if(res.s) {
       sscob[key] = res.t;
     } else {
       ok.emer = true;
       ok.ok(res.i);
       return false;
     }
   }
   search.tim1();
   setTimeout((sids, sci, onz) => {search.start(sids, sci, onz);}, 88, sids, JSON.stringify(sscob), onz);
   return true;
 },

 start:function(sids, sci, onz) {
   function zat(a) {
     let za = [];
     for(let i = 0; i < a.length; i++) if(a[i]) za.push(+i);
     return za.slice();
   }
   let schdobj = JSON.parse(sids);
   let si = JSON.parse(schdobj.sid);
   if(schdobj.sid in searchcache) {
     let m = false;
     for(let key in searchcache[schdobj.sid]) {
       if(searchcache[schdobj.sid][key].length != 0) {
         m = m || true;
         schdobj[key] = true;
       } else schdobj[key] = false;
     }
     if(!m) {
       search.tim2(xl('sea_noresult'));
     } else {
       if(onz == 'new') schdobj['search_time'] = search.gettimestring();
       let sids2 = JSON.stringify(schdobj);
       search.pcacheout(sids2, undefined, undefined, sci, function(resob, sids2, onz, sci) {
         if(resob.s) {
           dsxhistory.pinp(sids2, onz);
           search.tim2(undefined, sids2, sci, resob.db, resob.pg);
         } else search.tim2(resob.m);
       }, sids2, onz, sci);
     }
   } else {
     searchcache[schdobj.sid] = {};
     let su = 0;
     search.cstat = {};
     search.cstat.stack = [1];
     search.cstat.sci = sci;
     search.cstat.regob = JSON.parse(sci);
     search.cstat.reg = {};
     for(let key in db_list) {
       if(!db_list[key].use) continue;
       let at = setting.getsin(key, si);
       if(at[0]) {
         eval(`search.cstat.reg[key] = ${search.cstat.regob[key]};`);
         searchcache[schdobj.sid][key] = [];
         let db; eval(`db=${key};`);
         search.cstat.stack.push([db, key, 0, zat(at[1])]);
         su = +su + +db.length;
     } }
     if(search.cstat.stack.length == 1) {
       ok.ok(xl('sea_error'));
       return;
     }
     search.cstat.schdobj = JSON.parse(sids);
     search.cstat.seid = schdobj.sid;
     search.cstat.onz = onz;
     if(si[0][4] == '') search.cstat.sfun = si[0][4];
     else eval(`search.cstat.sfun = ${si[0][4]}`);
     if(si[0][5] == '') search.cstat.exexe = si[0][5];
     else eval(`search.cstat.exexe = ${si[0][5]}`);
     search.cstat.inter = +Math.trunc(+su/100) + 1;
     search.cstat.prcnt = 0;

     if(typeof search.cstat.exexe === 'function') {
       try {
         search.cstat.exexe('before');
       } catch(er) {
         search.breakflag = true;
         delete searchcache[schdobj.sid];
         search.tim2(`${xl('sea_errexe')} 'before'<br>${er}`);
         return;
       }
     }
     setTimeout(() => {search.cachestart();}, 88);
   }
 },

 breakflag:false,
 cachestart:function() {
   setTimeout(() => {
     let bf = false, suf = [];
     function exeng(match, ...args) {
       try {
         let mar = [];
         for(let i = 0; i < args.length; i++) {
           if(typeof args[i] != 'number') mar.push(args[i]);
           else break;
         }
         bf = bf || search.cstat.sfun(match, mar.slice());
       } catch(er) {
         suf.push(`${xl('sea_erfunsea')}<br>${er}`);
         search.breakflag = true;
       }
       if(search.breakflag || bf) eval('j');
       return match;
     }
     for(; search.cstat.stack[0] < search.cstat.stack.length; search.cstat.stack[0]++) {
       let c = 0;
       let db = search.cstat.stack[search.cstat.stack[0]][0];
       let key = curdbforfuncex = search.cstat.stack[search.cstat.stack[0]][1];
       let l  = search.cstat.stack[search.cstat.stack[0]][0].length;
       let ll = search.cstat.stack[search.cstat.stack[0]][3].length;
       for(; search.cstat.stack[search.cstat.stack[0]][2] < l; search.cstat.stack[search.cstat.stack[0]][2]++) {
         for(let g = 0; g < ll; g++) {
           if(typeof search.cstat.sfun === 'string') {
             search.cstat.reg[key].lastIndex = 0;
             if(search.cstat.reg[key].test(db[search.cstat.stack[search.cstat.stack[0]][2]][search.cstat.stack[search.cstat.stack[0]][3][g]])) {
               searchcache[search.cstat.seid][key].push(+search.cstat.stack[search.cstat.stack[0]][2]);
               break;
             }
           } else {
             try {
               db[search.cstat.stack[search.cstat.stack[0]][2]][search.cstat.stack[search.cstat.stack[0]][3][g]].replace(search.cstat.reg[key], exeng);
             } catch(j) {'j';}
             if(search.breakflag) break;
             if(bf) {
               bf = false;
               searchcache[search.cstat.seid][key].push(+search.cstat.stack[search.cstat.stack[0]][2]);
               break;
             }
           }
         }
         ++c;
         if(c >= +search.cstat.inter || search.breakflag) {
           if(search.breakflag) {
             delete searchcache[search.cstat.seid];
             if(suf.length != 0) search.tim2(suf.join('<hr>'));
           } else {
             ++search.cstat.stack[search.cstat.stack[0]][2];
             ++search.cstat.prcnt;
             if(g('searchindicator_id')) searchindicator_id.innerHTML = search.cstat.prcnt + '%';
             search.cachestart();
           }
           return;
     } } }
     if(typeof search.cstat.exexe === 'function') {
       try {
         search.cstat.exexe('after');
       } catch(er) {
         search.breakflag = true;
         delete searchcache[search.cstat.seid];
         search.tim2(`${xl('sea_errexe')} 'after'<br>${er}`);
         return;
       }
     }
     let m = false;
     for(let key in searchcache[search.cstat.seid]) {
       if(searchcache[search.cstat.seid][key].length != 0) {
         m = m || true;
         search.cstat.schdobj[key] = true;
       } else search.cstat.schdobj[key] = false;
     }
     if(!m) {
       search.tim2(xl('sea_noresult'));
       return;
     } else {
       search.cstat.schdobj['search_time'] = search.gettimestring();
       let sids = JSON.stringify(search.cstat.schdobj);
       search.pcacheout(sids, undefined, undefined, search.cstat.sci, function(resob, sids, onz, sci) {
         if(resob.s) {
           dsxhistory.pinp(sids, onz);
           search.tim2(undefined, sids, sci, resob.db, resob.pg);
         } else search.tim2(resob.m);
       }, sids, search.cstat.onz, search.cstat.sci);
     }
   }, 0);
 },
 
 detailinf:function(sid64, sci64) {
   let si = JSON.parse(b64d(sid64)), sci = JSON.parse(b64d(sci64)), r = {}, rs = '';
   for(let key in sci) {
     if(!setting.getsin(key, si)[0]) continue;
     let lkey = b64e(sci[key]);
     let nn = db_list[key].short_name;
     if(lkey in r) r[lkey].push(nn);
     else r[lkey] = [nn];
   }
   for(let lkey in r) rs += r[lkey].join(', ') + ' :\n' + b64d(lkey) + '\n';
   if(si[0][4].length != 0) rs += si[0][4];
   ok.ok(`<textarea cols="30" rows="11" style="white-space:pre;" readonly>${dsx.tomnemonics(rs)}</textarea>`, undefined, ok.txtbut('close'));
 },

 pcacheout:function(sids, dbk, page = 1, sci, cb = function(){}, ...args) {
   istorage.getItem('mar', function(val, sids, dbk, page, sci, cb, ...args) {
     cb(search.cacheout(sids, dbk, page, sci, val), ...args);
   }, undefined, sids, dbk, page, sci, cb, ...args);
 },

 breakflag2:false,
 cacheout:function(sids, dbk, page, sci, jms) {
   let schdobj = JSON.parse(sids);
   let sid = schdobj.sid;
   let res = '', rl = [];
   for(let key in searchcache[sid]) {
     if(searchcache[sid][key].length != 0) rl.push(['', '', key, db_list[key].short_name]);
   }
   if(dbk === undefined) dbk = rl[0][2];
   let si = JSON.parse(sid);
   let regob = JSON.parse(sci);

   displaybox_res_id.innerHTML = `<table id="resultinf_id" data-sid="${b64e(sid)}" data-sci="${b64e(sci)}" data-dbk="" data-page="${page}"><tbody>
     <tr><th>${xl('sea_navi')}</th><th>${xl('sea_seasch')}</th><th>${xl('sea_seamap')}</th></tr>
     <tr><td id="ri1_id"></td><td rowspan="2" id="ri3_id" onclick="search.detailinf('${b64e(sid)}','${b64e(sci)}');"></td><td rowspan="2" id="ri4_id"></td></tr>
     <tr><td id="ri2_id"></td></tr>
   </tbody></table><div class="matchm matchmprcnt" style="display:none;" id="matchm_id"></div><hr>`;

   ri3_id.innerHTML = `${dsx.tomnemonics(si[0][0])}<br>«${dsx.tomnemonics(schdobj.sscsheme_name)}»<br>${xl('sea_more')}`;
   let ts = '<table id="seldbreslist3_id"><tbody><tr>';
   for(let i = 1; i < si.length; i++) {
     if(!si[i][1]) continue;
     let dbnl = '', dbnl2 = '', rtm = '(–) ', higclck = '';
     if(!db_list[si[i][0]].use) dbnl = ' class="disabledtext"';
     if(si[i][0] == dbk) dbnl2 = ' class="selcurdbinmapsea"';
     else dbnl2 = ' class="nsecurdbinmapsea"';
     if(schdobj[si[i][0]]) {
       if(dbnl == '') rtm = '(+) ';
       else rtm = '(!+) ';
     }
     if((si[i][0] in searchcache[sid]) && db_list[si[i][0]].use) if(searchcache[sid][si[i][0]].length != 0 && si[i][0] != dbk) higclck = ` onclick="search.pcacheout(b64d('${b64e(sids)}'),'${si[i][0]}',undefined,b64d('${b64e(sci)}'));search.rback('upd',undefined,undefined,'${si[i][0]}',1);"`;
     ts += `<td${dbnl}${dbnl2}${higclck}>${rtm}<b>${db_list[si[i][0]].short_name}</b><br>`;
     for(let h = 2; h < si[i].length; h++) {
       if(!si[i][h]) continue;
       ts += `• ${db_list[si[i][0]].columns[h-2]}<br>`;
     }
     ts += `</td>`;
   }
   ri4_id.innerHTML = ts + '</tr></tbody></table>';

   let mlc = ''; if(rl.length > 1) mlc = 'mlist';
   ri1_id.innerHTML = `<button class="${mlc}" id="seldbreslist_id" data-xval="" onclick="search.seldb();"></button>`;
   seldbreslist_id.dataset.xval = resultinf_id.dataset.dbk = dbk;
   ok.delay = true;
   search.seldb = ok.rlist('seldbreslist_id', rl, function(id, val, s, sci) {
     if(id !== false) {
       search.pcacheout(s, val, undefined, sci);
       search.rback('upd', undefined, undefined, val, 1);
     }
   }, undefined, sids, sci);

   let pag = +Math.trunc(searchcache[sid][dbk].length/setting.cline);
   if(searchcache[sid][dbk].length%setting.cline != 0) ++pag;
   let s_pag = (page-1)*setting.cline;
   let f_pag = 0;
   if(+(+s_pag + +setting.cline) >= +searchcache[sid][dbk].length) f_pag = searchcache[sid][dbk].length;
   else f_pag = +s_pag + +setting.cline;
   
   if(+pag > 1) {
     let pl = [];
     for(let p = 1; p <= +pag; p++) pl.push(['','',+p,xl('sea_page')+' '+p]);
     let sp = page;
     if(page == 1) sp = pag;
     else --sp;
     ri2_id.innerHTML = `<button class="arrow_l" data-xval="" onclick="search.pcacheout(b64d('${b64e(sids)}'),'${dbk}',${sp},b64d('${b64e(sci)}'));search.rback('upd',undefined,undefined,'${dbk}',${sp});"></button>`;
     let xac = '';
     if(+pl.length <= 999) xac = 'search.selpage();';
     else xac = `ok.autohide(1300, ok.ok(xl('sea_alotofpg'), undefined, ''));`;
     ri2_id.innerHTML += `<button class="mlist" id="selpagres_id" data-xval="" onclick="${xac}"></button>`;
     selpagres_id.dataset.xval = page;
     ok.delay = true;
     search.selpage = ok.rlist('selpagres_id', pl, function(id, val, s, d, sci) {
       if(id !== false) {
         search.pcacheout(s, d, val, sci);
         search.rback('upd', undefined, undefined, d, val);
       }
     }, undefined, sids, dbk, sci);
     sp = page;
     if(page == pag) sp = 1;
     else ++sp;
     ri2_id.innerHTML += `<button class="arrow_r" data-xval="" onclick="search.pcacheout(b64d('${b64e(sids)}'),'${dbk}',${sp},b64d('${b64e(sci)}'));search.rback('upd',undefined,undefined,'${dbk}',${sp});"></button>`;
   }

   let count = 0, suf = [];
   function selt(m) {
     ++count;
     return `<span class="wo" onclick="search.getwoid(${count});" id="wo${count}">${m}</span>`;
   }
   let mar = JSON.parse(jms);
   function mhas(cdb, id) {
     for(let i = 0; i < mar[cdb].length; i++) if(+mar[cdb][i] == +id) return true;
     return false;
   }

   curdbforfuncex = dbk;
   let db; eval(`db = ${dbk};`);
   let rex; eval(`rex = ${regob[dbk]};`);
   let at = setting.getsin(dbk, si)[1];
   res += `<table id="searchrestable_id"><tbody><tr><th class="emo">⭐</th>`;
   let eol = {};
   for(let h = 0; h < db_list[dbk].columns.length; h++) {
     res += db_list[dbk].edithead(db_list[dbk].columns[h], h, eol, eog);
   }
   res += `</tr>`;
   for(let g = +s_pag; g < +f_pag; g++) {
     let ck = '';
     if(mhas(dbk,+searchcache[sid][dbk][g])) ck = ' checked';
     res += `<tr><td><label class="labelblock">&nbsp;<input type="checkbox" onchange="mark.pact(this,'${dbk}',${+searchcache[sid][dbk][g]});"${ck}/>&nbsp;</label></td>`;
     let eol = {};
     for(let s = 0; s < at.length; s++) {
       let ddd = db_list[dbk].editfunc(db[searchcache[sid][dbk][g]][s], s, at[s], searchcache[sid][dbk][g], regob[dbk], false, eol, eog);
       if(at[s]) {
         if(si[0][4].length == 0) {
           ddd = ddd.replace(rex, (match) => {return selt(match);});
         } else {
           try {
             ddd = ddd.replace(rex, function(match, ...args) {
               try {
                 let mar = [];
                 for(let i = 0; i < args.length; i++) {
                   if(typeof args[i] != 'number') mar.push(args[i]);
                   else break;
                 }
                 if(eval(`(${si[0][4]})(match, mar.slice())`)) return selt(match);
                 else return match;
               } catch(er) {
                 suf.push(`${xl('sea_ofunerr')}<br>${er}`);
                 search.breakflag2 = true;
                 eval('j');
               }
             });
           } catch(j) {'j';}
           if(search.breakflag2) {
             search.breakflag2 = false;
             return {'s':false, 'm':suf.join('<hr>')};
           }
         }
       }
       res += db_list[dbk].editfunc(ddd, s, at[s], searchcache[sid][dbk][g], regob[dbk], true, eol, eog);
     }
     res += '</tr>';
   }
   res += '</tbody></table>';
   
   if(+pag > 1) {
     let sp = page;
     if(page == 1) sp = pag;
     else --sp;
     res += `<hr><div class="resfootnavdiv"><button class="arrow_l" data-xval="" onclick="search.pcacheout(b64d('${b64e(sids)}'),'${dbk}',${sp},b64d('${b64e(sci)}'));search.rback('upd',undefined,undefined,'${dbk}',${sp});dsx.dispscroll();"></button>`;
     sp = page;
     if(page == pag) sp = 1;
     else ++sp;
     res += `<button class="arrow_r" data-xval="" onclick="search.pcacheout(b64d('${b64e(sids)}'),'${dbk}',${sp},b64d('${b64e(sci)}'));search.rback('upd',undefined,undefined,'${dbk}',${sp});dsx.dispscroll();"></button></div>`;
   }
   
   displaybox_res_id.innerHTML += res;

   navimetr_id.dataset.foc = 0;
   navimetr_id.dataset.las = count;
   nmr1_id.disabled = false;
   nmr2_id.disabled = false;
   search.getwoid(0);
   return {'s':true, 'db':dbk, 'pg':page};
 },

 getwoid:function(curid) {
   keyboard.onoffkb();
   let oldid = +navimetr_id.dataset.foc;
   function clta() {
     navimetr_id.dataset.foc = curid;
     if(g('wo'+oldid)) g('wo'+oldid).className = 'wo';
     if(g('wo'+curid)) g('wo'+curid).className = 'wo_sel';
     navimetr_id.innerText = curid + '/' + navimetr_id.dataset.las;
   }
   if(typeof(curid) == 'number') {
     clta();
     return true;
   } else if(curid == '+') {
     curid = +oldid;
     if(+curid >= +navimetr_id.dataset.las) curid = 1;
     else ++curid;
   } else if(curid == '-') {
     curid = +oldid;
     if(+curid <= 1) curid = +navimetr_id.dataset.las;
     else --curid;
   }
   clta();

   if('matchmanimation' in dsx.tob) {
     delete dsx.tob['matchmanimation'];
     matchm_id.style.backgroundColor = 'rgba(0,0,0,0.0)';
     matchm_id.style.display = 'none';
   }
   g('wo'+curid).scrollIntoView({behavior:'smooth',block:'center',inline:'center'});
   search.mafl(g('wo'+curid));

   return true;
 },

 mafl:function(t) {
     let wosc = t.getBoundingClientRect();
     if(+wosc.width > 40) return;
     let ph = 0, midu = 0;
     matchm_id.style.height = '';
     matchm_id.style.width = '';
     matchm_id.classList.add('matchmprcnt');
     matchm_id.style.display = '';
     midu = matchm_id.getBoundingClientRect();
     matchm_id.classList.remove('matchmprcnt');
     if(+midu.width >= +midu.height) {
       ph = midu.width;
       matchm_id.style.height = ph + 'px';
       matchm_id.style.width = ph + 'px';
     } else {
       ph = midu.height;
       matchm_id.style.width = ph + 'px';
       matchm_id.style.height = ph + 'px';
     }
     matchm_id.style.left = abro((+wosc.left + +wosc.width/2) - ph/2) + 'px';
     matchm_id.style.top = abro((+wosc.top + +wosc.height/2) - ph/2) + 'px';
     matchm_id.style.borderRadius = abro(ph/2) + 'px';
     if(cscheme.curcscheme == 'light') {
       matchm_id.style.backgroundColor = 'rgba(85,85,255,0.12)';
     } else {
       matchm_id.style.backgroundColor = 'rgba(255,255,0,0.08)';
     }

     dsx.run(1111, 'matchmanimation', function() {
       matchm_id.style.backgroundColor = 'rgba(0,0,0,0.0)';
       matchm_id.style.display = 'none';

     }, function(...args) {
       let ph = +matchm_id.style.width.replace(/px/, '');
       ph = ph - (args[7][1]*args[0])/args[2];
       if(ph < 0) ph = 0;
       matchm_id.style.width = abro(ph) + 'px';
       matchm_id.style.height = abro(ph) + 'px';
       let wosc = args[7][0].getBoundingClientRect();
       matchm_id.style.left = abro((+wosc.left + +wosc.width/2) - ph/2) + 'px';
       matchm_id.style.top = abro((+wosc.top + +wosc.height/2) - ph/2) + 'px';
       matchm_id.style.borderRadius = abro(ph/2) + 'px';
       //if(abro(ph) == 0) return 'del';
       return 'run';

     }, undefined, t, +matchm_id.style.width.replace(/px/,''));
 },

 wval:function(sid, cdb) {
  let si = JSON.parse(sid);
  let sch = si[0][3], word = si[0][0];
  if(word != '') {
      curdbforfuncex = cdb;
      function xcalc(w) {
        if(si[0][1].length == 0 || si[0][2].length == 0) return w;
        let suf = [];
        try {
          let uol = {};
          w = w.replace(eval(si[0][1]), function(match, ...args) {
            try {
              let mar = [], i = 0;
              for(; i < args.length; i++) {
                if(typeof args[i] != 'number') mar.push(args[i]);
                else break;
              }
              return eval(`(${si[0][2]})(match, mar.slice(), args[i], args[i+1], uol, uog);`);
            } catch(er) {
              suf.push(`${xl('sea_inprocer')}<br>${er}`);
            }
          });
        } catch(er) {
          suf.push(`${xl('sea_inprocer')}<br>${er}`);
        }
        if(suf.length == 0) return w;
        else return suf.slice();
      }
      if(sch.includes('txt')) {
        let wr = xcalc(sreg(word));
        if(typeof wr == 'object') return {
          's':false,
          'i':wr.join('<hr>'),
        };
        sch = sch.replace(/txt/gu, regucode(wr));
      } else if(sch.includes('reg')) {
        let wr = xcalc(word);
        if(typeof wr == 'object') return {
          's':false,
          'i':wr.join('<hr>'),
        };
        sch = sch.replace(/reg/gu, regucode(wr));
      } else return {
        's':false,
        'i':xl('sea_inspomi'),
      };
  }

  if(!regtest(sch)) {
    return {
      's':false,
      'i':`${xl('sea_misregex')}<br>${sch}`,
    };
  }
  try {
    eval(`let xtrg = ${sch}; xtrg.test('Test_Regular_Expression');`);
  } catch(er) {
    return {
      's':false,
      'i':`${er}<br>${xl('sea_regexerr')}<br>${sch}`,
    };
  }
  return {
    's':true,
    't':sch,
  };
 },

 hs:function() {
   let rl = [];
   rl.push(['', '', 0, xl('sea_seasch')]);
   rl.push(['', '', 1, xl('sea_seamap')]);
   ok.rlist('', rl, function(id, val) {
     if(id !== false) {
       if(val == 0) search.hss();
       else if(val == 1) search.hsm();
     }
   });
 },
 
 hss:function() {
   ok.constr(`<div id="hssboxdlg_id"></div>`, `
     <button onclick="ok.hide();">${ok.txtbut('close')}</button>
     <button onclick="ok.dig('sm');">${xl('sea_seamap')}</button>
   `, function(m, val) {
     if(m == 'htset') {
       let ts = '<table><tbody>';
       for(let i = 0; i < searchscheme_list.length; i++) {
         let che = '';
         if(i == cur_searchscheme) che = 'checked';
         if(searchscheme_list[i][3].includes('txt') || searchscheme_list[i][3].includes('reg')) ts += `<tr><td><label><input type="radio" onchange="ok.dig('ok',${i});" name="hssradio_name"${che}/>${dsx.tomnemonics(searchscheme_list[i][0])}</label></td></tr>`;
       }
       hssboxdlg_id.innerHTML = ts + '</tbody></table>';
     } else if(m == 'ok') {
       cur_searchscheme = +val;
       setting.placeholder(+val);
       istorage.setItem('cur_searchscheme', cur_searchscheme);
     } else if(m == 'sm') {
       search.hsm();
       return;
     }
     return false;
   });
 },

 hsm:function() {
   ok.constr(`<div id="hsmboxdlg_id"></div>`, `
     <button onclick="ok.hide();">${ok.txtbut('close')}</button>
     <button onclick="ok.dig('ss');">${xl('sea_seasch')}</button>
   `, function(m) {
     if(m == 'htset') {
       hsmboxdlg_id.innerHTML = setting.sinupd(false);
     } else if(m == 'ss') {
       search.hss();
       return;
     }
     return false;
   });
 },

};
