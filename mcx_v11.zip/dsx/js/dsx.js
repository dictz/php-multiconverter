'use strict';
function g(idelem){return document.getElementById(idelem);}
function b64e(str){return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,function toSolidBytes(math,p1){return String.fromCharCode('0x'+p1);}));} 
function b64d(str){return decodeURIComponent(atob(str).split('').map(function(c){return '%'+('00'+c.charCodeAt(0).toString(16)).slice(-2);}).join(''));} 
function rnd(minr,maxr){return Math.floor(Math.random()*(maxr-minr+1))+minr;}
let urndobj = {};
function urnd(p='dsx',r=16){if(p=='' || r==0){return;}let minr='1'.repeat(r),maxr='9'.repeat(r),n;if(!(p in urndobj)){urndobj[p]={};}function tp(){n=rnd(+minr,+maxr);if(String(n) in urndobj[p]){return false;}else{return true;}}let i=0;for(;i<33;i++){if(tp()){break;}}if(i==33){return;}urndobj[p][String(n)]='';return +n;}
function ulen(par){let len=0;for(let i of par){++len;}return len;}
function uoto(str,uo){let ofs=0,uo2=0,sts='';for(let i of str){++uo2;sts+=i;if(uo2===+uo){break;}}return sts.length;}
function usli(str,ns=1,ast=''){if(+ns==0){return ast;}if(ulen(str)>+ns){str=str.slice(0,uoto(str,+ns));return str+ast;}return str;}
function blen(str){return +(new Blob([str]).size);}
function perc(x,f){return +((+x*100)/+f);}
function cper(x,p){return +((+x*+p)/100);}
function remp(obje,prop){if(Reflect.has(obje,prop)){return Reflect.deleteProperty(obje,prop);}else{return false;}}
function sreg(s){return s.replace(/([\[\]\\\^\$\.\|\?\*\+\(\)\/\{\}])/gu,'\\$1');}
function regucode(r){return r.replace(/[^\[\]\\\^\$\.\|\?\*\+\(\)\/\{\}]/gu,function(match){return match.replace(/[\p{M}\p{Z}\p{C}]/gu,function(match1){return '\\u{'+match1.codePointAt(0).toString(16).toLowerCase()+'}';});});}
function symc(str,s){let n=0;str.replace(eval(`/${regucode(sreg(s))}/gu`),function(match){++n;return match;});return n;}
function sethash(h){window.location.hash = h[0];}
function regtest(r){try{let act=/^\/.+\/[gmusi]*$/;act.lastIndex=0;if(act.test(r)){eval(`${r}.test('Test_Regular_Expression');`);return true;}else{return false;}}catch(e){return false;}}
function abro(x) {return Math.abs(Math.round(x));}

function bradd(str, lm, lx, repar, sfrep) {
	let sl = ulen(str);
	if(+sl <= +lm) return str;
	let nstr = '', cmst = repar.join(''), cs = 0, tf = false;
	function coru() {
		if((+sl - +cs) > +lm) {
			sl = sl - cs;
		}
		cs = 0;
	}
	for(let sym of str) {
		nstr += sym;
		if(sym == '<') tf = true;
		else if(sym == '>') {tf = false; continue;}
		if(tf) continue;
		++cs;
		if(sym.includes('\n')) coru();
		if(+cs >= +lx) {
			if(cmst.includes(sym)) {
				nstr += sfrep;
				coru();
			}
		}
	}
	return nstr;
}

let curdbforfuncex = '', dbpalaneranges = {}, uog = {};
function urcmp(p1, p2) {
  if(typeof p1 !== 'string' || typeof p2 !== 'string') return false;
  let s1 = +p1.codePointAt(0), s2 = +p2.codePointAt(0);
  for(let i = 0; i < dbpalaneranges[curdbforfuncex].length; i++) {
    if(s1 >= dbpalaneranges[curdbforfuncex][i][0] && s1 <= dbpalaneranges[curdbforfuncex][i][1]) {
      if(s2 >= dbpalaneranges[curdbforfuncex][i][0] && s2 <= dbpalaneranges[curdbforfuncex][i][1]) return false;
      else return true;
  } }
  return false;
}

function getuc(p, e = true) {
  if(typeof p !== 'string') return false;
  let s = p.codePointAt(0).toString(16).toLowerCase();
  for(let i = 0; i < cacheconf[curdbforfuncex].length; i++) {
    for(let ii = 0; ii < cacheconf[curdbforfuncex][i].length; ii++) {
      if(cacheconf[curdbforfuncex][i][ii].length == 1) {
        if(s == cacheconf[curdbforfuncex][i][ii][0]) {
          return cacheconf[curdbforfuncex][i].map(function(item) {
            item = item.map(function(item) {
              return String.fromCodePoint(Number('0x' + item));
            }).join('');
            if(e) return sreg(item);
            else return item;
          }).slice();
  } } } }
  return [p];
}

sethash(urlhash.exit);
let dsx = {
 margin:function() {
   let p = headpanel_id.offsetHeight + 'px';
   marginbox_id.style.height = p;
 },

 dispscroll:function(x = 0, y = 0) {
   scrollbox_id.scrollLeft = +x;
   scrollbox_id.scrollTop = +y;
 },

 currentdisplay:'displaybox_res_id',
 currentpanel:'p_resnavi_id',
 displayshow:function(id) {
   function copf(o, pf, ...par) {
     try {if(eval(o) !== undefined) if(pf in eval(o)) eval(`${o}.${pf}(...par);`);} catch(e) {ok.ok(e);}
   }
   if(id === dsx.currentdisplay) return;
   if(g(dsx.currentdisplay)) {
     copf(g(dsx.currentdisplay).dataset.js, 'hide');
     g(dsx.currentdisplay).style.display = 'none';
   }
   if(g(dsx.currentpanel)) {
     g(dsx.currentpanel).dataset.sl = +headpanel_id.scrollLeft;
     g(dsx.currentpanel).style.display = 'none';
   }
   copf(g(id).dataset.js, 'show');
   g(id).style.display = '';
   g(g(id).dataset.pan).style.display = '';
   headpanel_id.scrollLeft = +g(g(id).dataset.pan).dataset.sl;
   dsx.currentdisplay = id;
   dsx.currentpanel = g(id).dataset.pan;
   dsx.dispscroll();
 },

 infolistgen:function(np = 'name') {
   let str = `<div class="setting"><fieldset><legend>${dsx_dictitle}</legend>${bradd(dsx_dicdescr,40,40,[' ','.'],'<br>')}<hr><table><tbody>`;
   for(let key in db_list) {
     if(!db_list[key].use) continue;
     let n = db_list[key].name;
     if(np === 'fullname') n = db_list[key].full_name;
     else if(np === 'shortname') n = db_list[key].short_name;
     str += `<tr><td>${n}</td><td>${eval(key + '.length;')}</td></tr>`;
   }
   return `${str}</tbody></table></fieldset></div>`;
 },

 inptxtwupd:function(t) {
   setTimeout(function(t) {
     if(t.value == '') {
       t.style.width = '300px';
     } else {
       if(+t.scrollWidth > +t.style.width.replace(/px/,'')) t.style.width = (+t.style.width.replace(/px/,'') + +60) + 'px';
     }
   }, 33, t);
 },

 start:function() {
dsx.jsync([() => {
   let su = 0;
   for(let key in db_list) if(db_list[key].use) eval(`su += ${key}.length;`);
   istorage.setItem('dblengsum', su);

}, () => {
   dsx.scrollfunc = {};
   scrollbox_id.addEventListener('scroll', function() {
     for(let key in dsx.scrollfunc) {
       dsx.run(300, `dsx_scrollfunc_${key}`, dsx.scrollfunc[key]);
     }
   });

   dsx.scrollfunc.lefttop = function() {
     if(g('keyboardbox_id')) if(keyboardbox_id.style.display == '') {lefttop_id.style.display = 'none'; return;}
     if(+scrollbox_id.scrollLeft >= 200 || +scrollbox_id.scrollTop >= 200) lefttop_id.style.display = '';
     else lefttop_id.style.display = 'none';
   };

   word_id.onfocus = word_m_id.onfocus = function() {
     setTimeout(function(t, tx) {
       if(tx != '') {
         t.value = tx;
         keyboard.updtxa(t);
       }
     }, 33, this, window.getSelection().toString());
     window.getSelection().removeAllRanges();
     keyboard.onoffkb(usekbflag, this);
   };

   word_id.oninput = word_m_id.oninput = function() {
     setTimeout(function(t) {
       keyboard.updtxa(t);
     }, 33, this);
   };

   word_id.onmousedown = word_m_id.onmousedown = function() {
     setTimeout(function(t) {
       keyboard.updtxa(t);
     }, 33, this);
   };

   word_id.ondblclick = word_m_id.ondblclick = function() {
     setTimeout(function(t) {
       t.blur();
       search.hs();
     }, 33, this);
   };

}, () => {
   setting.start();

}, () => {
   mark.init();

}, () => {
   dsx.raf = true;
   dsx.restart = false;
   window.addEventListener('hashchange', (ev) => {
     search.breakflag = true;
     if(dsx.restart) return;
     diaok_id.onmousedown = function() {if(ok.mpda) ok.resall();};
     if(dsx.raf) ok.resall();
     else dsx.raf = true;

     keyboard.onoffkb();
     let uh = window.location.hash;
     if(uh == urlhash.dsx[0]) {
       dsx.displayshow('displaybox_res_id');
       title_id.innerText = urlhash.dsx[1];

     } else if(uh == urlhash.sett[0]) {
       dsx.displayshow('displaybox_set_id');
       title_id.innerText = urlhash.sett[1];

     } else if(uh == urlhash.hist[0]) {
       dsx.displayshow('displaybox_his_id');
       title_id.innerText = urlhash.hist[1];

     } else if(uh == urlhash.mark[0]) {
       dsx.displayshow('displaybox_mar_id');
       title_id.innerText = urlhash.mark[1];

     } else if(uh == urlhash.cmd[0]) {
       dsx.displayshow('displaybox_cmd_id');
       title_id.innerText = urlhash.cmd[1];

     } else if(uh == urlhash.exit[0]) {
       diaok_id.onmousedown = function() {ok.dig(true);};
       ok.ok(xl('ht_toexit'), function() {
         sethash(urlhash.dsx);
       }, ok.txtbut('cancel'));
       title_id.innerText = urlhash.exit[1];

     }
   });

}, () => {
   title_id.innerText = urlhash.exit[1];
   dsxstartinfolist_id.innerHTML = dsx.infolistgen('shortname') + '&nbsp;&nbsp;' + ((Date.now()-loadtime)/1000).toFixed(0) + xl('ht_s');
   diaok_id.onmousedown = function() {ok.dig(true);};

}]);


 },

 setel:function(tag, id, ht, ob = document.head) {
   if(g(id)) g(id).remove();
   let elem = document.createElement(tag);
   elem.id = id;
   elem.innerHTML = ht;
   ob.append(elem);
 },

 tob:{},
 trunf:false,
 trunt:0,
 run:function(t, idx, code, codex = function(){return 'run';}, interf = false, ...par) {
   function runiter(time) {
     dsx.trunt = time;
     return requestAnimationFrame(function inte(time) {
     try {
       function ruc(ct, t, idx, code, codex, interf, par) {
         code(...par);
         if(!interf) delete dsx.tob[idx];
         else dsx.tob[idx][0] = dsx.tob[idx][1];
       }
       function idxc() {
         let c = 0; for(let idx in dsx.tob) ++c; return c;
       }
       for(let idx in dsx.tob) {
         if(dsx.tob[idx][0] > 0) {
           let qio = time - dsx.trunt;
           let tact = dsx.tob[idx][4](qio, ...dsx.tob[idx]);
           if(tact == 'run') dsx.tob[idx][0] = dsx.tob[idx][0] - qio;
           else if(tact == 'pause') continue;
           else delete dsx.tob[idx];
         } else ruc(...dsx.tob[idx]);
       }
       if(idxc() == 0) dsx.trunf = false;
       else dsx.trunf = runiter(performance.now());
     } catch(er) {
       ok.cancel(er, function(r) {
         if(r) dsx.trunf = runiter(performance.now());
       }, undefined, ok.txtbut('continue'));
     }
     });
   }
   if(!(idx in dsx.tob)) {
     dsx.tob[idx] = [t, t, idx, code, codex, interf, par.slice()];
     if(dsx.trunf !== false) return true;
     dsx.trunf = runiter(performance.now());
     return true;
   } else return false;
 },

 toucode:function(par) {
   return par.replace(/./gus, function(match) {
     return '\\u{' + (match.codePointAt(0)).toString(16) + '}';
   });
 },

 tomnemonics:function(par) {
   return par.replace(/./gus, function(match) {
     return '&#' + match.codePointAt(0) + ';';
   });
 },

 convpos:function(t, posU) {
   let sl = 0, pu = 0;
   if(posU !== undefined) {
     for(let i of t.value) {
       if(+pu == +posU) break;
       ++pu;
       sl = +sl + +i.length;
     }
     return +sl;
   } else {
     let pos = t.selectionStart = t.selectionEnd;
     for(let i of t.value) {
       if(+sl == +pos) break;
       ++pu;
       sl = +sl + +i.length;
     }
     return +pu;
   }
 },

 selectionU:function(t, pos, par) {
   if(par !== undefined) {
     if(par == 'Start') {
       t.selectionStart = dsx.convpos(t, pos);
     } else if(par == 'End') {
       t.selectionEnd = dsx.convpos(t, pos);
     }
   } else {
     t.selectionStart = t.selectionEnd = dsx.convpos(t, pos);
   }
 },

 setRangeTextU:function(t, txt, sta, end) {
   t.setRangeText(txt, dsx.convpos(t, sta), dsx.convpos(t, end));
 },

 objtotext:function(d, p = '', e = ',', m = [], c = 0) {
  if(m[c] !== undefined) p = '\n' + ' '.repeat(m[c]) + p;
  if(typeof d == 'boolean') return p + String(d) + e;
  else if(typeof d == 'number') return p + String(d) + e;
  else if(typeof d == 'string') return p + '"' + d.replace(/(["\\])/g,'\\$1').replace(/\n/g,'\\n') + '"' + e; //" ' `
  else if(typeof d == 'object') {
    let t = p;
    if('length' in d) {
      t += '[';
      for(let i = 0; i < d.length; i++) t += dsx.objtotext(d[i], undefined, undefined, m, c+1);
      if(t.at(-1) == ',') t = t.slice(0, -1);
      t += ']';
    } else {
      t += '{';
      for(let key in d) t += dsx.objtotext(d[key], '\'' + key + '\':', undefined, m, c+1);
      if(t.at(-1) == ',') t = t.slice(0, -1);
      if(m[c] !== undefined) t += '\n' + ' '.repeat(m[c]) + '}';
      else t += '\n}';
    }
    return t + e;
  }
  //ok.ok('Unidentified data type!');
  return p + '\'Unidentified data type!\'' + e;
 },

 symarr:function(db, plane) {
   let ca = [];
   if(db == 'unicode' && plane != undefined) {
     for(let i = 0; i < unicode_blocks.length; i++) {
       if(unicode_blocks[i][2] == plane) {
         let m1 = Number('0x' + unicode_blocks[i][0]);
         let m2 = Number('0x' + unicode_blocks[i][1]);
         for(let i = m1; i <= m2; i++) ca.push(i);
         break;
       }
     }
     return ca.slice();
   }
   if(db != undefined && plane == undefined) {
     for(let pl in cachesymb[db]) ca = ca.concat(dsx.symarr(db, pl));
     return ca.slice();
   } else if(db == undefined || plane == undefined) return [];
   for(let i = 0; i < cachesymb[db][plane].symbols.length; i++) {
     let m = cachesymb[db][plane].symbols[i].split('-');
     let m1 = Number('0x' + m[0]);
     if(m.length == 2) {
       let m2 = Number('0x' + m[1]);
       for(let i = m1; i <= m2; i++) ca.push(i);
     } else ca.push(m1);
   }
   return ca.slice();
 },

 jsync:function(arf, ob = {}) {
   let timeout = 33;
   if(ob.timeout !== undefined) timeout = ob.timeout;
   setTimeout(function(arf, obt) {
     try {
       let ob = arf[0](obt);
       if(ob === undefined) ob = {};
       if(ob.ret === undefined || ob.ret === false) arf.shift();
       else if(ob.ret === 'continue') ob.ret = false;
       else if(ob.ret === 'break') arf.length = 0;
       else if(typeof ob.ret == 'number') arf = arf.slice(ob.ret, arf.length);
       if(arf.length > 0) dsx.jsync(arf, ob);
     } catch(er) {ok.ok(er);}
   }, timeout, arf, ob);
 },

 savefile:function(filename, content, ftype = 'text/plain;charset=utf-8') {
  const element = document.createElement('a');
  const blob = new Blob(content, {'type': ftype});
  const fileUrl = URL.createObjectURL(blob);
  element.setAttribute('href', fileUrl);
  element.setAttribute('download', filename);
  element.style.display = 'none';
  document.body.appendChild(element);
  element.click();
  document.body.removeChild(element);
 },

 saveorprint:function() {
   let rl = [];
   rl.push(['', '', 0, xl('ht_print')]);
   rl.push(['', '', 1, xl('ht_savtext')]);
   rl.push(['', '', 2, xl('ht_savhtml')]);
   ok.rlist('', rl, function(id, val) {
     if(id !== false) {
       let htmlstr;
       if(dsx.currentdisplay == 'displaybox_res_id') {
         if(!g('searchrestable_id')) {ok.autohide(1500, ok.ok(xl('ht_emp'), undefined, '')); return;}
         htmlstr = searchrestable_id.innerHTML;
       } else if(dsx.currentdisplay == 'displaybox_mar_id') {
         if(!g('markviewtable_id')) {ok.autohide(1500, ok.ok(xl('ht_emp'), undefined, '')); return;}
         htmlstr = markviewtable_id.innerHTML;
       } else return;
       if(val == 0) print();
       else if(val == 1) dsx.savetext(htmlstr);
       else if(val == 2) dsx.savehtml(htmlstr);
     }
   });
 },

 savetext:function(htmlstr) {
   let trarr = [];
   htmlstr.replace(/<tr[^<>]*>(.+?)<\/tr>/gs, function(match, p1) {
     let tdarr = [];
     p1.replace(/<t(d|h)[^<>]*>(.+?)<\/t(d|h)>/gs, function(match, p1, p2) {
       let xtx = p2.split(/<hr[ ]*\/?>/);
       for(let i = 0; i < xtx.length; i++) xtx[i] = xtx[i].replace(/<br[ ]*\/?>/g, '\n').replace(/<[^<>]*>/g, '').replace(/&nbsp;/g, ' ');
       tdarr.push(...xtx);
       return '';
     });
     trarr.push(tdarr);
     return '';
   });

   let outpstr = '';
   for(let i = 1; i < trarr.length; i++) {
     for(let ii = 1; ii < trarr[i].length; ii++) {
       outpstr += trarr[i][ii] + '\n';
     }
     outpstr += '\n\n';
   }

   // '\u{feff}' + 
   dsx.savefile('page.txt', [new Uint8Array([0xef,0xbb,0xbf]), outpstr]);
 },

 savehtml:function(htmlstr) {
   let trarr = [];
   htmlstr.replace(/<tr[^<>]*>(.+?)<\/tr>/gs, function(match, p1) {
     let tdarr = [];
     p1.replace(/<t(d|h)[^<>]*>(.+?)<\/t(d|h)>/gs, function(match, p1, p2) {
       let xtx = p2.split(/<hr[ ]*\/?>/);
       for(let i = 0; i < xtx.length; i++) xtx[i] = xtx[i].replace(/<br[ ]*\/?>/g, '@©®©@').replace(/<[^<>]*>/g, '').replace(/@©®©@/g, '<br>');
       tdarr.push(xtx.join('<hr>'));
       return '';
     });
     trarr.push(tdarr);
     return '';
   });

   let outpstr = `<html>
<head>
  <title>${title_id.innerText}</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0"/>
  <meta name="HandheldFriendly" content="True"/>
  <style>
    table {
      border-collapse: collapse;
    }
    table * {
      border-color: black;
      border-width: 1px;
      border-style: solid;
    }
    table tbody tr td {
      padding: 5px 10px;
      vertical-align: top;
    }
    hr {
      border-width: 1px;
      border-top-width: 0px;
    }
  </style>
</head>
<body>
<table><tbody>
`;
   for(let i = 1; i < trarr.length; i++) {
     outpstr += '<tr>\n';
     for(let ii = 1; ii < trarr[i].length; ii++) {
       outpstr += '  <td contenteditable="true">' + trarr[i][ii] + '</td>\n';
     }
     outpstr += '</tr>';
   }
   outpstr += '\n</tbody></table>\n</body>\n</html>';
   // '\u{feff}' + 
   dsx.savefile('page.html', [outpstr]);
 },

};
