<?php 
set_time_limit(86399);
ini_set('memory_limit', '3072M');
mb_internal_encoding('UTF-8');

//================================================
//           НАСТРОЙКИ | OPTIONS
//------------------------------------------------

//README
  $readme_text = ''; // Общий текст для README.txt. Файл не будет создан если строка пуста.

//DSL
  $dsl_numparts = 3;              // Деление DSL на части, количество частей, число >= 1.
  $dsl_parbalance = 1;            // 1 - уравновесить части по размеру; 2 - уровнять части по количеству слов.
  $dsl_threshold = 200*1024*1024; // Порог для осуществления деления, - размер исходн. файла(ов) в байтах. Деление будет происходить только если размер исходника больше этого значения.
  $dsl_include = true;            // Использование директивы #INCLUDE при делении на части: true - использовать; false - не использовать. Используется для компиляции в Lingvo, другие программы могут игнорировать директиву.
  $dsl_compress = 6;              // Сжатие DictZIP (.dsl.dz). Число от 1 до 9, определяющее уровень сжатия. 0 - без сжатия. Для компиляции в Lingvo установить 0.
  $dsl_cn_langindex = 'Chinese';  // English
  $dsl_ru_langindex = 'Russian';
  $dsl_cn_langcontent = 'Chinese';
  $dsl_ru_langcontent = 'Russian';
  $dsl_readme = $readme_text;     // Текст для README.txt

//MDict
  $md_compress = 6;          // Внутреннее сжатие. Число от 1 до 9, определяющее уровень сжатия. 0 - без сжатия.
  $md_indent = 20;           // Отступы в словарных статьях, пиксели. 0 - без отступов.
  $md_addcontent = '';       // Добавочное содержимое, помещается в конце каждой страницы. Допустимо использование HTML, CSS и JavaScript.
  $md_readme = $readme_text; // Текст для README.txt

//StarDict
  $sd_compress = 6;          // Сжатие GZIP (.idx.gz) и DictZIP (.dict.dz). Число от 1 до 9, определяющее уровень сжатия. 0 - без сжатия.
  $sd_indent = 20;           // Отступы в словарных статьях, пиксели. 0 - без отступов.
  $sd_addcontent = '';       // Добавочное содержимое, помещается в конце каждой страницы. Допустимо использование HTML, CSS и JavaScript (некоторые программы-просмотрщики JavaScript не выполняют).
  $sd_readme = $readme_text; // Текст для README.txt

//HTML
  $ht_langcode = 'russian-RF'; // Язык интерфейса (см. dsx/js/lang.js)
  $ht_readme = $readme_text;   // Текст для README.txt

//ZIP
  $option_zip = false;   // Создание сжатого ZIP-каталога: true - включить; false - обычный каталог.
  $zip_password = '';    // Пароль для ZIP-каталога (PHP >= 7.2). Пустая строка '' - без пароля.
  $zip_srccatdel = true; // Удаление исходного каталога после получения ZIP-каталога: true - удалить; false - не удалять.

//Тест
  $tstnums = 1000; // Количество слов в базах для тестовой конвертации.


//================================================

function tdsrepl($xstr) {return trim(preg_replace('/[ ]{2,}/',' ',str_replace(["\t",'\'','"','<','>','\\','$'], [' ',' ',' ',' ',' ',' ',' '], $xstr)));}
if($_SERVER["REQUEST_METHOD"] != 'POST') {
include 'dsx/php/adapter_ced.php';
include 'dsx/php/adapter_dsl.php';

$ast = 'Добавление, редактирование и новые версии словаря - http://bkrs.info';
$bktitle = '大БКРС';
$bkdescr = 'Большой Китайско-Русский Словарь';
$brtitle = 'БРуКС';
$brdescr = 'Большой Русско-Китайский Словарь';
$extitle = 'Примеры';
$exdescr = 'Примеры 大БКРС';

$flv = array('StarDict' => false, 'MDict' => false, 'DSL' => false, 'HTML' => false);
$dadir = 'da/';
$addir = 'adapter/';
$convdata = array('testfl' => false, 'dadir' => $dadir, 'bzdate' => '', 'bzl' => []);

$dadate = '';
$dadate2 = '';
$arfiles = scandir($dadir);
foreach ($arfiles as $key => $value) {
  if(is_file($dadir.$value)) {
    if(preg_match('/^(dabkrs|dabruks|examples)_[\d]{6}$/', $value) != 1) continue;
    $dafnam = explode('_', $value)[0];
    $dadate = $convdata['bzdate'] = explode('_', $value)[1];
    $dadate2 = preg_replace('/(\d\d)(\d\d)(\d\d)/', '20$1-$2-$3', $dadate);
    if ($dafnam == 'dabkrs') {
      $convdata['bzl'][$dafnam] = array();
      $convdata['bzl'][$dafnam]['flv'] = $flv;
      $convdata['bzl'][$dafnam.'s'] = array();
      $convdata['bzl'][$dafnam.'s']['flv'] = $flv;
      $convdata['bzl'][$dafnam]['title'] = $convdata['bzl'][$dafnam.'s']['title'] = $bktitle.' - '.$dadate;
      $convdata['bzl'][$dafnam]['descr'] = $convdata['bzl'][$dafnam.'s']['descr'] = $bkdescr.' ('.$dadate2.'). '.$ast;
    } else if ($dafnam == 'dabruks') {
      $convdata['bzl'][$dafnam] = array();
      $convdata['bzl'][$dafnam]['flv'] = $flv;
      $convdata['bzl'][$dafnam]['title'] = $brtitle.' - '.$dadate;
      $convdata['bzl'][$dafnam]['descr'] = $brdescr.' ('.$dadate2.'). '.$ast;
    } else if ($dafnam == 'examples') {
      $convdata['bzl'][$dafnam] = array();
      $convdata['bzl'][$dafnam]['flv'] = $flv;
      $convdata['bzl'][$dafnam]['title'] = $extitle.' - '.$dadate;
      $convdata['bzl'][$dafnam]['descr'] = $exdescr.' ('.$dadate2.'). '.$ast;
    }
  }
}

$mixbz = array(
'dabkrs_dabruks_examples' => [
  'flv' => $flv,
  'title' => $bktitle.', '.$brtitle.', '.$extitle.' - '.$dadate,
  'descr' => $bkdescr.', '.$brdescr.', '.$exdescr.' ('.$dadate2.'). '.$ast
], 'dabkrs_dabruks' => [
  'flv' => $flv,
  'title' => $bktitle.', '.$brtitle.' - '.$dadate,
  'descr' => $bkdescr.', '.$brdescr.' ('.$dadate2.'). '.$ast
], 'dabkrss_dabruks_examples' => [
  'flv' => $flv,
  'title' => $bktitle.', '.$brtitle.', '.$extitle.' - '.$dadate,
  'descr' => $bkdescr.', '.$brdescr.', '.$exdescr.' ('.$dadate2.'). '.$ast
], 'dabkrss_dabruks' => [
  'flv' => $flv,
  'title' => $bktitle.', '.$brtitle.' - '.$dadate,
  'descr' => $bkdescr.', '.$brdescr.' ('.$dadate2.'). '.$ast
],
);
foreach ($mixbz as $key => $profar) {
  if(count(array_diff_key(array_flip(explode('_',$key)), $convdata['bzl'])) != 0) {
    unset($mixbz[$key]);
  }
}
$convdata['bzl'] += $mixbz;

$adapterinfoar = json_decode(trim(str_replace(["\r","\n"],['',''],preg_replace('/^.*<json>[\r]?\n(.*)\n<\/json>.*$/s','$1',file_get_contents($addir.'EDITME.json')))), true);
foreach ($adapterinfoar as $key => $dbl) {
  if($key == 'CDICT') {
    foreach ($dbl as $dkey => $infl) {
      if(adapter_ced($addir.$infl['file'], $dadir.$dkey)) {
        $convdata['bzl'][$dkey] = array();
        $convdata['bzl'][$dkey]['flv'] = $flv;
        $convdata['bzl'][$dkey]['title'] = tdsrepl($infl['title']);
        $convdata['bzl'][$dkey]['descr'] = tdsrepl($infl['description']);
        $convdata['bzl'][$dkey]['grn'] = 'cdict';
      } else {
        continue;
      }
    }
  } else if($key == 'DSLDICT') {
    foreach ($dbl as $dkey => $infl) {
      foreach ($infl['files'] as &$ifn) $ifn = $addir.$ifn;
      unset($ifn);
      if(adapter_dsl($infl['files'], $dadir.$dkey)) {
        $convdata['bzl'][$dkey] = array();
        $convdata['bzl'][$dkey]['flv'] = $flv;
        $convdata['bzl'][$dkey]['flv']['DSL'] = 'disabled';
        $convdata['bzl'][$dkey]['title'] = tdsrepl($infl['title']);
        $convdata['bzl'][$dkey]['descr'] = tdsrepl($infl['description']);
        $convdata['bzl'][$dkey]['grn'] = 'dsldict';
      } else {
        continue;
      }
    }
  }
}

$convdatajs = base64_encode(json_encode($convdata));
//_________________________________________________________________
?>
<html>
<head>
  <title>mcx</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0"/>
  <meta name="HandheldFriendly" content="True"/>
  <link href="dsx/css/index.css" rel="stylesheet" type="text/css"/>
  <script src="dsx/js/index.js" type="text/javascript"></script>
  <script type="text/javascript">
 'use strict';
 const convdata = JSON.parse(b64d('<?php echo $convdatajs; ?>'));
 window.name = 'mcx';

 function ncbut() {
   return `<hr><p><button onclick="getinplist();flvupd();">Повтор</button></p>`;
 }
 function updbut(txt) {
   return `<hr><p><button onclick="window.open(window.location,window.name);">${txt}</button></p>`;
 }

 let intvlid;
 function lani() {
   intvlid = setInterval(function() {
     if(!g('lani_id')) clearInterval(intvlid);
     let il = lani_id.innerText;
     if(ulen(il) >= 12) il = '..';
     else il += '..';
     lani_id.innerText = il;
   }, 500);
 }

 let tim1 = 0;
 function convstart(tst) {
   tim1 = Date.now();
   convdata['testfl'] = tst;
   convdata_name.value = b64e(JSON.stringify(convdata));
   let formDat = new FormData(document.forms.form_name);
   let xhr = new XMLHttpRequest();
   xhr.open('POST', window.location);
   xhr.onload = function() {
     if(xhr.status != 200) {
       ulist_id.innerHTML = `<p>${xhr.status}<br>${xhr.statusText}</p>${ncbut()}`;
     } else {
       let timd = new Date(Date.now() - tim1);
       let timar = [[timd.getUTCHours(),'ч'], [timd.getUTCMinutes(),'м'], [timd.getUTCSeconds(),'с'], [timd.getUTCMilliseconds(),'мс']];
       if(timar[0][0] != 0 || timar[1][0] != 0 || timar[2][0] != 0) timar[3][0] = 0;
       if(timar[0][0] != 0 || timar[1][0] > 9) timar[2][0] = 0;
       for(let i = 0; i < timar.length; i++) {
         if(timar[i][0] == 0) timar[i] = '';
         else timar[i] = timar[i].join('');
       }
       box_id.innerHTML = `<p>Выполнено за&nbsp;${timar.join(' ').trim()}</p><hr>${xhr.response}${updbut('Продолжить')}`;
     }
   };
   xhr.onerror = function() {
     ulist_id.innerHTML = `<p>Процесс завершился ошибкой.<br>Возможно локальный сервер был остановлен, попробуйте перезапустить.</p>${ncbut()}`;
   };

   ulist_id.innerHTML = `<p><span class="emo">⏳</span> Конвертируется <span id="lani_id"></span></p>`;
   lani();
   showhide_id.style.display = 'none';
   xhr.send(formDat);
 }

 function tdedit(xbz) {
   ok.constr(`
     <input type="text" id="newtitle_id" autocomplete="off" placeholder="Заголовок" onkeydown="if(event.key=='Enter'){newdescr_id.focus();}" style="width:400px;"/>
     <hr><textarea id="newdescr_id" placeholder="Описание" style="width:400px;height:20%;"></textarea>
   `, `
     <button onclick="ok.hide();">${ok.txtbut('cancel')}</button>
     <button onclick="ok.dig('save');">${ok.txtbut('apply')}</button>
   `, function(xbz, m) {
     if(m == 'htset') {
       newtitle_id.value = xbz['title'];
       newdescr_id.value = xbz['descr'];
       newtitle_id.focus();
     } else if(m == 'save') {
       xbz['title'] = newtitle_id.value.replace(/[\n\r\t'"<>\\$]/g, ' ').replace(/[ ]{2,}/g, ' ').trim();
       xbz['descr'] = newdescr_id.value.replace(/[\n\r\t'"<>\\$]/g, ' ').replace(/[ ]{2,}/g, ' ').trim();
       getinplist();
       return;
     }
     return false;
   }, xbz);
 }

 function flvupd() {
   let fcount = 0;
   for(let key in convdata['bzl']) {
     for(let key2 in convdata['bzl'][key]['flv']) {
       if(convdata['bzl'][key]['flv'][key2] === true) ++fcount;
     }
   }
   if(fcount > 0) showhide_id.style.display = '';
   else showhide_id.style.display = 'none';
   cc_id.innerText = 'Выбрано: ' + fcount;
 }

 function getinplist() {
   let listr = '', lth;
   for(let key in convdata['bzl']) {
     if(listr == '') {
       listr = `<tr class="thclass"><td></td>`;
       for(let key2 in convdata['bzl'][key]['flv']) listr += `<td>${key2}</td>`;
       listr += '</tr>';
       lth = listr.replace('<td></td>', '<td><span id="cc_id" class="cclass">Выбрано: 0</span></td>');
     }
     listr += `<tr><td onclick="tdedit(convdata['bzl']['${key}']);">${convdata['bzl'][key]['title']}`;
     if(key.indexOf('dabkrss') != -1) listr += `<br><span class="ssinf">(大БКРС short, <a target="_blank" href="http://bkrs.info/p257">слова с чтением</a>)</span>`;
     listr += `<br><span class="cbzc">${key}</span></td>`;
     for(let key2 in convdata['bzl'][key]['flv']) {
       if(convdata['bzl'][key]['flv'][key2] === 'disabled') {
         listr += '<td></td>';
         continue;
       }
       let che = '';
       if(convdata['bzl'][key]['flv'][key2] === true) che = ' checked';
       listr += `<td><label class="onlbl"><input type="checkbox" onchange="convdata['bzl']['${key}']['flv']['${key2}']=this.checked;flvupd();"${che}/></label></td>`;
     }
     listr += '</tr>';
   }
   if(listr != '') listr += lth;

   if(listr == '') ulist_id.innerHTML = `<p>В каталогах <i><?php echo $dadir; ?></i> и <i><?php echo $addir; ?></i> пусто.</p>${updbut('Обновить')}`;
   else ulist_id.innerHTML = `<table><tbody>${listr}</tbody></table`;
 }
  </script>
</head>
<body onload="getinplist();">
    <div class="diaok atop" id="diaok_id" style="display:none;" onmousedown="if(ok.mpda) ok.resall();" onmousemove="if(event.clientX > diaokbox_id.offsetLeft && event.clientX < +diaokbox_id.offsetLeft + +diaokbox_id.offsetWidth && event.clientY > diaokbox_id.offsetTop && event.clientY < +diaokbox_id.offsetTop + +diaokbox_id.offsetHeight) ok.mpda = false; else ok.mpda = true;">
      <div class="diaokbox" id="diaokbox_id"></div>
    </div>
    <div id="box_id">
      <form name="form_name" style="display:none;" onsubmit="return false;"><input type="hidden" name="convdata_name" id="convdata_name"/></form>
      <div id="ulist_id"></div>
      <div style="display:none;" id="showhide_id" class="showhide">
        <button class="ibut" onclick="ok.ok('В зависимости от вычислительной скорости и количества выбранных пунктов, время конвертации может составить от минуты до часа и более.<br>Проследите чтобы вкладка не оказалась скрытой и устройство не ушло в спящий режим, иначе локальный сервер может быть замедлен или остановлен.<br>(<i>«настройки экрана» -> «не выключать экран»</i>)');">i</button><button onclick="ok.cancel('Подтвердите конвертацию',function(r){if(r) convstart(false);});"> Конвертировать </button>
        <hr><button class="ibut" onclick="ok.ok('Будет по <?php echo strval($tstnums); ?> слов в выбранных словарных базах. Используется в тестировании, когда нужна быстрая конвертация.');">i</button><button onclick="ok.cancel('Подтвердите тестовую конвертацию',function(r){if(r) convstart(true);});"> Тест </button>
      </div>
    </div>
    <hr><p class="infot">mcx v11 | <a target="_blank" href="http://bkrs.info/taolun/thread-340497.html">Форум</a></p>
</body>
</html><?php } else { //_________________________________________________________________
include 'dsx/php/functions.php';
include 'dsx/php/convert_sd.php';
include 'dsx/php/convert_md.php';
include 'dsx/php/convert_dsl.php';
include 'dsx/php/convert_ht.php';

$convdata = json_decode(base64_decode($_POST["convdata_name"]), true);
$resstr = '';

$arp = array();
foreach ($convdata['bzl'] as $key => $val) {
  if(!$val['flv']['HTML']) continue;
  $tarp = explode('_', $key);
  foreach ($tarp as $key2 => $val2) $arp[] = $val2;
}
$resstrht = '';
if(count($arp) > 0) {
  $arp = array_unique($arp);
  foreach ($arp as $val) {
    if(!isset($convdata['bzl'][$val]['grn'])) $resstrht .= convert_ht($convdata['dadir'].$val.'_'.$convdata['bzdate'], $val, 'dsx/dict/'.$val.'.txt', $convdata['testfl']);
    else $resstrht .= convert_ht($convdata['dadir'].$val, $val, 'dsx/dict/'.$val.'.txt', $convdata['testfl'], $convdata['bzl'][$val]['grn']);
  }
  foreach ($convdata['bzl'] as $key => $val) {
    if(!$val['flv']['HTML']) continue;
    if(!isset($convdata['bzl'][$key]['grn'])) compile_ht($key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate']);
    else compile_ht($key, array($convdata['bzl'][$key]['grn'] => ''), $val['title'], $val['descr'], date('YmdHis',time()), $convdata['bzl'][$key]['grn']);
  }
  $arfiles = scandir('dsx/dict/');
  foreach ($arfiles as $key => $value) if(is_file('dsx/dict/'.$value)) @unlink('dsx/dict/'.$value);
}
if($resstrht != '') $resstr .= '<tr><th colspan="2">HTML</th></tr>'.$resstrht;


$resstrsd = '';
foreach ($convdata['bzl'] as $key => $val) {
  if(!$val['flv']['StarDict']) continue;
  if(!isset($convdata['bzl'][$key]['grn'])) $resstrsd .= convert_sd($convdata['dadir'], $key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate'], $convdata['testfl']);
  else $resstrsd .= convert_sd($convdata['dadir'], $key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate'], $convdata['testfl'], $convdata['bzl'][$key]['grn']);
}
if($resstrsd != '') $resstr .= '<tr><th colspan="2">StarDict</th></tr>'.$resstrsd;


$resstrmd = '';
foreach ($convdata['bzl'] as $key => $val) {
  if(!$val['flv']['MDict']) continue;
  if(!isset($convdata['bzl'][$key]['grn'])) $resstrmd .= convert_md($convdata['dadir'], $key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate'], $convdata['testfl']);
  else $resstrmd .= convert_md($convdata['dadir'], $key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate'], $convdata['testfl'], $convdata['bzl'][$key]['grn']);
}
if($resstrmd != '') $resstr .= '<tr><th colspan="2">MDict</th></tr>'.$resstrmd;


$resstrdsl = '';
foreach ($convdata['bzl'] as $key => $val) {
  if($val['flv']['DSL'] !== true) continue;
  if(!isset($convdata['bzl'][$key]['grn'])) $resstrdsl .= convert_dsl($convdata['dadir'], $key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate'], $convdata['testfl']);
  else $resstrdsl .= convert_dsl($convdata['dadir'], $key, array_flip(explode('_',$key)), $val['title'], $val['descr'], $convdata['bzdate'], $convdata['testfl'], $convdata['bzl'][$key]['grn']);
}
if($resstrdsl != '') $resstr .= '<tr><th colspan="2">DSL</th></tr>'.$resstrdsl;


header("Access-Control-Allow-Origin: *");
echo '<table class="resinfotable"><tbody>'.$resstr.'</tbody></table>';
} ?>