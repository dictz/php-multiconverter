<?php 
function convert_sd($dadir, $dafnam, $profdicarr, $dictitle, $dicdescr, $dadate, $testfl, $grn = '') {
$sd_dir = 'StarDict';
if(!is_dir($sd_dir)) mkdir($sd_dir);
$ddir = $sd_dir.'/'.str_replace('@', $dafnam, $GLOBALS['sd_catname']);
if(is_dir($ddir)) rrmdir($ddir);
mkdir($ddir);

$xaht = aht($GLOBALS['sd_theme']);
$wordcountall = 0;
$wordcount = 0;
$fndict = $ddir.'/'.$dafnam.'.dict';
$hdictwrite = fopen($fndict, 'a');

$curoffset = 0;
$tarr = array();
$tarr['0_0'] = ' ';
foreach ($profdicarr as $dakey => $val) {
  $fnamerd = $dadir;
  if($grn == '') {
    if($dakey == 'dabkrss') $fnamerd .= 'dabkrs_'.$dadate;
    else $fnamerd .= $dakey.'_'.$dadate;
  } else {
    $fnamerd .= $dakey;
  }
  $fp = @fopen($fnamerd, 'r');
  if(!$fp) return 'err:'.$fnamerd;
  $lbuf = '';
  $wordc = 1;
  fgsit($fp, $dakey);
  while (true) {
    $buffer = fgets($fp);
    if($buffer == "\r\n" || $buffer == "\n" || $buffer === false) {
      if($buffer === false && $lbuf == '') break;
      $lbuf = trim($lbuf);
      if($lbuf == '') continue;
      ++$wordcountall;
      $xtx = txta($dakey, $lbuf, $wordcountall, $grn, 'sd_indent', 'sd_theme');
      if($xtx == '') {
        $lbuf = '';
        continue;
      }
      $ard = explode("\n", $xtx);

      if($dakey == 'dabkrs' || $dakey == 'dabkrss' || $grn == 'cdict') {
        $ard[1] .= '<hr>'.$ard[2];
      }

      $ktl = fwrite($hdictwrite, $xaht.$ard[0].'<hr>'.$ard[1].$GLOBALS['sd_addcontent']);
      $tarr[$curoffset.'_'.$ktl] = keytrim($ard[0]);
      $curoffset += $ktl;
      ++$wordcount;
      $lbuf = '';
      if($testfl) {
        if($wordc >= $GLOBALS['tstnums']) break;
        else ++$wordc;
      }
    } else $lbuf .= $buffer;
  }
  fclose($fp);
}
fclose($hdictwrite);
uasort($tarr, 'ucmp');

$fnidx = $ddir.'/'.$dafnam.'.idx';
$hidxwrite = fopen($fnidx, 'a');
foreach ($tarr as $key => $val) {
  $keyar = explode('_', $key);
  fwrite($hidxwrite, $val."\x00".pack('N',$keyar[0]).pack('N',$keyar[1]));
}
fclose($hidxwrite);
unset($tarr);

$ifotext = 'StarDict\'s dict ifo file
version=2.4.2
wordcount='.$wordcount.'
idxfilesize='.filesize($fnidx).'
bookname='.$dictitle.'
date='.date('Y.m.d',time()).'
sametypesequence=h
description='.$dicdescr;

file_put_contents($ddir.'/'.$dafnam.'.ifo', $ifotext);
if($GLOBALS['sd_readme'] != '') file_put_contents($ddir.'/README.txt', "\xEF\xBB\xBF".$GLOBALS['sd_readme']);

dzipc($ddir, 'idx', 'gz', $GLOBALS['sd_compress']);
dzipc($ddir, 'dict', 'dz', $GLOBALS['sd_compress']);
zipc($ddir);
return restfunc($dafnam, $wordcount, $wordcountall);
}
?>