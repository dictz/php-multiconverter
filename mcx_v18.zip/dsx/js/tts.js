'use strict';
const synth = window.speechSynthesis;
let ttsset = {}, defaultvoiceidar = [], erreflag = false;
function defaultvoiceidar_gen() {
  let voices = synth.getVoices();
  defaultvoiceidar.length = 0;
  for(let i = 0; i < voices.length; i++) {
    //[voices[i].lang, voices[i].name, voices[i].voiceURI, voices[i].localService, voices[i].default];
    if(i == 0) {
      defaultvoiceidar.push(voices[i].name);
      break;
    }
  }
}

let tts = {
 start:function() {
   if('onvoiceschanged' in synth) synth.onvoiceschanged = tts.genvoicelist;
   tts.genvoicelist();
 },

 genvoicelist:function() {
   defaultvoiceidar_gen();
   istorage.getItem('ttsset', function(val) {
     ttsset = JSON.parse(val);
   }, function() {
     ttsset = {};
     if(defaultvoiceidar.length == 0) return;
     ttsset['dsxttsdef'] = [0, 1, 1, defaultvoiceidar.slice()];
     for(let key in db_list) ttsset[key] = [0, 1, 1, defaultvoiceidar.slice()];
     istorage.setItem('ttsset', JSON.stringify(ttsset));
   });
 },

 getutter:function(txt, voicename, pitch, rate) {
   const utterThis = new SpeechSynthesisUtterance(txt);
   let voices = synth.getVoices();
   for(let i = 0; i < voices.length; i++) {
     if(voices[i].name === voicename) {
       utterThis.voice = voices[i];
       utterThis.lang = voices[i].lang;
       break;
   } }
   utterThis.pitch = pitch;
   utterThis.rate = rate;
   return utterThis;
 },

 ssf:'stop',
 actiontts:function(dbs = tts.dbc, textts = tts.ustext) {
   tts.dbc = dbs;
   tts.ustext = usli(textts, 333); //32767max
   if(defaultvoiceidar.length == 0) {
     ok.ok(xl('tts_nofovoi'));
     return;
   }
   tts.hdi = ok.constr(`
     <button class="mlist" id="sellng_id" onclick="ok.hide();tts.sellng();"></button><br>
     <textarea id="ttstxtarea_id" style="white-space:normal;" oninput="tts.ustext=ttstxtarea_id.value=usli(ttstxtarea_id.value,333);">${dsx.tomnemonics(tts.ustext)}</textarea>
   `, `
     <button onclick="ok.hide();" id="ttsexitbut_id">${ok.txtbut('close')}</button>
     <button onclick="ok.hide();tts.setting();" id="ttssettingbut_id" class="ico_sett"></button>
     <button onclick="ok.dig('start');" id="ttsstartstopbut_id">${xl('tts_voice')}</button>
   `, function(m) {
     if(m == 'htset') {

       let rl = [];
       let dbttsset = ttsset[tts.dbc];
       for(let i = 0; i < dbttsset[3].length; i++) {
         rl.push(['', '', i, dbttsset[3][i]]);
       }
       rl[dbttsset[0]][1] = 'checked';
       sellng_id.innerText = rl[dbttsset[0]][3];
       ok.delay = true;
       tts.sellng = ok.rlist('', rl, function(id, val) {
         if(id !== false) {
           ttsset[tts.dbc][0] = +val;
           istorage.setItem('ttsset', JSON.stringify(ttsset), function() {
             tts.actiontts();
           });
         } else tts.actiontts();
       });

       tts.blockbut = function(b) {
         if(g('sellng_id')) sellng_id.disabled = b;
         if(g('ttstxtarea_id')) ttstxtarea_id.disabled = b;
         if(g('ttssettingbut_id')) ttssettingbut_id.disabled = b;
       };

       if(tts.ssf == 'start' || tts.ssf == 'play') {
         tts.blockbut(true);
         ttsstartstopbut_id.onclick = function(){ok.dig('stop');};
         ttsstartstopbut_id.innerText = xl('tts_stop');
       }

     } else if(m == 'start') {

       if(synth.speaking) return false;
       if(String(ttstxtarea_id.value).length == 0) {
         ttstxtarea_id.focus();
         return false;
       }

       tts.ssf = 'start';
       tts.blockbut(true);
       if(g('ttsstartstopbut_id')) ttsstartstopbut_id.onclick = function(){ok.dig('stop');};
       if(g('ttsstartstopbut_id')) ttsstartstopbut_id.innerText = xl('tts_stop');

       tts.dbttsset = ttsset[tts.dbc];
       tts.utt = tts.getutter(ttstxtarea_id.value, tts.dbttsset[3][+tts.dbttsset[0]], tts.dbttsset[1], tts.dbttsset[2]);
       tts.utt.onerror = function(event) {
         tts.utt.onend();
         if(event.error == 'canceled' || event.error == 'interrupted') return;
         if(ok.curok == tts.hdi) {
           ok.hide();
           if(erreflag) {
             ok.autohide(3333, ok.ok(`${event.error}<br>${xl('tts_prnotres')}`, undefined, ''));
             erreflag = false;
           } else {
             erreflag = true;
             ok.autohide(3333, ok.ok(`${event.error}<br>${xl('tts_unkerr')}`, undefined, ''));
           }
         }
         istorage.removeItem('ttsset', function() {
           tts.genvoicelist();
         });
       };

       tts.utt.onstart = function(event) {
         tts.ssf = 'play';
       };

       tts.utt.onend = function(event) {
         tts.ssf = 'stop';
         if(ok.curok == tts.hdi) {
           if(g('ttsstartstopbut_id')) ttsstartstopbut_id.onclick = function(){ok.dig('start');};
           if(g('ttsstartstopbut_id')) ttsstartstopbut_id.innerText = xl('tts_voice');
           tts.blockbut(false);
         }
       };

       synth.speak(tts.utt);

     } else if(m == 'stop') synth.cancel();

     return false;
   });
 },

 setting:function() {
   ok.constr(`
    <div class="ttssetting">
     <fieldset class="ttssettinglang">
       <legend>${xl('tts_lang')}</legend>
       <button class="mlist" id="sellanglist_id" onclick="ok.hide();tts.checklng();"></button><br>
     </fieldset>
     <fieldset class="ttssettingpitch">
       <legend>${xl('tts_voitone')}</legend>
       <button class="ico_add" onclick="ok.dig('pitch+');"></button>
       <span id="pitchvalue_id"></span>
       <button class="ico_sub" onclick="ok.dig('pitch-');"></button>
     </fieldset>
     <fieldset class="ttssettingrate">
       <legend>${xl('tts_voispeed')}</legend>
       <button class="ico_add" onclick="ok.dig('rate+');"></button>
       <span id="ratevalue_id"></span>
       <button class="ico_sub" onclick="ok.dig('rate-');"></button>
     </fieldset>
    </div>
   `, `
     <button onclick="ok.hide();istorage.setItem('ttsset',JSON.stringify(ttsset),function(){tts.actiontts();});">${ok.txtbut('close')}</button>
   `, function(m) {
     if(m == 'htset') {
       let rl = [];
       let dbttsset = ttsset[tts.dbc];
       let voices = synth.getVoices();
       for(let i = 0; i < voices.length; i++) {
         let ch = '';
         if(dbttsset[3].join('').includes(voices[i].name)) ch = 'checked';
         rl.push(['', ch, voices[i].name, voices[i].name]);
       }
       ok.lcor('sellanglist_id', ok.lcou(rl));
       ok.delay = true;
       tts.checklng = ok.clist('', rl, function(c, ar) {
         if(c === false) {tts.setting(); return;}
         let db = tts.dbc;
         ttsset[db][0] = 0;
         ttsset[db][3].length = 0;
         if(+c !== 0) {
           for(let i = 0; i < ar.length; i++) {
             if(ar[i][1] == 'checked') ttsset[db][3].push(ar[i][2]);
           }
         } else {
           ttsset[db][3] = ttsset[db][3].concat(defaultvoiceidar.slice());
           ok.autohide(1400, ok.ok(xl('tts_setchdef'), undefined, ''));
         }
         tts.setting();
       });
       pitchvalue_id.innerText = dbttsset[1];
       ratevalue_id.innerText = dbttsset[2];
     } else if(m == 'pitch+' && +pitchvalue_id.innerText < 2) {
       pitchvalue_id.innerText = +(+pitchvalue_id.innerText + 0.1).toFixed(1);
       ttsset[tts.dbc][1] = +pitchvalue_id.innerText;
     } else if(m == 'pitch-' && +pitchvalue_id.innerText > 0.1) {
       pitchvalue_id.innerText = +(+pitchvalue_id.innerText - 0.1).toFixed(1);
       ttsset[tts.dbc][1] = +pitchvalue_id.innerText;
     } else if(m == 'rate+' && +ratevalue_id.innerText < 2) {
       ratevalue_id.innerText = +(+ratevalue_id.innerText + 0.1).toFixed(1);
       ttsset[tts.dbc][2] = +ratevalue_id.innerText;
     } else if(m == 'rate-' && +ratevalue_id.innerText > 0.1) {
       ratevalue_id.innerText = +(+ratevalue_id.innerText - 0.1).toFixed(1);
       ttsset[tts.dbc][2] = +ratevalue_id.innerText;
     }
     return false;
   });
 },


};
