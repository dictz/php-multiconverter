<?php 
// Настройки вынесенные сюда переопределяют настройки по умолчанию

// $GLOBALS['sd_indent'] = 30;
// $GLOBALS['threads'] = 2;
// $GLOBALS['option_zip'] = false;
// ...

?>