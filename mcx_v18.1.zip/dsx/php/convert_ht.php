<?php 
function txtaht($dafnam, $txa, $wcnt, $grn) {
  $txa = str_replace('\\', '\\\\', $txa);
  $txa = str_replace(["\r","\t"], ['',' '], $txa);

  $txar = preg_split('/\n\s/', $txa, 2, PREG_SPLIT_NO_EMPTY);
  if($dafnam == 'dabkrs' || $dafnam == 'dabkrss' || $grn == 'cdict') {
    if(count($txar) == 2) {
      $txar2 = preg_split('/\n/', $txar[1], 2, PREG_SPLIT_NO_EMPTY);
      $txa = str_replace("\n", '\\n', $txar[0])."\n".str_replace("\n", '\\n', $txar2[0])."\n".str_replace("\n", '\\n', $txar2[1]);
    } else {
      $txa = '@err'.$wcnt."\n".'_'."\n".str_replace("\n", '\\n', $txa);
    }
  } else if($dafnam == 'dabruks' || $dafnam == 'examples' || $grn == 'dsldict') {
    if(count($txar) == 2) {
      $txa = str_replace("\n", '\\n', $txar[0])."\n".str_replace("\n", '\\n', $txar[1]);
    } else {
      $txa = '@err'.$wcnt."\n".str_replace("\n", '\\n', $txa);
    }
  }

  if($dafnam == 'dabkrss') {
    if(preg_match("/\n[\s]*_[\s]*\n/", $txa) == 1) {
      return '';
    }
  }

  $txa = str_replace('\'', '\\\'', $txa);
  $txa = str_replace("\n", '\',\'', $txa);
  $txa = str_replace('<', '＜', $txa);
  $txa = str_replace('>', '＞', $txa);
  $txa = preg_replace('/(\[m[0-9]+\]|\[[cipu\*]\]|\[\/[cipu\*]\]|\[c [^\[\]\\\\]*\]|\[ref\]|\[\/ref\]|\[ex\]|\[\/ex\]|\[sub\]|\[\/sub\]|\[sup\]|\[\/sup\])/', ' ', $txa);
  $txa = preg_replace('/\\\\\\\\([\[\]])/', '$1', $txa);
  $txa = str_replace('[/m]', ' \\n ', $txa);
  if($dafnam == 'dabruks') {
    $txa = preg_replace('/\\\\n[ ]*•[ ]*\\\\n.*$/', '', $txa);
    $txa = preg_replace('/\\\\n[ ]*••[ ]*\\\\n/', '\\n *** \\n', $txa);
  }
  $txa = preg_replace('/\[b\]([ ]*[IV]+[ ,])/', '\\n•$1', $txa);
  $txa = preg_replace('/\[b\]([ ]*[IV]+[ ]*)\[\/b\]/', '\\n•$1\\n', $txa);
  $txa = preg_replace('/\[b\]([^\[\]\n\/]+)\[\/b\]/', '[$1]', $txa);
  $txa = str_replace('[/b]', ' \\n ', $txa);
  while(preg_match('/\\\\n[ ]*\\\\n/', $txa) == 1) {
    $txa = preg_replace('/\\\\n[ ]*\\\\n/', '\\n', $txa);
  }
  $txa = preg_replace('/[ ]{2,}/', ' ', $txa);
  $txa = preg_replace('/[ ]*\\\\n[ ]*/', '\\n', $txa);
  $txa = preg_replace('/(\\\\n| )*\',\'(\\\\n| )*/', '\',\'', $txa);
  $txa = preg_replace('/(\\\\n| )*$/', '', $txa);
  $txa = preg_replace('/^(\\\\n| )*/', '', $txa);
  $txa = preg_replace('/([\(\[])[ ]+/', '$1', $txa);
  $txa = preg_replace('/[ ]+([\)\]])/', '$1', $txa);

  if($dafnam == 'examples') {
    if(preg_match('/(\\\\n\\\\n.*)(\\\\n)+/', $txa) == 1) {
      $txa = str_replace('\\n\\n', '\\n', $txa);
    }
  }
  return '\''.$txa.'\''."\n";
}

function convert_ht($fnamerd, $dafnam, $fnamewrt, $testfl, $grn = '') {
@unlink($fnamewrt);

if($dafnam == 'dabkrss') $fnamerd = str_replace('dabkrss', 'dabkrs', $fnamerd);
$wordcount = 0;
$wordcountall = 0;
$fp = @fopen($fnamerd, 'r');
if($fp === false) return 'err:'.$fnamerd;
$hwrite = fopen($fnamewrt, 'a');
$lbuf = '';
fgsit($fp, $dafnam);
while (true) {
  $buffer = fgets($fp);
  if($buffer == "\r\n" || $buffer == "\n" || $buffer === false) {
    if($buffer === false && $lbuf == '') break;
    $lbuf = trim($lbuf);
    if($lbuf == '') continue;
    ++$wordcountall;
    $tbu = txtaht($dafnam, $lbuf, $wordcountall, $grn);
    if($tbu == '') {
      $lbuf = '';
      continue;
    }
    fwrite($hwrite, $tbu);
    ++$wordcount;
    $lbuf = '';
    if($testfl) {
      if($wordcount >= $GLOBALS['tstnums']) break;
    }
  } else $lbuf .= $buffer;
}
fclose($hwrite);
fclose($fp);
return restfunc($dafnam, $wordcount, $wordcountall);
}

//----------------------------------------------------------------------------------

function repl64($str) {
  $arst2 = preg_split('/url\(\'([^\'\(\)\n"]*)\'\)/', $str, -1, PREG_SPLIT_DELIM_CAPTURE);//PREG_SPLIT_NO_EMPTY
  $val2 = '';
  foreach ($arst2 as $value2) {
    if(preg_match('/^dsx\/fonts\/[^\{\}"\'\n]*\.ttf$/',$value2)) {
      $val2 = $val2.'url(data:font/truetype;charset=utf-8;base64,'.base64_encode(file_get_contents($value2)).')';
    } else if(preg_match('/^dsx\/fonts\/[^\{\}"\'\n]*\.otf$/',$value2)) {
      $val2 = $val2.'url(data:font/opentype;charset=utf-8;base64,'.base64_encode(file_get_contents($value2)).')';
    } else {
      $val2 = $val2.$value2;
    }
  }
  return $val2;
}

function jscr($filename, $dsxsource, $profdicarr, $cur_profile_dict, $grn) {
  $handle = fopen($filename, 'a');

  $arst3 = preg_split('/<script src="([^"\'\n<>]*)" type="text\/javascript"[^\n<>]*>[^\n<>]*<\/script>/', $dsxsource, -1, PREG_SPLIT_DELIM_CAPTURE);//PREG_SPLIT_NO_EMPTY
  $count = 0;
  foreach ($arst3 as $value3) {
    $val3 = '';
    if(preg_match('/^dsx\/[^<>"\'\n]*\.js$/',$value3)) {
      $val39 = '';
      $arst39 = preg_replace('/^[^<>"\'\n]+\/([^\/<>"\'\n]+)\.js$/', '$1', $value3);
      $val39 = $arst39.'_idscript';
      $val3 = '<script type="text/javascript" id="'.$val39.'">';
      $fsize = filesize($value3);
      $lenste = 11111111;
      if($fsize <= $lenste) {
        $val3 = $val3.file_get_contents($value3);
      } else {
        $hread = fopen($value3, 'r');
        if($hread === false) {echo 'err:'.$value3; return 0;}
        for($ii = $fsize; ; ) {
          if($ii == 0) {
            break;
          } else if($ii <= $lenste) {
            $readbyte = $ii;
            $ii = 0;
          } else {
            $readbyte = $lenste;
            $ii = $ii - $lenste;
          }
          $val3 = $val3.fread($hread, $readbyte);
          $count = $count + fwrite($handle, $val3);
          $val3 = '';
        }
        fclose($hread);
      }
      $val3 = $val3.'</script>';
      
    } else if(preg_match('/^dsx\/[^<>"\'\n]*\.txt$/',$value3)) {
      $val39 = '';
      $arst39 = preg_replace('/^[^<>"\'\n]+\/([^\/<>"\'\n]+)\.txt$/', '$1', $value3);
      if(!isset($profdicarr[$arst39])) {$val3 = ''; continue;}
      $val39 = $arst39.'_ids_';
      $stdname = $value3;
      if($arst39 == $grn) $stdname = str_replace($arst39, $cur_profile_dict, $value3);
      $hread = fopen($stdname, 'r');
      if($hread === false) {echo 'err:'.$stdname; return 0;}
      $openfl = false;
      $iii = 0;
      for($ii = 1; ; ) {
        $val3 = fgets($hread);
        $enfl = false;
        if($val3 === false) {
          $enfl = true;
          if($openfl == true) {
            $ii = 10000;
            $val3 = '';
          } else {
            break;
          }
        } else {
          $val3 = '['.str_replace("\n", '', $val3).'],'."\n";
        }
        if($ii == 1) {
          $openfl = true;
          $val3 = '<script type="text/javascript" id="'.$val39.$iii.'">'."\n".'\'use strict\';'."\n".'(function() {'."\n".'let db_temp = ['."\n".$val3;
          $ii = $ii + 1;
        } else if($ii == 10000) {
          $openfl = false;
          $ii = 1;
          $val3 .= '];'."\n".$arst39.'.splice('.$arst39.'.length, 0, ...db_temp);'."\n".'db_temp.length = 0;'."\n".'dbloadpf();'."\n".$val39.$iii.'.remove();'."\n".'})();'."\n".'</script>'."\n";
          $iii = $iii + 1;
        } else {
          $openfl = true;
          $ii = $ii + 1;
        }
        $count = $count + fwrite($handle, $val3);
        $val3 = '';
        if($enfl === true) {
          break;
        }
      }
      fclose($hread);
      
    } else if(preg_match('/^dsx\/[^<>"\'\n]*\.jsn$/',$value3)) {
      $val3 = '';
      
    } else {
      $val3 = $value3;
      
    }
    $count = $count + fwrite($handle, $val3);
  }

  fclose($handle);
  return $count;
}

//----------------------------------------------------------------------------------

function compile_ht($cur_profile_dict, $profdicarr, $dictitle, $dicdescr, $dadate, $grn = '') {
  $imfoln = '';
  $dsxlangcode = $GLOBALS['ht_langcode'];
  if($grn == '') {
    $imfoln = 'images_bkrs';
    $dsxlangcode = 'russian-RF';
  } else if($grn == 'cdict') {
    $imfoln = 'images_mdbg';
    $dsxlangcode = 'english-USA';
  } else if($grn == 'dsldict') {
    $imfoln = 'images_dsl';
  }

  $search  = array('@@var_dicid@@', '@@var_dicver@@', '@@var_dictitle@@', '@@var_dicdescr@@', '@@var_dicprof@@', '@@var_langc@@', '@@var_dicicon@@');
  $replace = array($cur_profile_dict, $dadate, $dictitle, $dicdescr, base64_encode(json_encode($profdicarr)), $dsxlangcode, base64_encode(file_get_contents('dsx/'.$imfoln.'/favicon.ico')));
  $dsxsource = str_replace($search, $replace, file_get_contents('dsx/dsx.html_'));

  $dsxsource3 = '';
  $arst1 = preg_split('/<link href="([^">]*)"[^>]*\/>/', $dsxsource, -1, PREG_SPLIT_DELIM_CAPTURE);//PREG_SPLIT_NO_EMPTY
  foreach ($arst1 as $value) {
    $val4 = '';
    if(preg_match('/^[^<>"\'\n]*\.css$/', $value)) {
      $val4 = '<style>'.repl64(file_get_contents($value)).'</style>';
    } else {
      $val4 = $value;
    }
    $dsxsource3 .= $val4;
  }
  $dsxsource = '';
  
  $htmldir = 'HTML';
  if(!is_dir($htmldir)) mkdir($htmldir);
  $ddir = $htmldir.'/'.str_replace('@', $cur_profile_dict, $GLOBALS['ht_catname']);
  if(is_dir($ddir)) rrmdir($ddir);
  mkdir($ddir);
  
  $filename = $ddir.'/'.$cur_profile_dict.'.html';
  jscr($filename, $dsxsource3, $profdicarr, $cur_profile_dict, $grn);

  $swsource = file_get_contents('dsx/js/serviceworker.js_');
  $search  = array('@@var_dicver@@', '@@dsx_dict_id@@', '@@dsx_dir@@');
  $replace = array($dadate, $cur_profile_dict, '/'.$ddir);
  file_put_contents($ddir.'/serviceworker.js', str_replace($search, $replace, $swsource));

  if($GLOBALS['ht_readme'] != '') file_put_contents($ddir.'/README.txt', "\xEF\xBB\xBF".$GLOBALS['ht_readme']);

  zipc($ddir);
}
?>