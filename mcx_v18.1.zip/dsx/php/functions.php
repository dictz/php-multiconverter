<?php 
function restfunc($dafnam, $wordcount, $wordcountall) {
  $wd = $wordcountall - $wordcount;
  return number_format($wordcount, 0, '', '.').'_'.number_format($wd, 0, '', '.');
}

function ucmp($a, $b) {
  $c = mb_strtolower($a);
  $d = mb_strtolower($b);
  if($c == $d) {
    if($a == $b) return 0;
    return ($a < $b) ? -1 : 1;
  }
  return ($c < $d) ? -1 : 1;
}

function rrmdir($src) {
  $dir = opendir($src);
  if($dir === false) return false;
  while(false !== ( $file = readdir($dir)) ) {
    if(( $file != '.' ) && ( $file != '..' )) {
      $full = $src . '/' . $file;
      if( is_dir($full) ) {
        rrmdir($full);
      } else {
        @unlink($full);
      }
    }
  }
  closedir($dir);
  @rmdir($src);
}

function zipc($zipdn) {
  @unlink($zipdn.'.zip');
  if(!$GLOBALS['option_zip']) return false;

  $farr = scandir($zipdn);
  if($farr === false) return false;
  foreach ($farr as $key => $val) if(!is_file($zipdn.'/'.$val)) unset($farr[$key]);
  if(count($farr) == 0) return false;

  $zip = new ZipArchive();
  if($zip->open($zipdn.'.zip', ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
    foreach ($farr as $key => $val) {
      if($zip->addFile($zipdn.'/'.$val, $val) === false) {$zip->close(); return false;}
    }
    if($GLOBALS['zip_password'] != '') {
      $zip->setPassword($GLOBALS['zip_password']);
      foreach ($farr as $key => $val) {
        if($zip->setEncryptionName($val, ZipArchive::EM_AES_128) === false) {$zip->close(); return false;}
      }
    }
    $zip->close();
    if($GLOBALS['zip_srccatdel']) rrmdir($zipdn);
    return true;
  } else return false;
}

function fgsit($fp, $dafnam) {
  if($dafnam == 'dabkrs' || $dafnam == 'dabkrss' || $dafnam == 'dabruks') $b = fread($fp, 3);
  while(true) {
    if(mb_substr(trim(fgets($fp)),0,1) != '#') break;
  }
}

function dzipc($ddir, $fext, $form, $compress) {
  if($compress == 0) return false;
  $farr = scandir($ddir);
  if($farr === false) return false;
  foreach ($farr as $key => $val) if(!is_file($ddir.'/'.$val) || preg_match('/\.'.$fext.'$/', $val) != 1 || filesize($ddir.'/'.$val) == 0) unset($farr[$key]);
  if(count($farr) == 0) return false;

  foreach ($farr as $key => $val) {
    $fnread = $ddir.'/'.$val;
    $fsz = filesize($fnread);
    if($form == 'dz') if($fsz > (0xfff4/2)*58900) continue;
    $fhcrc = pack('V', implode('', unpack('N', hash_file('crc32b', $fnread, true))));
    $fzhead = "\x1f\x8b\x08";
    if($form == 'dz') $fzhead .= "\x04";
    else $fzhead .= "\x00";
    $fzhead .= pack('V', time())."\x02\x03";
    $brsz = 102400;
    if($form == 'dz') $brsz = 58900;
    
    $fnwrite = $fnread.'.gz';
    if($form == 'dz') $fnwrite = '~dz.tmp';

    $defcontext = deflate_init(ZLIB_ENCODING_GZIP, ['level' => $compress]); 
    $dsxxx = deflate_add($defcontext, "\x64\x73\x78", ZLIB_FULL_FLUSH);

    $gzextrar = array();
    $fhwrite = fopen($fnwrite, 'a');
    if($form != 'dz') fwrite($fhwrite, $fzhead);
    $fhread = fopen($fnread, 'r');
    $ftmpsz = $fsz;
    for( ; ; ) {
      if($ftmpsz > $brsz) {
        $gzextrar[] = fwrite($fhwrite, deflate_add($defcontext, fread($fhread, $brsz), ZLIB_FULL_FLUSH));
        $ftmpsz -= $brsz;
      } else if($ftmpsz == 0) {
        break;
      } else {
        $gzextrar[] = fwrite($fhwrite, deflate_add($defcontext, fread($fhread, $ftmpsz), ZLIB_FULL_FLUSH));
        break;
      }
    }
    $dsxxx = deflate_add($defcontext, '', ZLIB_FINISH);
    fclose($fhread);
    unlink($fnread);
    if($form != 'dz') {
      fwrite($fhwrite, "\x03\x00".$fhcrc.pack('V',$fsz));
    }
    fclose($fhwrite);
    if($form != 'dz') continue;

    $fhread = fopen($fnwrite, 'r');
    $fhwrite = fopen($fnread.'.dz', 'a');
    $dzxlen = (count($gzextrar)*2)+10;
    fwrite($fhwrite, $fzhead.pack('v',$dzxlen)."\x52\x41".pack('v',$dzxlen-4)."\x01\x00".pack('v',$brsz).pack('v',count($gzextrar)));
    foreach ($gzextrar as $key => $val) fwrite($fhwrite, pack('v',$val));
    $ftmpsz = filesize($fnwrite);
    $brsz = 102400;
    for( ; ; ) {
      if($ftmpsz > $brsz) {
        fwrite($fhwrite, fread($fhread, $brsz));
        $ftmpsz -= $brsz;
      } else if($ftmpsz == 0) {
        break;
      } else {
        fwrite($fhwrite, fread($fhread, $ftmpsz));
        break;
      }
    }
    fclose($fhread);
    unlink($fnwrite);
    fwrite($fhwrite, "\x03\x00".$fhcrc.pack('V',$fsz));
    fclose($fhwrite);
  }
  return true;
}

function aht($theme) {
  if($theme == '') return '';
  $str = preg_replace('#@media[^@]+/\*'.$theme.'\*/#', '', $GLOBALS['theme_style']);
  if($theme != 'app') $str = preg_replace(['#@media[^\{\}\n]+\{#','#\}[^\{\}\n]+/\*@\*/#'], ['',''], $str);
  else $str = str_replace(['/*light*/','/*dark*/'], ['',''], $str);
  $str = str_replace(["\r","\n"], ['',''], $str);
  return preg_replace(['/[\s]{2,}/', '#/\*@\*/#'], [' ', ''], $str);
}

function keytrim($key) {
  $key = preg_replace('/<br>/', ' ', $key);
  $key = preg_replace('/<[^<>]+>/', '', $key);
  $key = str_replace(['&lt;','&gt;'], ['<','>'], $key);
  if(mb_strlen($key) > 50) return trim(mb_substr($key, 0, 50)).'…';
  return trim($key);
}

function txta($dafnam, $txa, $wcnt, $grn, $indent, $theme) {
  $txa = str_replace(["\r","\t"], ['',' '], $txa);

  $txar = preg_split('/\n\s/', $txa, 2, PREG_SPLIT_NO_EMPTY);
  if($dafnam == 'dabkrs' || $dafnam == 'dabkrss' || $grn == 'cdict') {
    if(count($txar) == 2) {
      $txar2 = preg_split('/\n/', $txar[1], 2, PREG_SPLIT_NO_EMPTY);
      $txa = str_replace("\n", '\\n', $txar[0])."\n".str_replace("\n", '\\n', $txar2[0])."\n".str_replace("\n", '\\n', $txar2[1]);
    } else {
      $txa = '@err'.$wcnt."\n".'_'."\n".str_replace("\n", '\\n', $txa);
    }
  } else if($dafnam == 'dabruks' || $dafnam == 'examples' || $grn == 'dsldict') {
    if(count($txar) == 2) {
      $txa = str_replace("\n", '\\n', $txar[0])."\n".str_replace("\n", '\\n', $txar[1]);
    } else {
      $txa = '@err'.$wcnt."\n".str_replace("\n", '\\n', $txa);
    }
  }

  if($dafnam == 'dabkrss') {
    if(preg_match("/\n[\s]*_[\s]*\n/", $txa) == 1) {
      return '';
    }
  }

  $txa = str_replace(['<','>'], ['&lt;','&gt;'], $txa);
  $txa = preg_replace('/(\[[\*]\]|\[\/[\*]\])/', ' ', $txa);
  if($GLOBALS[$indent] == 0) $txa = preg_replace('/(\[m[0-9]?\]|\[\/m\])/', ' \\n ', $txa);
  else $txa = preg_replace('/\[m[01]?\](.*?)\[\/m\]/', ' \\n $1 \\n ', $txa);
  $txa = preg_replace('/(\[b\][ ]*[IV]+[ ,])/', '\\n$1', $txa);
  $txa = preg_replace('/(\[b\][ ]*[IV]+[ ]*\[\/b\])/', '\\n$1', $txa);
  while(preg_match('/\\\\n[ ]*\\\\n/', $txa) == 1) {
    $txa = preg_replace('/\\\\n[ ]*\\\\n/', '\\n', $txa);
  }
  $txa = preg_replace('/[ ]{2,}/', ' ', $txa);
  $txa = preg_replace('/[ ]*\\\\n[ ]*/', '\\n', $txa);
  $txa = preg_replace('/(\\\\n| )*\n(\\\\n| )*/', "\n", $txa);
  $txa = preg_replace('/(\\\\n| )*$/', '', $txa);
  $txa = preg_replace('/^(\\\\n| )*/', '', $txa);
  $txa = preg_replace('/([\(\[])[ ]+/', '$1', $txa);
  $txa = preg_replace('/[ ]+([\)\]])/', '$1', $txa);
  if($dafnam == 'examples') {
    if(preg_match('/(\\\\n\\\\n.*)(\\\\n)+/', $txa) == 1) {
      $txa = str_replace('\\n\\n', '\\n', $txa);
    }
  }
  if($GLOBALS[$indent] > 0) {
    $txa = preg_replace_callback('/\[m(\d)\](.*?)\[\/m\]/', function($matches) use ($indent) {
      if(intval($matches[1]) < 2) return ' \\n '.$matches[2].' \\n ';
      return '<div style="padding-inline-start:'.((intval($matches[1])-1)*$GLOBALS[$indent]).'px;">'.$matches[2].'</div>';
    }, $txa);
  }

  $txa = preg_replace('/\[([\/]?)(i|b|u|sub|sup)\]/', '<$1$2>', $txa);
  if($GLOBALS[$theme] != '') {
    $txa = preg_replace('#(\[c[^\[\]\\\\]*\]|\[p\])#', '<font class="p">', $txa);
    $txa = str_replace('[ex]', '<font class="ex">• ', $txa);
    $txa = preg_replace('#\[/(ex|p|c)\]#', '</font>', $txa);
  } else {
    $txa = preg_replace('#(\[c[^\[\]\\\\]*\]|\[/c\]|\[p\]|\[/p\]|\[/ex\])#', '', $txa);
    $txa = str_replace('[ex]', '• ', $txa);
  }
  if($grn == '') $txa = preg_replace('/(?<=\[\/ref\])([\s\p{P}]*)(?=\[ref\])/u', '<br>$1', $txa);
  if($indent == 'md_indent') $refpref = 'entry://';
  else $refpref = '';
  $txa = preg_replace('/\[ref\]([^\[\]]+)\[\/ref\]/', '<a href="'.$refpref.'$1">$1</a>', $txa);
  $txa = preg_replace('/\\\\([\[\]])/', '$1', $txa);
  return str_replace('\\n', '<br>', $txa);
}

?>