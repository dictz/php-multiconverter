<?php
function sbmr($txa) {
  return preg_replace_callback('/^[^\n]*$/mu', function($matches) {
    return ' '.trim($matches[0]);
  }, $txa);
}

function tdre($s) {
  return preg_replace(['/<(b|h)r>/','/<[^<>]+>/'], ["\n",''], $s);
}

function txta_dsl($dafnam, $txa, $wcnt, $grn) {
  $txa = str_replace("\r", '', $txa);

  $txar = preg_split('/\n\s/', $txa, 2, PREG_SPLIT_NO_EMPTY);
  if(count($txar) == 2) {
    $txa = preg_replace('/[ ]{2,}/u', ' ', trim(str_replace("\n",' ',$txar[0])))."\n".sbmr($txar[1]);
  } else {
    if($dafnam == 'dabkrs' || $dafnam == 'dabkrss' || $grn == 'cdict') {
      $txa = '@err'.$wcnt."\n".' _'."\n".sbmr($txa);
    } else if($dafnam == 'dabruks' || $dafnam == 'examples') {
      $txa = '@err'.$wcnt."\n".sbmr($txa);
    }
  }

  if($dafnam == 'dabkrss') {
    if(preg_match("/\n[\s]*_[\s]*\n/", $txa) == 1) {
      return '';
    }
  }

  return $txa."\n";
}

function convert_dsl($dadir, $dafnam, $profdicarr, $dictitle, $dicdescr, $dadate, $testfl, $grn = '') {
$dsl_dir = 'DSL';
if(!is_dir($dsl_dir)) mkdir($dsl_dir);
$ddir = $dsl_dir.'/'.str_replace('@', $dafnam, $GLOBALS['dsl_catname']);
if(is_dir($ddir)) rrmdir($ddir);
mkdir($ddir);

$wordcountall = 0;
$wordcount = 0;
$numparts = 1;
$partinfarr = array();

$lngindex = $GLOBALS['dsl_cn_langindex'];
$lngcontent = $GLOBALS['dsl_cn_langcontent'];
if(count($profdicarr) == 1) {
  $dada = array_flip($profdicarr)[0];
  if($dada == 'dabkrs' || $dada == 'dabkrss' || $dada == 'examples') {
    $lngcontent = $GLOBALS['dsl_ru_langcontent'];
  } else if($dada == 'dabruks') {
    $lngindex = $GLOBALS['dsl_ru_langindex'];
  }
}

$dslhead = '#NAME "'.tdre($dictitle).'@@p@@"
#INDEX_LANGUAGE "'.$lngindex.'"
#CONTENTS_LANGUAGE "'.$lngcontent.'"';

$szaf = 0;
foreach ($profdicarr as $dakey => $val) {
  $fnamerd = $dadir;
  if($grn == '') {
    if($dakey == 'dabkrss') $fnamerd .= 'dabkrs_'.$dadate;
    else $fnamerd .= $dakey.'_'.$dadate;
  } else {
    $fnamerd .= $dakey;
  }
  $szaf += filesize($fnamerd);
}

if($szaf > $GLOBALS['dsl_threshold']) $numparts = $GLOBALS['dsl_numparts'];
for($i = 1; $i <= $numparts; $i++) {
  if($numparts == 1) {
    $fnpstf = '';
    $tpstf = '';
  } else {
    $fnpstf = '_'.$i;
    $tpstf = ' ( '.$i.' / '.$numparts.' )';
  }
  $hxdslwrite = fopen($ddir.'/'.$dafnam.$fnpstf.'.dsl', 'a');
  $fsz = fwrite($hxdslwrite, "\xFF\xFE".iconv('UTF-8','UTF-16LE//IGNORE',str_replace('@@p@@',$tpstf,$dslhead)));
  if($numparts > 1 && $i == 1) {
    if($GLOBALS['dsl_include']) for($ii = 2; $ii <= $numparts; $ii++) $fsz += fwrite($hxdslwrite, iconv('UTF-8','UTF-16LE//IGNORE',"\n".'#INCLUDE "'.$dafnam.'_'.$ii.'.dsl"'));
  }
  $fsz += fwrite($hxdslwrite, iconv('UTF-8','UTF-16LE//IGNORE',"\n\n"));
  $partinfarr[] = array($hxdslwrite, $fsz, 0);
}

foreach ($profdicarr as $dakey => $val) {
  $fnamerd = $dadir;
  if($grn == '') {
    if($dakey == 'dabkrss') $fnamerd .= 'dabkrs_'.$dadate;
    else $fnamerd .= $dakey.'_'.$dadate;
  } else {
    $fnamerd .= $dakey;
  }

  $fp = @fopen($fnamerd, 'r');
  if(!$fp) return 'err:'.$fnamerd;
  $lbuf = '';
  $wordc = 1;
  fgsit($fp, $dakey);
  while (true) {
    $buffer = fgets($fp);
    if($buffer == "\r\n" || $buffer == "\n" || $buffer === false) {
      if($buffer === false && $lbuf == '') break;
      $lbuf = trim($lbuf);
      if($lbuf == '') continue;
      ++$wordcountall;
      $xtx = txta_dsl($dakey, $lbuf, $wordcountall, $grn);
      if($xtx == '') {
        $lbuf = '';
        continue;
      }

      $focf = 0;
      $minp = 0;
      foreach($partinfarr as $key => $val) {
        if($key == 0) {
          $minp = $val[$GLOBALS['dsl_parbalance']];
          $focf = 0;
        }
        if($minp > $val[$GLOBALS['dsl_parbalance']]) {
          $minp = $val[$GLOBALS['dsl_parbalance']];
          $focf = $key;
        }
      }
      $partinfarr[$focf][1] += fwrite($partinfarr[$focf][0], iconv('UTF-8','UTF-16LE//IGNORE',$xtx));
      ++$partinfarr[$focf][2];

      ++$wordcount;
      $lbuf = '';
      if($testfl) {
        if($wordc >= $GLOBALS['tstnums']) break;
        else ++$wordc;
      }
    } else $lbuf .= $buffer;
  }
  fclose($fp);
}
foreach($partinfarr as $key => $val) fclose($val[0]);

$imfoln = '';
if($dafnam == 'dabkrs' || $dafnam == 'dabkrss' || $dafnam == 'dabruks' || $dafnam == 'examples' || $grn == '') $imfoln = 'images_bkrs';
else if($grn == 'cdict') $imfoln = 'images_mdbg';

for($i = 1; $i <= $numparts; $i++) {
  if($numparts == 1) {
    $fnpstf = '';
    $dpstf = '';
  } else {
    $fnpstf = '_'.$i;
    $dpstf = "\n".'Часть '.$i.' из '.$numparts;
  }
  file_put_contents($ddir.'/'.$dafnam.$fnpstf.'.ann', "\xFF\xFE".iconv('UTF-8','UTF-16LE//IGNORE',tdre($dicdescr).$dpstf));
  @copy('dsx/'.$imfoln.'/dsl_icon.bmp', $ddir.'/'.$dafnam.$fnpstf.'.bmp');
}

if($GLOBALS['dsl_readme'] != '') file_put_contents($ddir.'/README.txt', "\xEF\xBB\xBF".$GLOBALS['dsl_readme']);

dzipc($ddir, 'dsl', 'dz', $GLOBALS['dsl_compress']);
zipc($ddir);
return restfunc($dafnam, $wordcount, $wordcountall);
}
?>